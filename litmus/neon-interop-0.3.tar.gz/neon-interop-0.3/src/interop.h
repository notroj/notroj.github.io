
#ifndef INTEROP_H
#define INTEROP_H 1

#include <ne_session.h>
#include <ne_request.h>
#include <ne_basic.h>

#include "tests.h"

/* prototype a test function. */
#define TF(x) int x(void)

TF(options);
TF(put_get);
TF(delete);
TF(delete_null);
TF(mkcol);
TF(delete_coll);
TF(mkcol_again);
TF(mkcol_no_parent);

TF(copy_init); TF(copy_simple); TF(copy_overwrite); TF(copy_cleanup);
TF(copy_coll);
TF(move); TF(move_coll); TF(move_cleanup);

TF(propfind_d0); TF(propfind_invalid); TF(propfind_invalid2);
TF(propinit); TF(propset); TF(propget); TF(propmove); 
TF(propdeletes); TF(propreplace);

TF(propnullns); TF(propmanyns);

TF(propcleanup);

/* The sesssion to use. */
extern ne_session *i_session;

/* server details. */
extern const char *i_hostname;
extern int i_port;
extern struct in_addr i_address;
extern char *i_path;

extern int i_class2; /* true if server is a class 2 DAV server. */

/* Upload htdocs/foo to i_path + path */
int upload_foo(const char *path);

#define ONREQ(x) do { int _ret = (x); if (_ret) { t_context("line %d: HTTP error:\n%s", __LINE__, ne_get_error(i_session)); return FAIL; } } while (0);

/* STATUS(404) returns non-zero if status code is not 404 */
#define STATUS(code) (strncmp(ne_get_error(i_session), #code " ", 4) != 0)

#define GETSTATUS (atoi(ne_get_error(i_session)))

#endif /* INTEROP_H */
