/* 
   litmus: WebDAV server test suite
   Copyright (C) 2001, Joe Orton <joe@manyfish.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "config.h"

#include <stdlib.h>

#include <ne_props.h>
#include <ne_uri.h>
#include <ne_locks.h>

#include "common.h"

static char *res, *res2;
ne_lock_session *l_sess;

struct ne_lock reslock = {0};

static int init_locks(void)
{
    l_sess = ne_lock_register(i_session);
    
    return OK;
}

static int put(void)
{
    PRECOND(i_class2);

    CONCAT2(res, i_path, "lockme");
    CONCAT2(res2, i_path, "notlocked");
    
    CALL(upload_foo("lockme"));
    CALL(upload_foo("notlocked"));    

    return OK;
}

static int lock(void)
{
    PRECOND(i_class2);

    reslock.uri = res;
    reslock.depth = NE_DEPTH_ZERO;
    reslock.scope = ne_lockscope_exclusive;
    reslock.type = ne_locktype_write;
    reslock.timeout = 3600;
    reslock.owner = "litmus test suite";
    
    ONREQ(ne_lock(i_session, &reslock));

    ne_lock_add(l_sess, ne_lock_copy(&reslock));

    return OK;
}

static int notowner_modify(void)
{
    char *tmp;
    ne_propname pname = { "http://webdav.org/neon/litmus/", "random" };
    ne_proppatch_operation pops[] = { 
	{ &pname, ne_propset, "foobar" },
	{ NULL }
    };

    PRECOND(i_class2);

    ONN("DELETE of locked resource", 
	ne_delete(i_session2, res) != NE_ERROR);

    if (STATUS2(423)) 
	t_warning("DELETE failed with %d not 423", GETSTATUS2);

    CONCAT2(tmp, i_path, "whocares");
    ONN("MOVE of locked resource", 
	ne_move(i_session2, 0, res, tmp) != NE_ERROR);
    free(tmp);
    
    if (STATUS2(423))
	t_warning("MOVE failed with %d not 423", GETSTATUS2);
    
    ONN("COPY onto locked resource",
	ne_copy(i_session2, 1, NE_DEPTH_ZERO, res2, res) != NE_ERROR);

    if (STATUS2(423))
	t_warning("COPY failed with %d not 423", GETSTATUS2);

    ONN("PROPPATCH of locked resource",
	ne_proppatch(i_session2, res, pops) != NE_ERROR);
    
    if (STATUS2(423))
	t_warning("PROPPATCH failed with %d not 423", GETSTATUS2);

    ONN("PUT on locked resource",
	ne_put(i_session2, res, i_foo_fd) != NE_ERROR);

    if (STATUS2(423))
	t_warning("PUT failed with %d not 423", GETSTATUS2);

    return OK;    
}

static int notowner_lock(void)
{
    struct ne_lock dummy;

    memcpy(&dummy, &reslock, sizeof(reslock));
    dummy.token = "opaquelocktoken:foobar";

    ONN("UNLOCK of locked resource",
	ne_unlock(i_session2, &dummy) != NE_ERROR);

    /* 2518 doesn't really say what status code that UNLOCK should
     * fail with. mod_dav gives a 400 as the locktoken is bogus.  */
    
    ONN("LOCK on locked resource",
	ne_lock(i_session2, &dummy) != NE_ERROR);
    
    if (STATUS2(423))
	t_warning("LOCK failed with %d not 423", GETSTATUS2);

    return OK;
}

static int owner_modify(void)
{
    ONV(ne_put(i_session, res, i_foo_fd),
	("PUT on locked resource failed: %s", ne_get_error(i_session)));

    return OK;
}

/* ne_lock_discover: check that the lock returned has correct URI,
 * token */

/* shared locks. */

/* collection locking. */

static int unlock(void)
{
    PRECOND(i_class2);

    ONREQ(ne_unlock(i_session, &reslock));

    return OK;
}

ne_test tests[] = {
    INIT_TESTS,
    
    T(init_locks),
    T(options),
    T(put),
    T(lock),
    
    T(notowner_modify),
    T(notowner_lock),
    
    T(owner_modify),

    /* Run the notowner tests again; make sure none of the modify_*
     * tests blew destroyed the lock. (this catches a mod_dav
     * regression when atomic PUT code is enabled). */
    T(notowner_modify),
    T(notowner_lock),

    T(unlock),

    FINISH_TESTS
};
    
