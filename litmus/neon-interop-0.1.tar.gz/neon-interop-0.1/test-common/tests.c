/* 
   Stupidly simple test framework
   Copyright (C) 2001, Joe Orton <joe@manyfish.co.uk>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include "config.h"

#include <sys/signal.h>

#include <stdio.h>
#ifdef HAVE_SIGNAL_H
#include <signal.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif

#include "ne_utils.h"
#include "ne_socket.h"

#include "tests.h"

char on_err_buf[BUFSIZ];

const char *name = NULL;
static FILE *child_debug;

char **test_argv;
int test_argc;

static int passes = 0, fails = 0, skipped = 0, warnings = 0;

static int warned;

static int aborted = 0;
static const char *suite;

void i_am(const char *testname)
{
    name = testname;
}

void warning(const char *str, ...)
{
    va_list ap;
    printf("WARNING: ");
    va_start(ap, str);
    vprintf(str, ap);
    va_end(ap);
    warnings++;
    warned++;
    putchar('\n');
}    

#define TEST_DEBUG (NE_DBG_HTTP | NE_DBG_SOCKET | NE_DBG_HTTPBODY)

#define W(m) write(0, m, strlen(m))

static void child_segv(int signo)
{
    signal(SIGSEGV, SIG_DFL);
    W("(possible segfault in child, not dumping core)\n");
    exit(-1);
}

void in_child(void)
{
    ne_debug_init(child_debug, TEST_DEBUG);    
    NE_DEBUG(TEST_DEBUG, "**** Child forked ****\n");
    signal(SIGSEGV, child_segv);
}

int main(int argc, char *argv[])
{
    int n;
    FILE *debug;
    
    /* get basename(argv[0]) */
    suite = strrchr(argv[0], '/');
    if (suite == NULL) {
	suite = argv[0];
    } else {
	suite++;
    }

    test_argc = argc;
    test_argv = argv;

    sock_init();

    debug = fopen("debug.log", "a");
    if (debug == NULL) {
	fprintf(stderr, "%s: Could not open debug.log: %s\n", suite,
		strerror(errno));
	return -1;
    }
    child_debug = fopen("child.log", "a");
    if (child_debug == NULL) {
	fprintf(stderr, "%s: Could not open child.log: %s\n", suite,
		strerror(errno));
	fclose(debug);
	return -1;
    }

    ne_debug_init(debug, TEST_DEBUG);

    if (tests[0] == NULL) {
	printf("-> no tests found in %s\n", suite);
	return -1;
    }

    printf("-> running %s:\n", suite);
    
    for (n = 0; !aborted && tests[n] != NULL; n++) {
	printf("%d: ", n);
	name = NULL;
	warned = 0;
	fflush(stdout);
	NE_DEBUG(TEST_DEBUG, "******* Running test %d ********\n", n);
	switch (tests[n]()) {
	case OK:
	    if (warned) {
		printf("%d: pass (with %d warnings).\n", n, warned);
	    } else {
		printf("pass.\n");
	    }
	    passes++;
	    break;
	case FAILHARD:
	    aborted = 1;
	    /* fall-through */
	case FAIL:
	    if (name != NULL) {
		printf("%s - ", name);
	    }
	    printf("FAIL.\n");
	    fails++;
	    break;
	case SKIP:
	    if (name != NULL) {
		printf("%s - ", name);
	    }
	    printf("SKIPPED.\n");
	    skipped++;
	    break;
	}
    }

    /* discount skipped tests */
    if (skipped) {
	printf("-> %d %s.\n", skipped,
	       skipped==1?"test was skipped":"tests were skipped");
	n -= skipped;
	if (passes + fails != n) {
	    printf("-> ARGH! Number of test results does not match number of tests.\n"
		   "-> ARGH! Test Results are INRELIABLE.\n");
	}
    }
    /* print the summary. */
    printf("-> summary for %s: of %d tests run: %d passed, %d failed. %.1f%%\n",
	   suite, n, passes, fails, 100*(float)passes/n);
    if (warnings) {
	printf("-> %d warning%s issued.\n", warnings, 
	       warnings==1?" was":"s were");
    }	

    if (fclose(debug)) {
	fprintf(stderr, "Error closing debug.log: %s\n", strerror(errno));
	fails = 1;
    }
       
    if (fclose(child_debug)) {
	fprintf(stderr, "Error closing child.log: %s\n", strerror(errno));
	fails = 1;
    }
    
    return fails;
}

