/* 
   neon interop test suite
   Copyright (C) 2001, Joe Orton <joe@manyfish.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "config.h"

#include <sys/types.h>

#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include <fcntl.h>

#include <ne_request.h>
#include <ne_string.h>

#include "interop.h"

#if 0
static struct {
    const char *name;
    int found;
} methods[] = {
#define M(x) { #x, 0 }
    M(PROPFIND), M(HEAD), M(GET), M(OPTIONS), M(DELETE), 
    M(PROPPATCH), M(COPY), M(MOVE), M(LOCK), M(UNLOCK),
    { NULL, 0 }
};

static void allow_hdr(void *userdata, const char *value)
{
    char *str = ne_strdup(value), *pnt = str;

    do {
	char *tok = ne_token(&pnt, ',', NULL);
	int n;
	
	for (n = 0; methods[n].name != NULL; n++) {
	    if (strcmp(methods[n].name, tok) == 0) {
		methods[n].found = 1;
		break;
	    }
	}	
	
    } while (pnt != NULL);    

    free(str);
}

static int allowed(const char *method)
{
    int n;

    for (n = 0; methods[n].name != NULL; n++) {
	if (strcmp(methods[n].name, method) == 0) {
	    return methods[n].found;
	    break;
	}
    }	

    return -1;
}

/* pull in from ne_basic.c. */
extern void dav_hdr_handler(void *userdata, const char *value);

static int adv_options(void)
{
    ne_request *req = ne_request_create(i_session, "OPTIONS", "/dav/");

    ne_add_response_header_handler(req, "Allow", allow_hdr, NULL);
    ne_add_response_header_handler(req, "DAV", dav_hdr_handler, &caps);

    ONREQ(ne_request_dispatch(req) || ne_get_status(req)->code != 200);

    ne_request_destroy(req);

    return OK;
}

#endif


int options(void)
{
    ne_server_capabilities caps = {0};
    
    ONREQ(ne_options(i_session, i_path, &caps));

    ON(caps.dav_class1 == 0);
    if (caps.dav_class2 == 0) {
	warning("server does not claim Class 2 compliance");
    }
    i_class2 = caps.dav_class2;

    return OK;
}

static char *create_temp(const char *contents)
{
    char tmp[256] = "/tmp/neon-interop-XXXXXX";
    int fd;
    
    fd = mkstemp(tmp);
    
    write(fd, contents, strlen(contents));
    
    close(fd);

    return ne_strdup(tmp);
}

static int compare_contents(const char *fn, const char *contents)
{
    int fd = open(fn, O_RDONLY), ret, rd;
    char buffer[BUFSIZ];
    ne_buffer *b = ne_buffer_create();

    while ((rd = read(fd, buffer, BUFSIZ)) > 0) {
	ne_buffer_append(b, buffer, rd);
    }

    close(fd);
    
    if (strlen(b->data) != strlen(contents)) {
	warning("length mismatch: %d vs %d", strlen(b->data), strlen(contents));
    }
    if (strlen(b->data) != ne_buffer_size(b)) {
	warning("buffer problem: %d vs %d", 
		strlen(b->data), ne_buffer_size(b));
    }

    ret = memcmp(b->data, contents, ne_buffer_size(b));
    ne_buffer_destroy(b);

    return ret;
}

static const char *test_contents = ""
"This is\n"
"a test file.\n"
"for neon interop\n"
"testing.\n";

static char *pg_uri = NULL;

int put_get(void)
{
    char *fn, tmp[] = "/tmp/neon-interop2-XXXXXX", *uri;
    int fd, res;
    
    fn = create_temp(test_contents);
    
    CONCAT2(uri, i_path, "res");

    /* Make sure it isn't there. */
    ne_delete(i_session, uri);

    fd = open(fn, O_RDONLY);
    ONREQ(ne_put(i_session, uri, fd));
    close(fd);
    
    if (STATUS(201)) {
	warning("PUT of new resource gave %d, should be 201",
		GETSTATUS);
    }

    fd = mkstemp(tmp);
    ONREQ(ne_get(i_session, uri, fd));
    close(fd);

    res = compare_contents(tmp, test_contents);
    if (res != OK) {
	char cmd[1024];
	snprintf(cmd, 1024, "diff -u %s %s", fn, tmp);
	system(cmd);
	ONN("PUT/GET byte comparison", res);
    }

    /* Clean up. */
    unlink(fn);
    unlink(tmp);

    /* so delete() isn't skipped. */
    pg_uri = uri;

    return OK;
}

int delete(void)
{
    PRECOND(pg_uri); /* skip if put_get failed. */
    
    ON(ne_delete(i_session, pg_uri));

    return OK;
}

int delete_null(void)
{
    char *uri;

    CONCAT2(uri, i_path, "404me");
    ON(ne_delete(i_session, uri) != NE_ERROR);

    if (STATUS(404)) {
	warning("DELETE on null resource gave %d, should be 404",
		GETSTATUS);
    }

    return OK;
}

static char *coll_uri = NULL;

int mkcol(void)
{
    char *uri;

    CONCAT2(uri, i_path, "coll/");

    /* Make sure it's not there. */
    ne_delete(i_session, uri);
    
    ONREQ(ne_mkcol(i_session, uri));
    
    coll_uri = uri; /* for subsequent tests. */

    return OK;
}

int mkcol_again(void)
{
    PRECOND(coll_uri);

    ONN("MKCOL on existing collection succeeds",
	ne_mkcol(i_session, coll_uri) != NE_ERROR);

    if (STATUS(405)) {
	warning("MKCOL on existing collection gave %d, should be 405",
		GETSTATUS);
    }
    
    return OK;
}    

int delete_coll(void)
{
    PRECOND(coll_uri);
    
    ONREQ(ne_delete(i_session, coll_uri));

    return OK;
}


int mkcol_no_parent(void)
{
    char *uri;

    CONCAT2(uri, i_path, "409me/noparent/");

    ONN("MKCOL with missing intermediate succeeds",
	ne_mkcol(i_session, uri) != NE_ERROR);
    
    if (STATUS(409)) {
	warning("MKCOL with missing intermediate gave %d, should be 409",
		GETSTATUS);
    }

    return OK;
}
