/* Unconditionally define _GNU_SOURCE */
#ifndef _GNU_SOURCE
# undef _GNU_SOURCE
#endif

/* Define to be package name */
#undef PACKAGE

/* Define to be version string */
#undef VERSION

/* Define if you have LC_MESSAGE */
#undef HAVE_LC_MESSAGES

/* Define if you have OpenSSL */
#undef SSL_ENABLE

/* Define to enable SOCKS support */
#undef HAVE_SOCKS

/* Define if you have socks.h */
#undef HAVE_SOCKS_H

/* Define if you have expat */
#undef HAVE_EXPAT

/* Define if you have libxml */
#undef HAVE_LIBXML

