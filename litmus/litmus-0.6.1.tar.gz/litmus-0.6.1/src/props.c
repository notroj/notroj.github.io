/* 
   litmus: DAV server test suite
   Copyright (C) 2001-2002, Joe Orton <joe@manyfish.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "config.h"

#include <stdlib.h>

#include <ne_request.h>
#include <ne_props.h>
#include <ne_uri.h>

#include "common.h"

#define NS "http://webdav.org/neon/litmus/"

#define NSPACE(x) ((x) ? (x) : "")

static const ne_propname props[] = {
    { "DAV:", "getcontentlength" },
    { "DAV:", "getlastmodified" },
    { "DAV:", "displayname" },
    { "DAV:", "resourcetype" },
    { NS, "foo" },
    { NS, "bar" },
    { NULL }
};

#define ELM_resourcetype (NE_ELM_207_UNUSED + 1)
#define ELM_collection (NE_ELM_207_UNUSED + 4)

static const struct ne_xml_elm complex_elms[] = {
    { "DAV:", "resourcetype", ELM_resourcetype, 0 },
    { "DAV:", "collection", ELM_collection, 0 },
    { NULL }
};

struct private {
    int collection;
};

struct results {
    ne_propfind_handler *ph;
    int result;
};

static void d0_results(void *userdata, const char *uri,
		       const ne_prop_result_set *rset)
{
    struct results *r = userdata;
    
    if (strncmp(uri, "http://", 7) == 0) {
	/* Absolute URI */
	uri = strchr(uri+7, '/');
	if (uri == NULL) {
	    NE_DEBUG(NE_DBG_HTTP, "Invalid URI???");
	    return;
	}
    }

    if (ne_path_compare(uri, i_path)) {
	t_warning("response href for wrong resource");
    } else {
	struct private *priv = ne_propset_private(rset);
	if (!priv->collection) {
	    r->result = FAIL;
	    t_context("Base collection did not define {DAV:}collection property");
	    return;
	} else {
	    r->result = 0;
	}
    }
}

static void *create_private(void *userdata, const char *uri)
{
    return ne_calloc(sizeof(struct private));
}

static int d0_validate(void *ud, ne_xml_elmid parent, ne_xml_elmid child)
{
    if ((parent == NE_ELM_prop && child == ELM_resourcetype) ||
	(parent == ELM_resourcetype && child == ELM_collection))
	return NE_XML_VALID;
    else
	return NE_XML_DECLINE;
}

static int endelm(void *userdata, const struct ne_xml_elm *elm, 
		  const char *cdata)
{
    struct results *r = userdata;
    struct private *p = ne_propfind_current_private(r->ph);

    if (elm->id == ELM_collection) {
	p->collection = 1;
    }

    return 0;
}

/* Depth 0 PROPFIND on root collection. */
static int propfind_d0(void)
{
    int ret;
    struct results r = {0};

    r.ph = ne_propfind_create(i_session, i_path, NE_DEPTH_ZERO);
    
    ne_propfind_set_private(r.ph, create_private, NULL);

    r.result = FAIL;
    t_context("No responses returned");

    ne_xml_push_handler(ne_propfind_get_parser(r.ph), complex_elms,
			d0_validate, NULL, endelm, &r);

    ret = ne_propfind_named(r.ph, props, d0_results, &r);

    if (r.result) {
	return r.result;
    }

    return OK;
}

static int do_invalid_pfind(const char *body)
{
    ne_request *req = ne_request_create(i_session, "PROPFIND", i_path);

    ne_set_request_body_buffer(req, body, strlen(body));

    ne_add_depth_header(req, NE_DEPTH_ZERO);

    ONV(ne_request_dispatch(req),
	("PROPFIND with non-well-formed XML request failed: %s",
	 ne_get_error(i_session)));
    
    if (STATUS(400)) {
	t_context("PROPFIND with ill-formed XML body got %d response not 400", GETSTATUS);
	return FAIL;
    }

    ne_request_destroy(req);

    return OK;
}

static int propfind_invalid(void)
{
    return do_invalid_pfind("<foo>");
}    

/* Julian Reschke's bug regarding invalid namespace declarations.
 * http://dav.lyra.org/pipermail/dav-dev/2001-August/002593.html
 * (mod_dav regression test).  */
static int propfind_invalid2(void)
{
    return do_invalid_pfind(
	"<D:propfind xmlns:D=\"DAV:\">"
	"<D:prop><bar:foo xmlns:bar=\"\"/>"
	"</D:prop></D:propfind>");
}


static int prop_ok = 0;
char *prop_uri;

static int propinit(void)
{
    CONCAT2(prop_uri, i_path, "prop");
    
    ne_delete(i_session, prop_uri);

    CALL(upload_foo("prop"));

    prop_ok = 1;
    
    return OK;
}

#define NP (10)

static ne_proppatch_operation pops[NP + 1];
static ne_propname propnames[NP + 1];
static char *values[NP + 1];

static int numprops = NP, removedprops = 5;

#define PS_VALUE "value goes here"

static int propset(void)
{
    int n;
    char tmp[100];

    for (n = 0; n < numprops; n++) {
	sprintf(tmp, "prop%d", n);
	propnames[n].nspace = NS;
	propnames[n].name = ne_strdup(tmp);
	pops[n].name = &propnames[n];
	pops[n].type = ne_propset;
	sprintf(tmp, "value%d", n);
	values[n] = ne_strdup(tmp);
	pops[n].value = values[n];
    }

    memset(&pops[n], 0, sizeof(pops[n]));
    memset(&propnames[n], 0, sizeof(propnames[n]));	   
    values[n] = NULL;

    PRECOND(prop_ok);

    prop_ok = 0; /* if the PROPPATCH fails, no point in testing further. */
    ONMREQ("PROPPATCH", prop_uri, ne_proppatch(i_session, prop_uri, pops));
    prop_ok = 1;

    return OK;
}

static void pg_results(void *userdata, const char *uri,
		       const ne_prop_result_set *rset)
{
    struct results *r = userdata;
    const char *value;
    const ne_status *status;
    int n;

    r->result = 0;

    for (n = 0; n < numprops; n++) {
	value = ne_propset_value(rset, &propnames[n]);
	status = ne_propset_status(rset, &propnames[n]);

	if (values[n] == NULL) {
	    /* We should have received a 404 for this property. */

	    if (value == NULL) {
		if (status == NULL) {
		    t_warning("Property %d omitted from results with no status",
			      n);
		} else if (status->code != 404) {
		    t_warning("Status for missing property %d was not 404", n);
		}
	    } else {
		r->result = FAIL;
		t_context("Deleted property `{%s}%s' was still present",
			  NSPACE(propnames[n].nspace), propnames[n].name);
	    }
	} else {
	    /* We should have a value for this property. */
	    if (value == NULL) {
		t_context("No value given for property {%s}%s", 
			  NSPACE(propnames[n].nspace), propnames[n].name);
		r->result = FAIL;
	    } else if (strcmp(value, values[n])) {
		t_context("Property {%s}%s had value %s, expected %s",
			  NSPACE(propnames[n].nspace), propnames[n].name, 
			  value, values[n]);
		/* Check the value matches. */
		r->result = FAIL;
	    }
	}
    }
    
}

static int propget(void)
{
    struct results r = {0};

    PRECOND(prop_ok);

    r.result = 1;
    t_context("No responses returned");

    ONMREQ("PROPFIND", prop_uri,
	   ne_simple_propfind(i_session, prop_uri, NE_DEPTH_ZERO,
			      propnames, pg_results, &r));

    if (r.result) {
	return r.result;
    }	

    return OK;
}

static int propmove(void)
{
    char *dest;

    PRECOND(prop_ok);

    CONCAT2(dest, i_path, "prop2");
    
    ne_delete(i_session, dest);

    ONM2REQ("MOVE", prop_uri, dest,
	    ne_move(i_session, 0, prop_uri, dest));

    free(prop_uri);
    prop_uri = dest;

    return OK;
}

static int propdeletes(void)
{
    int n;

    PRECOND(prop_ok);
    
    for (n = 0; n < removedprops; n++) {
	pops[n].type = ne_propremove;
	values[n] = NULL;
    }

    ONMREQ("PROPPATCH", prop_uri,
	   ne_proppatch(i_session, prop_uri, pops));

    return OK;
}

static int propreplace(void)
{
    int n;

    PRECOND(prop_ok);

    for (n = removedprops; n < numprops; n++) {
	char tmp[100];
	sprintf(tmp, "newvalue%d", n);
	pops[n].type = ne_propset;
	pops[n].value = values[n] = ne_strdup(tmp);
    }

    ONMREQ("PROPPATCH", prop_uri,
	   ne_proppatch(i_session, prop_uri, pops));

    return OK;
}

/* Regression test for mod_dav 1.0.2, another found by Julian Reschke, 
 * see FAQ for details. */
static int propnullns(void)
{
    ne_request *req;

    PRECOND(prop_ok);

    numprops = 1;
    removedprops = 0;
    
    propnames[0].nspace = NULL;
    propnames[0].name = "nonamespace";
    pops[0].value = values[0] = "randomvalue";
    pops[0].type = ne_propset;

    pops[1].name = NULL;
    propnames[1].name = NULL;
    
    req = ne_request_create(i_session, "PROPPATCH", prop_uri);

#define BODY \
    "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" \
    "<propertyupdate xmlns=\"DAV:\"><set><prop>" \
    "<nonamespace xmlns=\"\">randomvalue</nonamespace>" \
    "</prop></set></propertyupdate>"
    
    ne_set_request_body_buffer(req, BODY, strlen(BODY));
    
    ONNREQ("PROPPATCH of property with null namespace (see FAQ)",
	   ne_request_dispatch(req));
    
    ne_request_destroy(req);

    return OK;
}

static const char *manyns[10] = {
    "alpha", "beta", "gamma", "delta", "epsilon", 
    "zeta", "eta", "theta", "iota", "kappa"
};    

static int propmanyns(void)
{
    int n;

    numprops = 10;

    for (n = 0; n < numprops; n++) {
	propnames[n].nspace = manyns[n];
	propnames[n].name = "somename";
	pops[n].name = &propnames[n];
	pops[n].value = values[n] = "manynsvalue";
	pops[n].type = ne_propset;
    }

    ONMREQ("PROPPATCH", prop_uri,
	   ne_proppatch(i_session, prop_uri, pops));
    
    return OK;
}

static int propcleanup(void)
{
    ne_delete(i_session, prop_uri);
    return OK;
}

ne_test tests[] = 
{
    INIT_TESTS,

    T(propfind_invalid), T(propfind_invalid2),
    T(propfind_d0),
    T(propinit),
    T(propset), T(propget),
    T(propmove), T(propget),
    T(propdeletes), T(propget),
    T(propreplace), T(propget),
    T(propnullns), T(propget),
    
    T(propinit),

    T(propmanyns), T(propget),
    T(propcleanup),

    FINISH_TESTS
};
