/* 
   neon interop test suite
   Copyright (C) 2001, Joe Orton <joe@manyfish.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <config.h>

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#include <fcntl.h>
#include <stdlib.h>

#include <ne_uri.h>
#include <ne_auth.h>

#include "interop.h"

int i_class2 = 0;

ne_session *i_session;

const char *i_hostname;
int i_port;
struct in_addr i_address;
char *i_path;

static int use_secure = 0;

const char *i_username = NULL, *i_password;

static int foo_fd;

static int init(void)
{
    struct uri u = {0};

    if (test_argc < 2 || test_argc > 4 || test_argc == 3) {
	i_am("Usage: interop URL [username password]");
	return FAILHARD;
    }

    if (uri_parse(test_argv[1], &u, NULL)) {
	i_am("Parse URL");
	return FAILHARD;
    }       

    if (u.scheme && strcmp(u.scheme, "https") == 0)
	use_secure = 1;

    i_hostname = u.host;
    if (u.port > 0) {
	i_port = u.port;
    } else {
	if (use_secure) {
	    i_port = 443;
	} else {
	    i_port = 80;
	}
    }
    if (uri_has_trailing_slash(u.path)) {
	i_path = u.path;
    } else {
	CONCAT2(i_path, u.path, "/");
    }

    i_path = uri_abspath_escape(i_path);
    
    if (test_argc > 2) {
	i_username = test_argv[2];
	i_password = test_argv[3];
    }

    i_am("hostname lookup");
    if (sock_name_lookup(i_hostname, &i_address))
	return FAILHARD;

    return OK;
}

static int open_foo(void)
{
    foo_fd = open("htdocs/foo", O_RDONLY);
    ONN("open htdocs/foo", foo_fd < 0);
    return OK;
}

static int test_connect(void)
{
    nsocket *sock = sock_connect(i_address, i_port);
    if (sock == NULL) {
	i_am("connect to server");
	return FAILHARD;
    }
    sock_close(sock);
    return OK;
}

static int auth(void *ud, const char *realm,
		char **username, char **password)
{
    *username = ne_strdup(i_username);
    *password = ne_strdup(i_password);
    return 0;
}

static int begin(void)
{
    i_session = ne_session_create();
    ON(i_session == NULL);

    ONN("hostname lookup", ne_session_server(i_session, i_hostname, i_port));

    ne_set_useragent(i_session, "interop/" VERSION);
    
    if (i_username) {
	ne_set_server_auth(i_session, auth, NULL);
    }

    if (use_secure) {
	if (ne_set_secure(i_session, 1)) {
	    i_am("No SSL support, reconfigure using --with-ssl");
	    return FAILHARD;
	}
    }
    
    ne_set_persist(i_session, 0);
    
    return OK;
}

static int finish(void)
{
    ne_session_destroy(i_session);
    return OK;
}

int upload_foo(const char *path)
{
    char *uri;
    int ret;
    CONCAT2(uri, i_path, path);
    /* foo_fd is rewound automagically by ne_request.c */
    ret = ne_put(i_session, uri, foo_fd);
    free(uri);
    return ret;
}

#define ONS(str, x) do {						\
    if ((x) < 0) {					       		\
	sprintf(on_err_buf, "%s: %s", (str), sock_get_error(sock));	\
	i_am(on_err_buf);					       	\
	return FAIL;							\
    }									\
} while (0)

static int expect100(void)
{
    nsocket *sock;
    char req[BUFSIZ], buf[BUFSIZ];
    ne_status status = {0};

    sock = sock_connect(i_address, i_port);
    ONN("connect to server", sock == NULL);
    
    sprintf(req, 
	    "PUT %sexpect100 HTTP/1.1" EOL
	    "Host: %s" EOL
	    "Content-Length: 100" EOL
	    "Expect: 100-continue" EOL EOL,
	    i_path, i_hostname);

    NE_DEBUG(NE_DBG_SOCKET, "Request:\n%s", req);

    ONS("sending request", sock_send_string(sock, req));

    switch (sock_block(sock, 30)) {
    case SOCK_TIMEOUT: 
	ONN("timeout waiting for interim response", FAIL);
	break;
    case 0:
	/* no error. */
	break;
    default:
	ONN("error reading from socket", FAIL);
	break;
    }

    ONS("reading status line", sock_readline(sock, buf, BUFSIZ));

    NE_DEBUG(NE_DBG_HTTP, "[status] %s", buf);

    ONN("parse status line", ne_parse_statusline(buf, &status));

    if (status.code == 100) {
	char rbuf[100] = {0};
	
	ONN("write request body", sock_fullwrite(sock, rbuf, 100));
    }

    sock_close(sock);

    return OK;
}

ne_test tests[] = {
    /*** Initialization ***/
    T(init),
    T(test_connect),
    T(open_foo),
    T(begin),

    /* Basic tests. */
    T(options),
    T(put_get),
    T(delete),
    T(delete_null),
    T(mkcol),
    T(mkcol_again),
    T(delete_coll),
    T(mkcol_no_parent),

    /*** Copy/move tests. ***/
    T(copy_init), T(copy_simple), T(copy_overwrite), T(copy_cleanup), 
    T(copy_coll), T(move), T(move_coll), T(move_cleanup),

    /*** Property tests ***/
    T(propfind_invalid),
    T(propfind_d0),
    T(propinit),
    T(propset), T(propget),
    T(propmove), T(propget),
    T(propdeletes), T(propget),
    T(propreplace), T(propget),
    T(propcleanup),

    /* Test for 100-continue support */
    T(finish),
    T(begin), T(expect100),

    /*** End of tests ***/

    T(finish),
    T(NULL)
};


