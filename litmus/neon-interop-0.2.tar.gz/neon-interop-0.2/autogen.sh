#!/bin/sh
set -e
echo -n "aclocal... "
aclocal -I macros
echo -n "autoheader... "
autoheader
echo -n "autoconf... "
autoconf
echo okay.
rm -rf autom4te.cache
