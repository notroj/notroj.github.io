/* 
   litmus: WebDAV server test suite: common routines
   Copyright (C) 2001-2002, Joe Orton <joe@manyfish.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <config.h>

#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif

#include <fcntl.h>
#include <stdlib.h>

#include <ne_uri.h>
#include <ne_auth.h>

#include "getopt.h"

#include "common.h"

int i_class2 = 0;

ne_session *i_session, *i_session2;

const char *i_hostname;
int i_port;
struct in_addr i_address;
char *i_path;

static int use_secure = 0;

const char *i_username = NULL, *i_password;

static char *htdocs_root = NULL;

int i_foo_fd;

const static struct option longopts[] = {
    { "htdocs", required_argument, NULL, 'd' },
    { "help", no_argument, NULL, 'h' },
    { NULL }
};

static void usage(FILE *output)
{
    fprintf(output, 
	    "Usage: %s [OPTIONS] URL [username password]\n"
	    " Options are:\n"
	    "    -d DIR    use given htdocs root directory\n",
	    test_argv[0]);
}
	    

int init(void)
{
    struct uri u = {0};
    int optc, n;

    while ((optc = getopt_long(test_argc, test_argv, 
			       "d:h", longopts, NULL)) != -1) {
	switch (optc) {
	case 'd':
	    htdocs_root = optarg;
	    break;
	case 'h':
	    usage(stdout);
	    exit(1);
	default:
	    usage(stderr);
	    exit(1);
	}
    }

    n = test_argc - optind;

    if (n == 0 || n > 3 || n == 2) {
	usage(stderr);
	exit(1);
    }

    if (htdocs_root == NULL)
	htdocs_root = "htdocs";

    if (uri_parse(test_argv[optind], &u, NULL)) {
	t_context("Parse URL");
	return FAILHARD;
    }       

    if (u.scheme && strcmp(u.scheme, "https") == 0)
	use_secure = 1;

    i_hostname = u.host;
    if (u.port > 0) {
	i_port = u.port;
    } else {
	if (use_secure) {
	    i_port = 443;
	} else {
	    i_port = 80;
	}
    }
    if (uri_has_trailing_slash(u.path)) {
	i_path = u.path;
    } else {
	CONCAT2(i_path, u.path, "/");
    }

    i_path = uri_abspath_escape(i_path);
    
    if (test_argc > 2) {
	i_username = test_argv[2];
	i_password = test_argv[3];
	
	if (strlen(i_username) >= NE_ABUFSIZ) {
	    t_context("username must be <%d chars", NE_ABUFSIZ);
	    return FAILHARD;
	}

	if (strlen(i_password) >= NE_ABUFSIZ) {
	    t_context("password must be <%d chars", NE_ABUFSIZ);
	    return FAILHARD;
	}
    }

    if (sock_name_lookup(i_hostname, &i_address)) {
	t_context("hostname lookup");
	return FAILHARD;
    }

    return OK;
}

int open_foo(void)
{
    char *foofn;
    CONCAT2(foofn, htdocs_root, "/foo");
    i_foo_fd = open(foofn, O_RDONLY);
    if (i_foo_fd < 0) {
	t_context("could not open %s: %s", foofn, strerror(errno));
	return FAILHARD;
    }
    return OK;
}

int test_connect(void)
{
    nsocket *sock = sock_connect(i_address, i_port);
    if (sock == NULL) {
	t_context("connect to server");
	return FAILHARD;
    }
    sock_close(sock);
    return OK;
}

static int auth(void *ud, const char *realm, int attempt,
		char *username, char *password)
{
    strcpy(username, i_username);
    strcpy(password, i_password);
    return attempt;
}

static void i_pre_send(void *userdata, ne_buffer *hdr)
{
    char buf[BUFSIZ];
    const char *name = userdata;
    
    snprintf(buf, BUFSIZ, "%s: %s: %d (%s)\r\n", 
	     name, test_suite, test_num, tests[test_num].name);
    
    ne_buffer_zappend(hdr, buf);
}

static int init_session(ne_session *sess)
{
    ONN("hostname lookup", ne_session_server(sess, i_hostname, i_port));

    ne_set_useragent(i_session, "litmus/" VERSION);

    if (i_username) {
	ne_set_server_auth(sess, auth, NULL);
    }

    if (use_secure) {
	if (ne_set_secure(sess, 1)) {
	    t_context("No SSL support, reconfigure using --with-ssl");
	    return FAILHARD;
	}
    }
    
    ne_set_persist(sess, 0);

    return OK;
}    

int begin(void)
{
    i_session = ne_session_create();
    i_session2 = ne_session_create();

    CALL(init_session(i_session));
    CALL(init_session(i_session2));

    /* Send header with every request associating the request with the
     * test number and session. */
    ne_hook_pre_send(i_session, i_pre_send, "X-Litmus");
    ne_hook_pre_send(i_session2, i_pre_send, "X-Litmus-Second");

    return OK;
}

int make_space(void)
{
    char *space;

    CONCAT2(space, i_path, "litmus/");
    
    ne_delete(i_session, space);

    if (ne_mkcol(i_session, space)) {
	t_context("Could not create new collection `%s' for tests: %s\n"
		  "Server must allow `MKCOL %s' for tests to proceed", 
		  space, ne_get_error(i_session), space);
	return FAILHARD;
    }
    
    free(i_path);
    i_path = space;    

    return OK;
}

int finish(void)
{
    ne_session_destroy(i_session);
    return OK;
}

int upload_foo(const char *path)
{
    char *uri;
    int ret;
    CONCAT2(uri, i_path, path);
    /* i_foo_fd is rewound automagically by ne_request.c */
    ret = ne_put(i_session, uri, i_foo_fd);
    free(uri);
    return ret;
}

int options(void)
{
    ne_server_capabilities caps = {0};
    
    ONV(ne_options(i_session, i_path, &caps),
	("OPTIONS on base collection `%s': %s", i_path, 
	 ne_get_error(i_session)));

    ONN("server does not claim WebDAV compliance", caps.dav_class1 == 0);
    if (caps.dav_class2 == 0) {
	t_warning("server does not claim Class 2 compliance");
    }
    i_class2 = caps.dav_class2;

    return OK;
}
