#!/bin/sh
set -e
rm -rf config.cache autom4te.cache
aclocal -I macros
autoheader
autoconf
gettextize --force --copy | egrep -v ^Copying
cp /usr/share/libtool/config.sub .
cp /usr/share/libtool/config.guess .
rm -rf autom4te.cache
