#!/bin/sh

major=`echo $1 | sed "s/\..*//g"`
minor=`echo $1 | sed "s/^[0-9]*\.\(.*\)\.[0-9]*$/\1/g"`
rel=`echo $1 | sed "s/^.*\./\1/g"`
version=$1

./.update-po.sh $version
