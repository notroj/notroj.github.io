/* 
 *      XSitecopy, for managing remote web sites with a GNOME interface.
 *      Copyright (C) 1999, Lee Mallabone <lee0@callnetuk.com
 *                                                                        
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *     
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *     
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 */

#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#include <gnome.h>
#include "gcommon.h"
#include "sites.h"
#include "common.h"
#include "rcfile.h"
#include "gcommon.h"
#include "misc.h"

#include "config.h"
#include "tree.h"

/* Updates */
void close_main_update_window(GtkButton * button, gpointer data);
void *actual_main_update(void *a_site);
int start_main_update(void);
int main_update_please(GtkWidget * update_button, gpointer data);

/* File List changes */
int fe_catchup_site(void);
void catchup_selected(gint button_number, gpointer data);
int fe_init_site(void);
void initialize_selected(gint button_number, gpointer data);

/* Disk accesses */
void save_default(void);	/* Saves site definitions to current value of 'rcfile' */

/* Site List changes */
void delete_a_site(GtkWidget * button_or_menu, gpointer data);
struct site *find_prev_site(struct site *a_site);	/* Used for delete_a_site */
void delete_selected(gint button_number);

#endif				/* OPERATIONS_H */
