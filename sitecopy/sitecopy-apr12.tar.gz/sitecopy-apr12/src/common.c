/* 
   sitecopy, manage remote web sites.
   Copyright (C) 1998-99, Joe Orton <joe@orton.demon.co.uk>.
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   $Id: common.c,v 1.21 2000/04/07 23:29:02 joe Exp $
*/

#include <config.h>

#include <stdio.h>
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif 
#include <stdarg.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif /* HAVE_STDLIB_H */

#include <ctype.h>

#ifndef HAVE_SNPRINTF
#include "snprintf.h"
#endif /* HAVE_SNPRINTF */

#include "i18n.h"
#include "common.h"
#include "md5.h"

int debug_mask;
FILE *debug_stream;

void debug( int ch, char *template, ...) 
{
#ifdef DEBUGGING
    va_list params;
    if( (ch&debug_mask) != ch ) return;
    fflush( stdout );
    va_start( params, template );
    vfprintf( debug_stream, template, params );
    va_end( params );
    if( (ch&DEBUG_FLUSH) == DEBUG_FLUSH ) fflush( debug_stream );
#else
    /* No debugging here */
#endif
}

/* Snagged from fetchmail */
# if !HAVE_STRERROR && !defined(strerror)
char *strerror (errnum)
     int errnum;
{
  extern char *sys_errlist[];
  extern int sys_nerr;

  if (errnum > 0 && errnum <= sys_nerr)
    return sys_errlist[errnum];
  return _("Unknown system error");
}
# endif /* HAVE_STRERROR */

/* Writes the ASCII representation of the MD5 digest into the
 * given buffer, which must be at least 33 characters long. */
void md5_hexify( unsigned char md5_buf[16], char *buffer ) {
    int count;
    for( count = 0; count<16; count++ ) {
	buffer[count*2] = HEXD2asc( md5_buf[count] >> 4 );
	buffer[count*2+1] = HEXD2asc( md5_buf[count] & 0x0f );
    }
    buffer[32] = '\0';
}

#define asc2hex(x) (((x) <= '9') ? ((x) - '0') : (tolower((x)) + 10 - 'a'))

/* Reads the ASCII representation of an MD5 digest. The buffer must
 * be at least 32 characters long. */
void md5_unhexify( const char *buffer, unsigned char md5_buf[16] ) {
    int count;
    for( count = 0; count<16; count++ ) {
	md5_buf[count] = ((asc2hex(buffer[count*2])) << 4) |
			  asc2hex(buffer[count*2+1]);
    }
}
