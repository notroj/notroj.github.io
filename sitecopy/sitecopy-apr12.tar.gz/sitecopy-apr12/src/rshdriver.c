/* 
   sitecopy rcp protocol driver module
   Copyright (C) 2000, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* TODO: 
 * - Reimplement using 'rcmd' etc natively (need to re-imp rcp protocol
 *   under GPL.) 
 * - At least fork/exec to save a sh process
 * - Do something with stdout
 */

#include <config.h>

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#ifdef HAVE_STDARG_H
#include <stdarg.h>
#endif

#include "xalloc.h"
#include "protocol.h"

typedef struct {
    const char *hostname;
    char *rsh_cmd, *rcp_cmd;
    char buf[BUFSIZ];
    char err[BUFSIZ];
} rsh_session;

static int run_rsh( rsh_session *sess, const char *template, ... ) 
#ifdef __GNUC__
                __attribute__ ((format (printf, 2, 3)))
#endif /* __GNUC__ */
    ;

static int run_rcp( rsh_session *sess, const char *template, ... ) 
#ifdef __GNUC__
                __attribute__ ((format (printf, 2, 3)))
#endif /* __GNUC__ */
    ;

static int run_rsh( rsh_session *sess, const char *template, ... ) 
{
    va_list params;
    char *pnt;
    size_t len;
    
    strcpy( sess->buf, sess->rsh_cmd );
    len = strlen( sess->rsh_cmd );
    pnt = sess->buf + len + 1;

    *pnt++ = ' ';

    va_start( params, template );
#ifdef HAVE_VSNPRINTF
    vfsnprintf( pnt, BUFSIZ - len, template, params );
#else
    vsprintf( pnt, template, params );
#endif
    va_end( params );

    if( system(sess->buf) == 0 ) {
	return PROTO_OK;
    } else {
	return PROTO_ERROR;
    }
}

static int run_rcp( rsh_session *sess, const char *template, ... ) 
{
    va_list params;
    char *pnt;
    size_t len;
    
    strcpy( sess->buf, sess->rcp_cmd );
    len = strlen( sess->rcp_cmd );
    pnt = sess->buf + len;
    
    *pnt++ = ' ';

    va_start( params, template );
#ifdef HAVE_VSNPRINTF
    vfsnprintf( pnt, BUFSIZ - len, template, params );
#else
    vsprintf( pnt, template, params );
#endif
    va_end( params );

    if( system(sess->buf) == 0 ) {
	return PROTO_OK;
    } else {
	return PROTO_ERROR;
    }
}

static int 
init( void **session, struct proto_options *opts )
{
    rsh_session *sess = xmalloc( sizeof(rsh_session) );
    memset( sess, 0, sizeof(rsh_session) );
    *session = sess;
    if( opts->rsh_cmd ) {
	sess->rsh_cmd = opts->rsh_cmd;
    } else {
	sess->rsh_cmd = "rsh";
    }
    if( opts->rcp_cmd ) {
	sess->rcp_cmd = opts->rcp_cmd;
    } else {
	sess->rcp_cmd = "rcp";
    }	
    return PROTO_OK;
}    

static void finish( void *session ) {
    rsh_session *sess = session;
    free( sess );
}

static int file_move( void *session, const char *from, const char *to ) {
    rsh_session *sess = session;
    return run_rsh(sess, "%s mv %s %s", sess->hostname, from, to );
}

static int file_upload( void *session, const char *local, const char *remote, 
			int ascii ) {
    rsh_session *sess = session;
    return run_rcp(sess, "%s %s:%s", local, sess->hostname, remote );
}

static int set_server( void *session, struct proto_host *server )
{
    rsh_session *sess = session;
    sess->hostname = server->hostname;
    /* TODO: could support server->username mapping onto
     * -l username for rsh, but rcp doesn't support this, so... */
    return PROTO_OK;
}

static int set_proxy( void *session, struct proto_host *proxy )
{
    return PROTO_UNSUPPORTED;
}

static int verify( void *session, const char *root )
{
    return PROTO_OK;
}

static int file_upload_cond( void *session,
			     const char *local, const char *remote,
			     int ascii, const time_t time ) {
    return PROTO_UNSUPPORTED;
}

static int file_get_modtime( void *sess, const char *remote, time_t *modtime ) {
    return PROTO_UNSUPPORTED;
}
    
static int file_download( void *sess, const char *local, const char *remote,
			  size_t remotesize, int ascii ) {
    return PROTO_UNSUPPORTED;
}

static int file_read( void *sess, const char *remote, size_t remotesize, 
		      proto_read_block reader, void *userdata ) {
    return PROTO_UNSUPPORTED;
}

static int file_delete( void *session, const char *filename ) {
    rsh_session *sess = session;
    return run_rsh( sess, "rm %s", filename );
}

static int file_chmod( void *session, const char *fname, const mode_t mode ) {
    rsh_session *sess = session;
    return run_rsh( sess, "chmod %03o %s", mode, fname );
}

static int dir_create( void *session, const char *dirname ) {
    rsh_session *sess = session;
    return run_rsh( sess, "mkdir %s", dirname );
}

static int dir_remove( void *session, const char *dirname ) {
    rsh_session *sess = session;
    return run_rsh( sess, "rmdir %s", dirname );
}

static int fetch_list( void *sess, const char *dirname, 
		       struct proto_file **files ) {
    return PROTO_UNSUPPORTED;
}

static const char *error( void *session ) {
    rsh_session *sess = session;
    return "An error occurred.";
}

/* The protocol drivers */
const struct proto_driver rsh_driver = {
    init,
    set_server,
    set_proxy,
    verify,
    finish,
    file_move,
    file_upload,
    file_upload_cond,
    file_get_modtime,
    file_download,
    file_read,
    file_delete,
    file_chmod,
    dir_create,
    dir_remove,
    NULL, /* create link */
    NULL, /* change link target */
    NULL, /* delete link */
    fetch_list,
    error,
    "", /* service name */
    0, /* service number */
    "rsh/rcp"
};
