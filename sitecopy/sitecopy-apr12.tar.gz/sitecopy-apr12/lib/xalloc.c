/* 
   Replacement memory allocation handling etc.
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

   $Id: xalloc.c,v 1.1 2000/04/05 15:31:09 joe Exp $
*/

#include <config.h>

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#include "xalloc.h"

void *xmalloc( size_t len ) 
{
    void *ptr = malloc(len);
    if( !ptr ) {
	/* uh-oh */
	abort();
    }
    return ptr;
}

#if !defined(HAVE_STRDUP) && !defined(strdup)
/* glibc2 defines strdup as a macro, don't be caught be that */
char *strdup( const char *s ) 
{
    return strcpy( xmalloc( strlen(s) + 1 ), s );
}
#endif

#if !defined(HAVE_STRNDUP) && !defined(strndup)
char *strndup( const char *s, size_t n )
{
    char *new = xmalloc( n + 1 );
    new[n] = '\0';
    memcpy( new, s, n );
    return new;
}
#endif
