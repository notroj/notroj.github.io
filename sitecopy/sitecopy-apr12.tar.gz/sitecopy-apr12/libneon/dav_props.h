/* 
   WebDAV Properties manipulation
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

*/

#ifndef DAV_PROPS_H
#define DAV_PROPS_H

#include "http_request.h"

struct dav_property {
    const char *name;
    const char *nspace;
    char *value;
    int result;
};

/* Find properties with names in set *props on resource at URI 
 * in set *props, with given depth. If props == NULL all properties
 * are returned.
 * Returns:
 *   HTTP_OK    *props has been changed (and numprops if props was == NULL)
 *   other HTTP_* codes.
 */
int dav_propfind( http_session *sess, const char *uri,
		  int depth, struct dav_property *props[], int *numprops );

#endif /* DAV_PROPS_H */
