/* 
   WebDAV Properties manipulation
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

   $Id: dav_props.c,v 1.1 2000/04/08 11:25:55 joe Exp $
*/

#include "config.h"

#include "dav_props.h"
#include "dav_207.h"

struct propfind_result {
    struct dav_propset;
};

int dav_propfind( http_session *sess, const char *uri, int depth, 
		  struct dav_propset *props[], int *numprops ) {
    int ret, is_allprop = (props==NULL);
    http_req *req;
    struct dav_207_parser p;
    struct hip_xml_elm *find_elms;
    static const struct hip_xml_elm *all_elms;
    sbuffer body, hdrs;
    
    body = sbuffer_create();

    sbuffer_concat( body, 
		    "<?xml version=\"1.0\"?>" EOL /* should we use encoding=? */
		    "<propfind xmlns=\"DAV:\">" );
    
    if( !is_allprop ) {
	int n;
	sbuffer_zappend( body, "<prop>" EOL );
	for( n = 0; n < numprops; n++ ) {
	    sbuffer_concat( body, "<" (*props)[n].name, " xmlns=\"", 
			    (*props)[n].nspace, "\">" EOL, NULL );
	}
	sbuffer_zappend( body, "</prop></propfind>" EOL );
    } else {
	sbuffer_zappend( body, "</allprop></propfind>" EOL );
    }
		    
    dav_207_init( &p );
    http_request_create( sess, "PROPFIND", uri );
    
    http_set_request_body( req, sbuffer_data(body) );
    
    hdrs = http_get_request_header( req );
    if( depth == 0 ) {
	sbuffer_zappend( hdrs, "Depth: 0" EOL );
    }
    
    return HTTP_ERROR;
}
