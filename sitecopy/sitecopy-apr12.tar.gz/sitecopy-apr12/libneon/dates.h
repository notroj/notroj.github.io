/* 
   Date manipulation routines
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 

*/

#ifndef DATES_H
#define DATES_H

#include "config.h"

#include <sys/types.h>

/* Date manipulation routines as per RFC1123 and RFC1036 */

/* Return current date/time in RFC1123 format */
char *rfc1123_date( time_t anytime );

/* Returns time from date/time in RFC1123 format */
time_t rfc1123_parse( const char *date );

time_t rfc1036_parse( const char *date );

/* Parses asctime date string */
time_t asctime_parse( const char *date );

#endif /* DATES_H */
