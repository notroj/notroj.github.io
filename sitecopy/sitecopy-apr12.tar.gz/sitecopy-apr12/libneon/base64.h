/* 
   Text->Base64 convertion, from RFC1521
   Copyright (C) 1998,1999,2000 Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

*/

#ifndef BASE64_H
#define BASE64_H

/* Plain->Base64 converter - will malloc the buffer to the correct size,
 * and fill it with the Base64 conversion of the parameter.
 * Base64 specification from RFC 1521. You must free() it. */

char *base64( const char *text );

#endif /* BASE64_H */

