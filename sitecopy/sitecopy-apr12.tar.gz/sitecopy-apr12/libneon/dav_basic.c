/* 
   WebDAV Class 1 namespace operations
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

   $Id: dav_basic.c,v 1.5 2000/04/10 12:34:19 joe Exp $
*/

#include "config.h"

#include "http_request.h"

#include "dav_basic.h"
#include "uri.h" /* for uri_has_trailing_slash */
#include "dav_207.h"

static int dummy_check( hip_xml_elmid p, hip_xml_elmid c );

static const struct hip_xml_elm unk[] = {
    { "@<unknown>@", HIP_ELM_unknown, 0 },
    { NULL, 0 }
};

static const struct hip_xml_elmlist dummy = {
    unk, dummy_check, NULL, NULL, NULL };

void dav_parse_xml_block( void *userdata, const char *block, size_t length )
{
    hip_xml_parse_v( userdata, block, length );
}

int dav_accept_207( void *userdata, http_req *req, http_status *status )
{
    return( status->code == 207);
}

/* Dispatch a DAV request and handle the 207 response appropriately */
int dav_simple_request( http_session *sess, http_req *req )
{
    int ret, invalid;
    http_status status;
    static const struct hip_xml_elm unk[] = {
	{ "@<unknown>@", HIP_ELM_unknown, 0 },
	{ NULL, 0 }
    };
    struct hip_xml_elmlist dummy = 
    { unk, dummy_check, NULL, NULL, NULL };
    struct dav_207_parser parser;

    dav_207_init( &parser, (struct hip_xml_elmlist *) &dummy);
    
    http_add_response_body_reader( req, dav_accept_207, dav_parse_xml_block, 
				   &parser );

    ret = http_request_dispatch( req, &status );

    invalid = dav_207_finish( &parser );

    if( ret == HTTP_OK ) {
	if( status.code == 207 ) {
	    if( invalid ) { 
		DEBUG( DEBUG_HTTP, "207 parsing error.\n" );
		http_set_error( sess, parser.parser.error );
	    } else {
		dav_207_write_errors( sess, &parser );
	    }
	    ret = HTTP_ERROR;
	} else if( status.class != 2 ) {
	    ret = HTTP_ERROR;
	}
    }

    /* Free the 207 contexts */
    dav_207_free( &parser, NULL, NULL );

    http_request_destroy( req );

    return ret;
}
    
static int copy_or_move( http_session *sess, int is_move, int no_overwrite,
			 const char *src, const char *dest ) {
    http_req *req = http_request_create( sess, is_move?"MOVE":"COPY", src );
    const char *str;
    sbuffer hdrs;

#ifdef USE_DAV_LOCKS
    /* Copy needs to read/write the source, and write to the destination */
    dav_lock_using_resource( req, src, 
			     is_move?dav_lockusage_write:dav_lockusage_read, 
			     DAV_DEPTH_INFINITE );
    dav_lock_using_resource( req, dest, dav_lockusage_write, 
			     DAV_DEPTH_INFINITE );
    /* And we need to be able to add members to the destination's parent */
    dav_lock_using_parent( req, dest );
#endif

    hdrs = http_get_request_header( req );
    str = http_get_server_hostport( sess );
    sbuffer_concat( hdrs, "Destination: http://", str, dest, EOL, NULL );

    if( no_overwrite )
	sbuffer_zappend( hdrs, "Overwrite: F" EOL );

#if 0
    /* FIXME */
    if( ! http_webdav_server ) {
	/* For non-WebDAV servers */
	strcat( req.headers, "New-URI: " );
	strcat( req.headers, to );
	strcat( req.headers, EOL );
    }
#endif

    return dav_simple_request( sess, req );
}

int dav_copy( http_session *sess, const char *src, const char *dest ) {
    return copy_or_move( sess, 0, 1, src, dest );
}

int dav_move( http_session *sess, const char *src, const char *dest ) {
    return copy_or_move( sess, 1, 1, src, dest );
}

/* Deletes the specified resource on the server */
int dav_delete( http_session *sess, const char *uri ) {
    http_req *req = http_request_create( sess, "DELETE", uri );

#ifdef USE_DAV_LOCKS
    dav_lock_using_resource( req, uri, dav_lockusage_write, DAV_DEPTH_INFINITE );
    dav_lock_using_parent( req, uri );
#endif
    
    return dav_simple_request( sess, req );
}

int dav_mkcol( http_session *sess, const char *uri ) 
{
    http_req *req;
    char *real_uri;
    int ret;

    if( uri_has_trailing_slash( uri ) ) {
	real_uri = strdup( uri );
    } else {
	CONCAT2( real_uri, uri, "/" );
    }

    req = http_request_create( sess, "MKCOL", real_uri );

#ifdef USE_DAV_LOCKS
    dav_lock_using_resource( req, real_uri, dav_lockusage_write, 0 );
    dav_lock_using_parent( req, real_uri );
#endif
    
    ret = dav_simple_request( sess, req );

    free( real_uri );

    return ret;
}

static int dummy_check( hip_xml_elmid p, hip_xml_elmid c ) {
    switch( p ) {
    case DAV_ELM_prop:
	if( c != HIP_ELM_unknown ) {
	    return -1;
	}
	break;
    case DAV_ELM_response:
	if( c != DAV_ELM_prop ) {
	    return -1;
	}
	break;
    }
    return 0;
}

int dav_207_write_errors( http_session *sess, struct dav_207_parser *p ) 
{
    /* write the error */
    sbuffer buf;
    struct dav_response *rsp;
    buf = sbuffer_create();
    for( rsp = p->ms.first; rsp != NULL; rsp = rsp->next ) {
	if( rsp->status_line && rsp->href ) {
	    sbuffer_concat( buf, rsp->href, ": ", rsp->status_line, "\n",
			    NULL );
	} else {
	    struct dav_propstat *pst;
	    /* TODO: put something meaningful here... this is quite
	     * tricky. */
	    for( pst = rsp->first; pst != NULL; pst = pst->next ) {
		sbuffer_concat( buf, rsp->href, ": ", pst->status_line, "\n",
				NULL );
	    }
	}
    }
    http_set_error( sess, sbuffer_data(buf) );
    sbuffer_destroy(buf);
    return HTTP_OK;
}
