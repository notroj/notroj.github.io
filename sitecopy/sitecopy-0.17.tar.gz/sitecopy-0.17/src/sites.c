/* 
   sitecopy, for managing remote web sites.
   Copyright (C) 1998-2008, Joe Orton <joe@manyfish.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

/* This is the core functionality of sitecopy, performing updates
 * and checking files etc. */

#include <config.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <errno.h>
#include <dirent.h>
#include <fnmatch.h>
#include <fcntl.h>
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif /* HAVE_STDLIB_H */
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif /* HAVE_UNISTD_H */
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#include <time.h>
#ifdef HAVE_LIMITS_H
#include <limits.h>
#endif
#include <utime.h>

/* neon */
#include <ne_string.h>
#include <ne_alloc.h>
#include <ne_md5.h>
#include <ne_socket.h>

#include "basename.h"

#include "i18n.h"
#include "common.h"
#include "frontend.h"
#include "protocol.h"
#include "sitesi.h"

/* Shorthand for protocol driver methods */
#define CALL(a) (*site->driver->a)
#define DRIVER_ERR  ((*site->driver->error)(session))

/* This holds ALL the sites defined in the rcfile */
struct site *all_sites;
 
static int proto_init(struct site *site, void **session);
static void proto_finish(struct site *site, void *session);
static void proto_seterror(struct site *site, void *session);

struct site *site_find(const char *sitename)
{
    struct site *current;

    for (current = all_sites; current!=NULL; current=current->next) {
	if (strcmp(current->name, sitename) == 0) {
	    /* We found it */
	    return current;
	}
    }

    return NULL;
}

static int synch_create_directories(struct site *site)
{
    struct site_file *current;
    char *full_local;
    int ret;
    
    ret = 0;
    
    for_each_file(current, site) {
	if ((current->type==file_dir) && (current->diff==file_deleted)) {
	    full_local = file_full_local(&current->stored, site);
	    fe_synching(current);
	    if (mkdir(full_local, 0755) == 0) {
		fe_synched(current, true, NULL);
	    } else {
		ret = 1;
		fe_synched(current, false, strerror(errno));
		file_downloaded(current, site);
	    }
	    free(full_local);
	}
    }
    return ret;
}

static int synch_files(struct site *site, void *session)
{
    struct site_file *current;
    int ret;

    ret = 0;

    for_each_file(current, site) {
        if (fe_interrupted())
            break;

        char *full_local, *full_remote;
        if (current->type != file_file) continue;
        switch (current->diff) {
        case file_changed:
            if (!file_contents_changed(current, site)) {
                /* Just chmod it */
                full_local = file_full_local(&current->stored, site);
                fe_setting_perms(current);
                if (chmod(full_local, current->stored.mode) < 0) {
                    fe_set_perms(current, false, strerror(errno));
                }
                else {
                    fe_set_perms(current, true, NULL);
                }
                ne_free(full_local);
                break;
            }
            /* fall through */
        case file_deleted:
            full_local = file_full_local(&current->stored, site);
            full_remote = file_full_remote(&current->stored, site);
            fe_synching(current);
            if (CALL(file_download)(session, full_local, full_remote,
                                    current->stored.ascii) != SITE_OK) {
                fe_synched(current, false, DRIVER_ERR);
                ret = 1;
            }
            else {
                /* Successfull download */
                fe_synched(current, true, NULL);
                if (site->state_method == state_timesize) {
                    struct utimbuf times;
                    /* Change the modtime of the local file so it doesn't look
                     * like it's changed already */
                    times.actime = current->stored.time;
                    times.modtime = current->stored.time;
                    if (utime(full_local, &times) < 0) {
                        fe_warning(_("Could not set modification time of local file."),
                                    full_local, strerror(errno));
                    }
                }
                if (file_perms_changed(current, site)) {
                    fe_setting_perms(current);
                    if (chmod(full_local, current->stored.mode) < 0) {
                        fe_set_perms(current, false, strerror(errno));
                    }
                    else {
                        fe_set_perms(current, true, NULL);
                    }
                }
                /* TODO: not strictly true if the chmod failed. */
                file_downloaded(current, site);
            }
            ne_free(full_local);
            ne_free(full_remote);
            break;
        case file_new:
            full_local = file_full_local(&current->local, site);
            fe_synching(current);
            if (unlink(full_local) != 0) {
                fe_synched(current, false, strerror(errno));
                ret = 1;
            }
            else {
                fe_synched(current, true, NULL);
            }
            ne_free(full_local);
            break;
        case file_moved: {
            char *old_full_local = file_full_local(&current->stored, site);
            full_local = file_full_local(&current->local, site);
            fe_synching(current);
            if (rename(full_local, old_full_local) == 0) {
                fe_synched(current, true, NULL);
            }
            else {
                fe_synched(current, false, strerror(errno));
                ret = 1;
            }
            ne_free(old_full_local);
            ne_free(full_local);
        }
        default:
            break;
        }
    }

    return ret;
}

static int synch_delete_directories(struct site *site)
{
    struct site_file *current, *prev;
    int ret;

    ret = 0;

    for (current=site->files_tail; current!=NULL; current=prev) {
	prev = current->prev;
	if ((current->type==file_dir) && (current->diff==file_new)) {
	    char *full_local = file_full_local(&current->local, site);
	    fe_synching(current);
	    if (rmdir(full_local) == -1) {
		fe_synched(current, false, strerror(errno));
		ret = 3;
	    } else {
		fe_synched(current, true, NULL);
		file_delete(site, current);
	    }
	    free(full_local);
	}
    }

    return ret;
}

/* Resyncs the LOCAL site with the REMOTE site.
 * This is site_update backwards, and is essentially the same in structure,
 * except with the logic reversed.
 */
int site_synch(struct site *site) 
{
    int ret, need_conn;
    void *session;
 
    /* Do we need to connect to the server: note that ignored files
     * are treated as changed files in synch mode. */
    need_conn = (site->numchanged + site->numdeleted + 
		 site->numignored > 0);
   
    if (need_conn) {
	ret = proto_init(site, &session);
	if (ret != SITE_OK) {
	    proto_finish(site, session);
	    return ret;
	}
    }

    ret = synch_create_directories(site);
    if (ret == 0 || site->keep_going) {
	ret = synch_files(site, session);
	if (ret == 0 || site->keep_going) {
	    ret = synch_delete_directories(site);
	}
    }
    
    if (need_conn) {
	proto_finish(site, session);
    }

    if (fe_interrupted()) {
	ret = SITE_INTERRUPTED;
    }
    else if (ret == 0) {
	ret = SITE_OK;
    }
    else {
	ret = SITE_ERRORS;
    }
    return ret;
}

static int file_chmod(struct site_file *file, struct site *site, void *session)
{
    int ret = 0;
    /* chmod it if necessary */
    if (file_perms_changed(file, site)) {
	char *full_remote = file_full_remote(&file->local, site);
	fe_setting_perms(file);
	if (CALL(file_chmod)(session, full_remote, file->local.mode) != SITE_OK) {
	    fe_set_perms(file, false, DRIVER_ERR);
	    ret = 1;
	} else {
	    file->stored.mode = file->local.mode;
	    fe_set_perms(file, true, NULL);
	    file_set_diff(file, site);
	}
	free(full_remote);
    }
    return ret;
}

static void 
file_retrieve_server(struct site_file *file, struct site *site, void *session)
{
    time_t rtime;
    char *full_remote = file_full_remote(&file->local, site);
    if (CALL(file_get_modtime)(session, full_remote, &rtime) == SITE_OK) {
	file->server.time = rtime;
	file->server.exists = true;
    } else {
	file->server.exists = false;
	fe_warning(_("Upload succeeded, but could not retrieve modification time.\n"
		      "If this message persists, turn off safe mode."),
		    full_remote, DRIVER_ERR);
    }
    free(full_remote);
}

/* Create new directories and change permissions on existing directories. */
static int update_create_directories(struct site *site, void *session)
{
    struct site_file *current;
    int ret = 0;

    for_each_file(current, site) {
        if (fe_interrupted())
            break;

        char *full_remote;
        int oret = SITE_OK;

        /* New or changed directories only. */
        if (current->type != file_dir
            || (current->diff != file_new && current->diff != file_changed)
            || !fe_can_update(current))
            continue;

        full_remote = file_full_remote(&current->local, site);

        if (current->diff == file_new) {
            fe_updating(current);
            oret = CALL(dir_create)(session, full_remote);
            fe_updated(current, oret == SITE_OK,
                       oret == SITE_OK ? NULL : DRIVER_ERR);
            if (oret == SITE_OK && site->dirperms) {
                /* Record the directory as created, with its
                 * permissions not yet set, so that if setting them
                 * fails, the next update retries only that. */
                file_uploaded(current, site);
                current->stored.mode = 0;
                file_set_diff(current, site);
            }
        }

        if (site->dirperms && oret == SITE_OK) {
            fe_setting_perms(current);
            oret = CALL(file_chmod)(session, full_remote, current->local.mode);
            fe_set_perms(current, oret == SITE_OK,
                         oret == SITE_OK ? NULL : DRIVER_ERR);
        }

        if (oret == SITE_OK)
            file_uploaded(current, site);
        else
            ret = 1;

        ne_free(full_remote);
    }

    return ret;
}

/* Returns the filename to use for tempupload mode, ne_malloc-allocated:
 * FILENAME with a ".in." prefix inserted after any directories, and a
 * random suffix, so that it isn't the name of another file on the
 * server; or NULL if the filename is too long.  (pass the site since
 * we may have different tempupload modes in the future.) */
static char *temp_upload_filename(const char *filename, struct site *site)
{
    static int seeded = 0;
    const char *base = strrchr(filename, '/');
    char buf[PATH_MAX];

    if (!seeded) {
        srandom(time(NULL) ^ getpid());
        seeded = 1;
    }

    base = base ? base + 1 : filename;
    if (ne_snprintf(buf, sizeof buf, "%.*s.in.%s.%08lx",
                    (int)(base - filename), filename, base,
                    (unsigned long)random()) >= sizeof buf - 1) {
        /* Truncated. */
        return NULL;
    }

    return ne_strdup(buf);
}
static int update_delete_files(struct site *site, void *session)
{
    struct site_file *current, *next;
    int ret = 0;

    for (current=site->files; current!=NULL; current=next) {
        if (fe_interrupted())
            break;

	next = current->next;
	/* Skip directories and links, and only do deleted files on
	 * this pass */
	if (current->diff == file_deleted &&
	    current->type == file_file) {
	    char *full_remote;
	    if (!fe_can_update(current)) continue;
	    full_remote = file_full_remote(&current->stored, site);
	    fe_updating(current);
	    if (CALL(file_delete)(session, full_remote) != SITE_OK) {
		fe_updated(current, false, DRIVER_ERR);
		ret = 1;
	    } else {
		/* Successful update - file was deleted */
		fe_updated(current, true, NULL);
		file_delete(site, current);
	    }
	    free(full_remote);
	}
    }
    
    return ret;
}

static int update_move_files(struct site *site, void *session)
{
    int ret = 0;
    struct site_file *current;
    char *old_full_remote, *full_remote;

    for_each_file(current, site) {
        if (fe_interrupted())
            break;

        if (current->diff != file_moved || !fe_can_update(current))
            continue;

        /* The file has been moved */
        full_remote = file_full_remote(&current->local, site);
        fe_updating(current);
        old_full_remote = file_full_remote(&current->stored, site);
        if (CALL(file_move)(session, old_full_remote, full_remote) != SITE_OK) {
            ret = 1;
            fe_updated(current, false, DRIVER_ERR);
        }
        else {
            /* Successful update - file was moved */
            fe_updated(current, true, NULL);
            file_uploaded(current, site);
        }
        ne_free(old_full_remote);
        ne_free(full_remote);
    }

    return ret;
}


/* Does everything but file deletes */
static int update_files(struct site *site, void *session)
{
    struct site_file *current;
    char *full_local, *full_remote;
    int ret = 0;

    for_each_file(current, site) {
        if (fe_interrupted())
            break;


        /* This loop only handles changed and new files, so
         * skip everything else. */

        if (current->type != file_file
            || current->diff == file_deleted
            || current->diff == file_moved
            || current->diff == file_unchanged) continue;

        full_local = file_full_local(&current->local, site);
        full_remote = file_full_remote(&current->local, site);

        switch (current->diff) {
        case file_changed: /* File has changed, upload it */
            if (current->ignore) break;
            if (!file_contents_changed(current, site)) {
                /* If the file contents haven't changed, then we can
                 * just chmod it */
                if (file_chmod(current, site, session))
                    ret = 1;
                break;
            }
            /* fall through */
        case file_new: /* File is new, upload it */
            if (!fe_can_update(current))
                break;
            if (current->diff == file_changed && site->nooverwrite) {
                /* Must delete remote file before uploading new copy.
                 * FIXME: Icky hack to convince the FE we are about to
                 * delete the file */
                current->diff = file_deleted;
                fe_updating(current);
                if (CALL(file_delete)(session, full_remote) != SITE_OK) {
                    fe_updated(current, false, DRIVER_ERR);
                    ret = 1;
                    current->diff = file_changed;
                    /* Don't upload it! */
                    break;
                }
                else {
                    fe_updated(current, true, NULL);
                    current->diff = file_changed;
                    /* The file is no longer on the server: if the
                     * upload fails, the next update must upload it
                     * as a new file, rather than delete it again. */
                    current->stored.exists = false;
                }
            }
            fe_updating(current);
            /* Now, upload it */
            if (site->safemode && current->server.exists) {
                /* Only do this for files we do know the remote modtime for */
                int cret;
                cret = CALL(file_upload_cond)(session,
                    full_local, full_remote, current->local.ascii,
                    current->server.time);
                switch (cret) {
                case SITE_ERRORS:
                    fe_updated(current, false, DRIVER_ERR);
                    ret = 1;
                    break;
                case SITE_FAILED:
                    fe_updated(current, false,
                                _("Remote file has been modified - not overwriting with local changes"));
                    ret = 1;
                    break;
                default:
                    /* Success case */
                    fe_updated(current, true, NULL);
                    file_retrieve_server(current, site, session);
                    if (file_chmod(current, site, session)) ret = 1;
                    file_uploaded(current, site);
                    break;
                }
            }
            else if (site->tempupload) {
                /* Do temp file upload followed by a move */
                char *temp_remote = temp_upload_filename(full_remote, site);
                if (temp_remote == NULL) {
                    fe_updated(current, false,
                               _("Filename too long for a temporary upload"));
                    ret = 1;
                }
                else if (CALL(file_upload)(session, full_local, temp_remote,
                                           current->local.ascii) != SITE_OK) {
                    fe_updated(current, false, DRIVER_ERR);
                    ret = 1;
                }
                else {
                    /* Successful upload... now move it */
                    if (CALL(file_move)(session, temp_remote,
                                         full_remote) != SITE_OK) {
                        fe_updated(current, false, DRIVER_ERR);
                        /* Originally coded to delete the temporary file
                         * here, but, on second thoughts... if something
                         * is broken, let's not try to be too clever, else
                         * we might make it worse. */
                        ret = 1;
                    }
                    else {
                        /* Successful move */
                        fe_updated(current, true, NULL);
                        if (site->safemode) {
                            file_retrieve_server(current, site, session);
                        }
                        if (file_chmod(current, site, session)) ret = 1;
                        file_uploaded(current, site);
                    }
                }
                ne_free(temp_remote);
            }
            else {
                /* Normal unconditional upload */
                if (CALL(file_upload)(session, full_local, full_remote,
                                       current->local.ascii) != SITE_OK) {
                    fe_updated(current, false, DRIVER_ERR);
                    ret = 1;
                }
                else {
                    /* Successful upload. */
                    fe_updated(current, true, NULL);
                    if (site->safemode) {
                        file_retrieve_server(current, site, session);
                    }
                    if (file_chmod(current, site, session)) ret = 1;
                    file_uploaded(current, site);
                }
            }
            break;

        default: /* Ignore everything else */
            break;
        }
        ne_free(full_remote);
        ne_free(full_local);
    }

    return ret;

}

static int update_delete_directories(struct site *site, void *session)
{
    struct site_file *current, *prev;
    int ret = 0;

    /* This one must iterate through the list BACKWARDS, so
     * directories are deleted bottom up */
    for (current=site->files_tail; current!=NULL; current=prev) {
	prev = current->prev;
	if ((current->type==file_dir) && (current->diff == file_deleted)) {
	    char *full_remote;
	    if (!fe_can_update(current)) continue;
	    full_remote = file_full_remote(&current->stored, site);
	    fe_updating(current);
	    if (CALL(dir_remove)(session, full_remote) != SITE_OK) {
		ret = 1;
		fe_updated(current, false, DRIVER_ERR);
	    } else {
		/* Successful delete */
		fe_updated(current, true, NULL);
		file_delete(site, current);
	    }
	    free(full_remote);
	}
    }
    return ret;
}

static int update_links(struct site *site, void *session)
{
    struct site_file *current, *next;
    int ret = 0;

    for (current=site->files; current!=NULL; current=next) {
	char *full_remote;
	next = current->next;
	if (current->type != file_link) continue;

	full_remote = file_full_remote(&current->local, site);
	switch (current->diff) {
	case file_new:
	    fe_updating(current);
	    if (CALL(link_create)(session, full_remote, 
				  current->local.linktarget) != SITE_OK) {
		fe_updated(current, false, DRIVER_ERR);
		ret = 1;
	    } else {
		fe_updated(current, true, NULL);
		current->diff = file_unchanged;
	    }
	    break;
	case file_changed:
	    fe_updating(current);
	    if (CALL(link_change)(session, full_remote,
				   current->local.linktarget) != SITE_OK) {
		fe_updated(current, false, DRIVER_ERR);
		ret = 1;
	    } else {
		fe_updated(current, true, NULL);
		current->diff = file_unchanged;
	    }
	    break;
	case file_deleted:
	    fe_updating(current);
	    if (CALL(link_delete)(session, full_remote) != SITE_OK) {
		fe_updated(current, false, DRIVER_ERR);
		ret = 1;
	    } else {
		fe_updated(current, true, NULL);
		file_delete(site, current);
	    }
	default:
		break;
	}
	free(full_remote);
    }
    return ret;
}

static void proto_finish(struct site *site, void *session)
{
    proto_seterror(site, session);
    CALL(finish)(session);
}

static void proto_seterror(struct site *site, void *session)
{
    if (site->last_error)
        ne_free(site->last_error);
    site->last_error = ne_strdup(DRIVER_ERR);
}

const char *site_get_protoname(struct site *site) 
{
    if (site->driver)
	return site->driver->protocol_name;
    else
	return site->proto_string;
}

static int proto_init(struct site *site, void **session)
{
    int ret;
    
    if (site->last_error) {
        ne_free(site->last_error);
        site->last_error = NULL;
    }

    ret = CALL(init)(session, site);
    if (ret != SITE_OK) {
	proto_seterror(site, *session);
	return ret;
    }

    return SITE_OK;
}


/* Updates the remote site.
 * 
 * Executes each of the site_update_* functions in turn (if their
 * guard evaluates to true). 
 */
int site_update(struct site *site)
{
    int ret = 0, num;
    const struct handler {
	int (*func)(struct site *, void *session);
	int guard;
    } handlers[] = {
	{ update_delete_files, !site->nodelete },
	{ update_create_directories, 1 },
	{ update_move_files, site->checkmoved },
	{ update_files, 1 },
	{ update_links, site->symlinks == sitesym_maintain },
	{ update_delete_directories, !site->nodelete },
	{ NULL, 1 }
    };
    void *session;

    ret = proto_init(site, &session);
    if (ret != SITE_OK) {
	proto_finish(site, session);
	return ret;
    }
    
    for (num = 0; handlers[num].func != NULL && !fe_interrupted()
	     && (ret == 0 || site->keep_going);
	 num++) {
	if (handlers[num].guard) {
	    int newret;
	    newret = (*handlers[num].func)(site, session);
	    if (newret != 0) {
		ret = newret;
	    }
	}
    }

    if (fe_interrupted()) {
	ret = SITE_INTERRUPTED;
    }
    else if (ret == 0) {
	/* Site updated successfully. */
	ret = SITE_OK;
    }
    else {
	/* Update not totally successfull */
	ret = SITE_ERRORS;
    }

    proto_finish(site, session);

    return ret;
}

/* This reads off the remote files and the local files. */
int site_readfiles(struct site *site)
{
    int ret;
    site_destroy(site);
    ret = site_read_stored_state(site);
    if (ret == SITE_OK) {
	site_read_local_state(site);
    }
    return ret;
}

/* Read the local site files... 
 * A stack is used for directories within the site - this is not recursive.
 * Each item on the stack is a FULL PATH to the directory, i.e., including
 * the local site root. */

/* Initial size of directory stack, and amount it grows
 * each time we fill it. */
#define DIRSTACKSIZE (1024)

void site_read_local_state(struct site *site)
{
    char **dirstack, *this, *full = NULL;
    int dirtop = 0, /* points to item above top stack item */
        dirmax = DIRSTACKSIZE; /* size of stack */

    dirstack = ne_malloc(sizeof(char *) * DIRSTACKSIZE);
    /* Push the root directory on to the stack */
    dirstack[dirtop++] = ne_strdup(site->local_root);

    /* Now, for all items in the stack, process all the files, and
     * add the dirs to the stack. Everything we put on the stack is
     * temporary and gets freed eventually. */

    while (dirtop > 0) {
        DIR *curdir;
        struct dirent *ent;
        /* Pop the stack */
        this = dirstack[--dirtop];

        NE_DEBUG(DEBUG_FILES, "Scanning: %s\n", this);
        curdir = opendir(this);
        if (curdir == NULL) {
            fe_warning("Could not read directory", this, strerror(errno));
            ne_free(this);
            continue;
        }

        /* Now read all the directory entries */
        while ((ent = readdir(curdir)) != NULL) {
            char *fname;
            struct stat item;
            struct site_file *current;
            struct file_state local = {0};
            enum file_type type;
            size_t dnlen = strlen(ent->d_name);

            /* Exclude the special directory entries. This test comes
             * high since it kills two stat calls per directory. */
            if (ent->d_name[0] == '.'
                && (dnlen == 1 || (ent->d_name[1] == '.' && dnlen == 2))) {
                continue;
            }

            if (full != NULL) ne_free(full);

            full = ne_concat(this, ent->d_name, NULL);

            if (lstat(full, &item) == -1) {
                fe_warning(_("Could not examine file."), full, strerror(errno));
                continue;
            }

            /* Is this a symlink? */
            if (S_ISLNK(item.st_mode)) {
                NE_DEBUG(DEBUG_FILES, "symlink - ");
                if (site->symlinks == sitesym_ignore) {
                    /* Just skip it */
                    NE_DEBUG(DEBUG_FILES, "ignoring.\n");
                    continue;
                }
                else if (site->symlinks == sitesym_follow) {
                    NE_DEBUG(DEBUG_FILES, "followed - ");
                    /* Else, carry on as normal, stat the real file */
                    if (stat(full, &item) == -1) {
                        /* It's probably a broken link */
                        NE_DEBUG(DEBUG_FILES, "broken.\n");
                        continue;
                    }
                }
                else {
                    NE_DEBUG(DEBUG_FILES, "maintained:\n");
                }
            }

            /* Now process it */

            /* This is the filename of this file - i.e., everything
             * apart from the local root */
            fname = (char *)full+strlen(site->local_root);

            /* Check for excludes */
            if (file_isexcluded(fname, site))
                continue;

            if (S_ISREG(item.st_mode)) {
                switch (site->state_method) {
                case state_timesize:
                    local.time = item.st_mtime;
                    break;
                case state_checksum:
                    if (file_checksum(full, &local, site) != 0) {
                        fe_warning(_("Could not checksum file"), full,
                                    strerror(errno));
                        continue;
                    }
                    break;
                }
                local.size = item.st_size;
                local.ascii = file_isascii(fname, site);
                type = file_file;
            }
            else if (S_ISLNK(item.st_mode)) {
                char tmp[BUFSIZ];
                ssize_t len;

                type = file_link;
                NE_DEBUG(DEBUG_FILES, "symlink being maintained.\n");
                len = readlink(full, tmp, sizeof tmp);
                if (len == -1) {
                    fe_warning(_("The target of the symlink could not be read."),
                               full, strerror(errno));
                    continue;
                }
                local.linktarget = ne_strndup(tmp, len);
            }
            else if (S_ISDIR(item.st_mode)) {
                type = file_dir;
                if (dirtop == dirmax) {
                    /* Grow the stack */
                    dirmax += DIRSTACKSIZE;
                    dirstack = ne_realloc(dirstack, sizeof(char *) * dirmax);
                }
                /* Add it to the search stack */
                dirstack[dirtop] = ne_concat(full, "/", NULL);
                dirtop++;
            }
            else {
                NE_DEBUG(DEBUG_FILES, "something else.\n");
                continue;
            }

            /* Set up rest of the local state */
            local.mode = item.st_mode & 0777;
            local.exists = true;
            local.filename = ne_strdup(fname);

            current = file_set_local(type, &local, site);
            DEBUG_DUMP_FILE_PROPS(DEBUG_FILES, current, site);

        }
        /* Close the open directory */
        closedir(curdir);
        /* And we're finished with this */
        ne_free(this);
    }

    if (full)
        ne_free(full);
    ne_free(dirstack);
}

/* Pretend the remote site is the same as the local site. */
void site_catchup(struct site *site)
{
    struct site_file *current, *next;
    for (current=site->files; current!=NULL; current=next) {
	next = current->next;
	switch (current->diff) {
	case file_deleted:
	    file_delete(site, current);
	    break;
	case file_changed:
	case file_new:
	case file_moved:
	    file_state_copy(&current->stored, &current->local, site);
	    file_set_diff(current, site);
	    break;
	case file_unchanged:
	    /* noop */
	    break;
	}
    }
}

/* Reinitializes the site - clears any remote files
 * from the list, and marks all other files as 'new locally'.
 */
void site_initialize(struct site *site)
{
    /* So simple. Be sure we have our abstraction layers at least
     * half-decent when things fall out this simple. */
    site_destroy_stored(site);
}

/* Munge modtimes of 'file' accordingly; when modtime of file on
 * server is 'remote_mtime'. */
static void munge_modtime(struct site_file *file, time_t remote_mtime,
			  struct site *site)
{
    /* If this is a file, and we are using timesize mode, and we have
     * a local copy of this file already, we have to cope with the
     * modtimes problem.  The problem is that the modtime locally will
     * ALWAYS be different from the modtime on the SERVER.  */
    if (file->type == file_file && site->state_method == state_timesize) {
	if (file->local.exists) {
	    /* If we are in safe mode, we can actually check whether
	     * the remote file has changed or not when we are using
	     * timesize mode, by comparing what we thought the server
	     * modtime was with what the actual (fetched) server
	     * modtime is. Got that? */
	    NE_DEBUG(DEBUG_FILES, "Fetch: %ld vs %ld\n", 
		     file->server.time, remote_mtime);
	    if (site->safemode && file->server.exists &&
		file->server.time != remote_mtime) {
		NE_DEBUG(DEBUG_FILES, 
			 "Fetch: Marking changed file changed.\n");
		file->stored.time = file->local.time + 1;
	    } else {
		NE_DEBUG(DEBUG_FILES, "Fetch: Marking unchanged files same.\n");
		file->stored.time = file->local.time;
	    }
	} else {
	    /* If the local file doesn't exist, pretend the file was
	     * last uploaded "now" (an arbitrary time is adequate, but
	     * "now" is the least confusing). */
	    file->stored.time = time(NULL);
	}

	/* update the diff. */
	file_set_diff(file, site);
    }
}

/* Returns the file type for a protocol driver's file type. */
static enum file_type proto_file_type(enum proto_filetype type)
{
    switch (type) {
    case proto_dir:
        return file_dir;
    case proto_link:
        return file_link;
    case proto_file:
    default:
        return file_file;
    }
}

/* Return a site_file structure given a proto_file structure fetched
 * by the protocol driver. */
static struct site_file *fetch_add_file(struct site *site,
                                        const struct proto_file *pf)
{
    struct site_file *file;
    struct file_state state = {0};

    state.size = pf->size;
    state.time = pf->modtime;
    state.exists = true;
    state.filename = pf->filename;
    state.mode = pf->mode;
    state.ascii = file_isascii(pf->filename, site);
    memcpy(state.checksum, pf->checksum, 16);

    file = file_set_stored(proto_file_type(pf->type), &state, site);

    munge_modtime(file, pf->modtime, site);

    if (site->safemode) {
        /* Store the server modtime. */
        file->server.time = pf->modtime;
        file->server.exists = true;
    }

    return file;
}

static int site_fetch_csum_read(void *userdata, const char *s, size_t len)
{
    struct ne_md5_ctx *md5 = userdata;
    ne_md5_process_bytes(s, len, md5);
    return 0;
}

/* Retrieve the remote checksum for all files */
static int fetch_checksum_file(struct proto_file *file,
                               struct site *site, void *session)
{
    struct ne_md5_ctx *md5;
    char *full_remote = ne_concat(site->remote_root, file->filename, NULL);
    int ret = 0;

    md5 = ne_md5_create_ctx();

    fe_checksumming(file->filename);
    if (CALL(file_read)(session, full_remote,
                        site_fetch_csum_read, md5) != SITE_OK) {
        ret = 1;
        fe_checksummed(full_remote, false, DRIVER_ERR);
    } else {
        ne_md5_finish_ctx(md5, file->checksum);
        fe_checksummed(full_remote, true, NULL);
    }
    free(full_remote);

    ne_md5_destroy_ctx(md5);
    return ret;
}
    
/* Updates the remote file list... site_fetch_callback is called for
 * every remote file found.
 */
/* Frees a list of proto_file structures, and their filenames. */
static void proto_files_free(struct proto_file *files)
{
    struct proto_file *f, *next;

    for (f = files; f; f = next) {
        next = f->next;
        ne_free(f->filename);
        ne_free(f);
    }
}

/* Lists the remote site, walking its directories, and places the
 * files found in *list, with filenames relative to the site root.
 * Excluded directories are not listed.  If 'checksums' is non-zero,
 * each file which isn't excluded is downloaded to calculate its
 * checksum.  Returns SITE_OK on success, SITE_FAILED if a directory
 * could not be listed, or SITE_ERRORS if a file could not be
 * checksummed. */
static int list_remote_files(struct site *site, void *session,
                             int need_modtimes, int checksums,
                             struct proto_file **list)
{
    const char **dirstack;
    size_t dirtop, dirmax = DIRSTACKSIZE;
    struct proto_file *files = NULL;
    int ret = SITE_OK, csum_failed = 0;

    /* The stack of directories still to list, which grows as
     * needed. */
    dirstack = ne_malloc(dirmax * sizeof *dirstack);
    dirtop = 1;
    dirstack[0] = "";

    do {
        struct proto_file *newfiles = NULL, *f, *lastf = NULL;
        const char *reldir;

        if (fe_interrupted()) {
            ret = SITE_INTERRUPTED;
            break;
        }

        reldir = dirstack[--dirtop];
        const char *slash = reldir[0] == '\0' ? "" : "/";
        char *curdir;

        curdir = ne_concat(site->remote_root, reldir, slash, NULL);

        ret = CALL(fetch_list)(session, curdir, need_modtimes, &newfiles);
        if (ret != SITE_OK) {
            ne_free(curdir);
            ret = SITE_FAILED;
            break;
        }

        for (f = newfiles; f; f = f->next) {
            char *relfn;

            relfn = ne_concat(reldir, slash, f->filename, NULL);
            ne_free(f->filename);
            f->filename = relfn;

            if (!file_isexcluded(relfn, site)) {
                if (f->type == proto_dir) {
                    if (dirtop == dirmax) {
                        dirmax += DIRSTACKSIZE;
                        dirstack = ne_realloc(dirstack,
                                              dirmax * sizeof *dirstack);
                    }
                    dirstack[dirtop++] = relfn;
                }
                else if (f->type == proto_file && checksums
                         && !csum_failed) {
                    csum_failed = fetch_checksum_file(f, site, session);
                }
            }

            lastf = f;
        }

        if (lastf) {
            lastf->next = files;
            files = newfiles;
        }

        ne_free(curdir);
    } while (dirtop > 0 && !csum_failed);

    ne_free(dirstack);

    /* Without the checksum of every file, the listing is no use. */
    if (csum_failed)
        ret = SITE_ERRORS;

    *list = files;
    return ret;
}

int site_fetch(struct site *site)
{
    int ret, need_modtimes;
    void *session;
    struct proto_file *files = NULL;

    ret = proto_init(site, &session);
    if (ret != SITE_OK) {
        proto_finish(site, session);
        return ret;
    }

    if (CALL(fetch_list) == NULL) {
        proto_finish(site, session);
        return SITE_UNSUPPORTED;
    }

    /* The remote modtimes are needed if timesize is used or in safe
     * mode: */
    need_modtimes = site->safemode || site->state_method == state_timesize;

    ret = list_remote_files(site, session, need_modtimes,
                            site->state_method == state_checksum, &files);

    if (ret == SITE_OK) {
        struct proto_file *f, *nextf;

        /* Remove existing stored state for the site. */
        site_destroy_stored(site);

        /* And replace it with the fetched state, which takes the
         * filenames. */
        for (f = files; f; f = nextf) {
            if (!file_isexcluded(f->filename, site)) {
                struct site_file *sf = fetch_add_file(site, f);
                fe_fetch_found(sf);
            }
            else {
                ne_free(f->filename);
            }
            nextf = f->next;
            ne_free(f);
        }
    }
    else {
        proto_files_free(files);
        ret = SITE_FAILED;
    }

    proto_finish(site, session);

    return ret;
}

/* Compares files list with files.
 * Returns SITE_OK on match, SITE_ERRORS on no match.
 */
/* Ahhhh, this is crap too.
 * If we had a generic file_set this would be easy and clean and spot
 * moved files too. We need a generic file_set.
 */
static int site_verify_compare(struct site *site,
                               const struct proto_file *files,
                               int *numremoved)
{
    struct site_file *file;
    const struct proto_file *lfile;
    int numremote = 0, mismatch = 0;

    /* Count the files expected on the server; excluded files are
     * skipped in the listing, so are not expected. */
    for_each_file(file, site) {
        numremote += file->stored.exists
            && !file_isexcluded(file->stored.filename, site);
    }

    for (lfile = files; lfile != NULL; lfile = lfile->next) {
        enum file_diff diff = file_new;

        if (file_isexcluded(lfile->filename, site))
            continue;

        numremote--;
        for_each_file(file, site) {
            if (file->stored.exists
                && strcmp(file->stored.filename, lfile->filename) == 0) {
                /* Do a mini file_compare job; only files have
                 * contents to compare. */
                diff = file_unchanged;
                if (file->type != proto_file_type(lfile->type)) {
                    diff = file_changed;
                }
                else if (lfile->type != proto_file) {
                    /* nothing to compare */
                }
                else if (site->state_method == state_checksum) {
                    if (memcmp(file->stored.checksum, lfile->checksum, 16))
                        diff = file_changed;
                }
                else {
                    if (file->stored.size != lfile->size
                        || (site->safemode
                            && file->server.time != lfile->modtime)) {
                        diff = file_changed;
                    }
                }
                break;
            }
        }

        /* If new files were added, adjust the count */
        if (diff == file_new)
            numremote++;

        if (diff != file_unchanged)
            mismatch = 1;

        fe_verified(lfile->filename, diff);
    }

    *numremoved = numremote;

    if (numremote != 0 || mismatch) {
        return SITE_ERRORS;
    }
    else {
        return SITE_OK;
    }
}

/* Compares what's on the server with what we THINK is on the server.
 * Returns SITE_OK if match, SITE_ERRORS if doesn't match.
 */
int site_verify(struct site *site, int *numremoved)
{
    struct proto_file *files = NULL;
    void *session;
    int ret;

    ret = proto_init(site, &session);
    if (ret != SITE_OK) {
        proto_finish(site, session);
        return ret;
    }

    if (CALL(fetch_list) == NULL) {
        proto_finish(site, session);
        return SITE_UNSUPPORTED;
    }

    /* With checksum state, each file must be downloaded to compare
     * its checksum. */
    ret = list_remote_files(site, session, 1,
                            site->state_method == state_checksum, &files);

    proto_finish(site, session);

    if (ret == SITE_OK) {
        /* Return whether they matched or not */
        ret = site_verify_compare(site, files, numremoved);
    }
    else {
        ret = SITE_FAILED;
    }

    proto_files_free(files);
    return ret;
}

/* Destroys the stored state of files in the files list for the given
 * site. Removes any files which do not exist locally from the list. */
void site_destroy_stored(struct site *site)
{
    struct site_file *current, *next;
    current = site->files;
    while (current != NULL) {
	next = current->next;
	if (!current->local.exists) {
	    /* It doesn't exist locally... nuke it */
	    file_delete(site, current);
	} else {
	    /* Just nuke the stored state...
	     * TODO-ngm: verify this. */
	    file_state_destroy(&current->stored);
	    /* Could just do .exists = false */
	    memset(&current->stored, 0, sizeof(struct file_state));
	    /* And set the diff */
	    file_set_diff(current, site);
	}
	current = next;
    }
}

/* Called to delete all the files associated with the site */
void site_destroy(struct site *site)
{
    struct site_file *current, *next;

    current = site->files;
    while (current != NULL) {
	next = current->next;
	file_delete(site, current);
	current = next;
    }

}


/* Produces a section of the flat listing output, of all the items
 * with the given diff type in the given site, using the given section
 * name. */
static void site_flatlist_items(FILE *f, struct site *site,
                                enum file_diff diff, const char *name)
{
    struct site_file *current;
    fprintf(f, "sectstart|%s", name);
    putc('\n', f);
    for_each_file(current, site) {
	if (current->diff == diff) {
	    fprintf(f, "item|%s%s", file_name(current),
		    (current->type==file_dir)?"/":"");
	    if (current->diff == file_moved) {
		fprintf(f, "|%s", current->stored.filename);
	    }
            if (current->ignore)
                fputs("|ignored", f);
            putc('\n', f);
	}
    }
    fprintf(f, "sectend|%s\n", name);
}

/* Produce the flat listing output for the given site */
void site_flatlist(FILE *f, struct site *site)
{
    fprintf(f, "sitestart|%s", site->name);
    if (site->url)	fprintf(f, "|%s", site->url);
    putc('\n', f);
    if (site->numnew > 0)
	site_flatlist_items(f, site, file_new, "added");
    if (site->numchanged > 0)
	site_flatlist_items(f, site, file_changed, "changed");
    if (site->numdeleted > 0)
	site_flatlist_items(f, site, file_deleted, "deleted");
    if (site->nummoved > 0)
	site_flatlist_items(f, site, file_moved, "moved");
    fprintf(f, "siteend|%s\n", site->remote_is_different?"changed":"unchanged");
}

int site_file_cmp_stored(const void *p1, const void *p2)
{
    struct site_file *f1 = *(struct site_file **) p1;
    struct site_file *f2 = *(struct site_file **) p2;

    return strcmp(f1->stored.filename, f2->stored.filename);
}

int site_file_is_stored(const struct site_file *file)
{
    return file->stored.exists;
}

struct site_file **site_sorted_files_list(struct site *site, file_filter_fn filter,
                                          file_cmp_fn compare, unsigned *count)
{
    unsigned num_items = 0, i;
    struct site_file **sorted, *current;

    /* Build the sorted copy.  */
    for (current = site->files; current; current = current->next)
        if (!filter || filter(current))
            num_items++;

    *count = num_items;
    sorted = ne_calloc(num_items * sizeof *sorted);

    for (i = 0, current = site->files; current; current = current->next)
        if (!filter || filter(current))
            sorted[i++] = current;

    qsort(sorted, num_items, sizeof *sorted, compare);

    return sorted;
}

int site_verify_certificate(void *userdata, int failures,
                            const ne_ssl_certificate *cert)
{
    struct site *site = userdata;

    /* A certificate the user accepted before is saved, and accepted
     * again.  Comparing the certificate, rather than trusting the
     * saved certificate as a CA, works for a certificate which is
     * not self-signed too. */
    if (site->server_cert && ne_ssl_cert_cmp(cert, site->server_cert) == 0)
        return 0;

    if (fe_accept_cert(cert, failures)) {
        /* Not accepted by user => fail verification. */
        return -1;
    }

    if (ne_ssl_cert_write(cert, site->certfile)) {
        fe_warning(_("Could not write SSL certificate"),
                   NULL, site->certfile);
    }

    return 0;
}

int site_load_certificate(struct site *site)
{
    if (access(site->certfile, R_OK) != 0)
        return 0;

    site->server_cert = ne_ssl_cert_read(site->certfile);
    return site->server_cert == NULL;
}

void site_sock_progress_cb(void *userdata, ne_off_t progress, ne_off_t total)
{
    fe_transfer_progress(progress, total);
}

void fe_initialize(void)
{
    ne_sock_init();
}
