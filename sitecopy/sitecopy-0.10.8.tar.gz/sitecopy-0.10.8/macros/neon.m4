# Copyright (C) 1998-2000 Joe Orton.  
# This file is free software; you may copy and/or distribute it with
# or without modifications, as long as this notice is preserved.
# This software is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY, to the extent permitted by law; without even
# the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.

# The above license applies to THIS FILE ONLY, the neon library code
# itself may be copied and distributed under the terms of the GNU
# LGPL, see COPYING.LIB for more details

# This file is part of the neon HTTP/WebDAV client library.
# See http://www.webdav.org/neon/ for the latest version. 
# Please send any feedback to <neon@webdav.org>

# Use the m4 macros NEON_INCLUDED_SOURCE to determine whether the neon
# source directory and expat source directories have been bundled.

# After calling NEON_LIBRARY(), if NEON_NEED_XML_PARSER="yes", then
# you must configure an XML parser too. You can do this your own way,
# or do it easily using the NEON_XML_PARSER() macro. Example usage
# for where we have bundled the neon sources in a directory called 
# libneon, and bundled expat sources in a directory called 'expat'.
#
#   define([NEON_INCLUDED_SOURCE],[libneon])
#   NEON_LIBRARY()
#   if test "$NEON_NEED_XML_PARSER" = "yes"; then
#       NEON_XML_PARSER(expat)
#   fi
#
# You are free to configure an XML parser any other way you like,
# but the end result must be, either expat or libxml will get linked
# in, and HAVE_EXPAT or HAVE_LIBXML is defined appropriately.
#
# Usage:
# NEON_LIBRARY()
# If a neon library is not found, $NEONOBJS will be added to LIBOBJS.
# You should set NEONOBJS to the minimal set of neon object files you
# require, e.g.:
#    NEONOBJS="libneon/http_request.o libneon/http_config.o \
#	libneon/string_utils.o libneon/xalloc.o libneon/socket.o \
#	libneon/http_auth.o libneon/dates.o libneon/base64.o"

# The function defines two variables which can be used to describe
# to the user how the build has been configured:
#    neon_library_message     : for neon overall

AC_DEFUN([NEON_LIBRARY],[

AC_ARG_WITH(neon,
	[  --with-neon	          Specify location of neon library ],
	[neon_loc="$withval"])

ifdef([NEON_INCLUDED_SOURCE],
	AC_ARG_WITH(included-neon,
	[  --with-included-neon    Force use of included neon library ],
 	[neon_force_included="$withval"],
 	[neon_force_included="no"])
,
# No neon source included 
neon_force_included=no
)

AC_MSG_CHECKING(for neon location)

if test "$neon_force_included" = "no"; then
    # We don't have an included neon source directory,
    # or they aren't force us to use it.

    if test -z "$neon_loc"; then
	# Look in standard places
	for d in /usr /usr/local; do
	    if test -x $d/bin/neon-config; then
		neon_loc=$d
	    fi
	done
    fi

    if test -x $neon_loc/bin/neon-config; then
	# Found it!
	AC_MSG_RESULT(found in $neon_loc)
	NEON_CONFIG=$neon_loc/bin/neon-config
	CFLAGS="$CFLAGS `$NEON_CONFIG --cflags`"
	LIBS="$LIBS `$NEON_CONFIG --libs`"
	neon_library_message="library in $neon_loc"
	neon_xml_parser_message="using whatever libneon uses"
    else
	ifdef([NEON_INCLUDED_SOURCE],
	    # Couldn't find neon, forced to use bundled sources
	    neon_force_included="yes",
	    # Couldn't find neon, and don't have bundled sources
	    AC_MSG_ERROR(could not find neon)
	)
    fi
fi

# This isn't a simple 'else' branch, since neon_force_included
# is set to yes if the search fails.

if test "$neon_force_included" = "yes"; then
    AC_MSG_RESULT(using supplied)
    dnl The NEON_INCLUDED_SOURCE below looks weird, but m4
    dnl groks it, so believe in it...
    CFLAGS="$CFLAGS -I"NEON_INCLUDED_SOURCE
    LIBNEON_SOURCE_CHECKS
    LIBOBJS="$LIBOBJS \$(NEONOBJS)"
    neon_library_message="included libneon"
    NEON_NEED_XML_PARSER=yes
else
    # Don't need to configure an XML parser
    NEON_NEED_XML_PARSER=no
fi

])

dnl Call these checks when compiling the libneon source package.

AC_DEFUN([LIBNEON_SOURCE_CHECKS],[

AC_CHECK_HEADERS(stdarg.h string.h strings.h sys/time.h regex.h \
	stdlib.h unistd.h limits.h sys/select.h)

AC_REPLACE_FUNCS(strcasecmp)

AC_SEARCH_LIBS(gethostbyname, nsl)

AC_SEARCH_LIBS(socket, socket inet)

NEON_SSL()

])

dnl Call to put lib/snprintf.o in LIBOBJS and define HAVE_SNPRINTF_H
dnl if snprintf isn't in libc.

AC_DEFUN([NEON_REPLACE_SNPRINTF], [

dnl Check for snprintf
AC_CHECK_FUNC(snprintf,,
	AC_DEFINE(HAVE_SNPRINTF_H, 1, [Define if need to include snprintf.h])
	LIBOBJS="$LIBOBJS lib/snprintf.o" )

])
