/* 
   sitecopy, for managing remote web sites. Stored state handling routines.
   Copyright (C) 1999, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   $Id: sitestore.c,v 1.26.2.2 2000/02/01 15:43:27 joe Exp $
*/

#include <config.h>

#include <sys/stat.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif

#include <ctype.h>
#include <errno.h>
#include <stdio.h>

#include <xmlparse.h>

#include "dates.h"

#include "common.h"
#include "sitesi.h"

/* UTF-8 decoding */

/* Single byte range 0x00 -> 0x7F */
#define SINGLEBYTE_UTF8( ch ) ( ((unsigned char) (ch)) < 0x80 )

/* Decode a double byte UTF8 string.
 * Returns 0 on success or non-zero on error. */
static inline int decode_utf8_double( char *dest, const char *src );

/* This is the string used in the old-style storage files to indicate
 * the line is a directory rather than a file */
#define DIRWORD "dir"
/* And this is used for links */
#define LINKWORD "link"

/* Use a version in the site state file: 
 * Bump the major number if a backwardly-incompatible change is made.
 */
#define SITE_STATE_FILE_VERSION "1.0"

#define CDATABUFSIZ 128
#define CDATASHRINK 256

static int site_read_stored_state_old( struct site *site, FILE *fp );
static int site_read_stored_state_new( struct site *site, FILE *fp );

void site_xml_endelm( void *userdata, const char *tag );
void site_xml_startelm( void *userdata, const char *tag, const char **atts );
void site_xml_cdata( void *userdata, const char *cdata, int len );
enum site_xml_tag site_xml_get_tag( const char *tagname );

static inline int 
decode_utf8_double( char *dest, const char *src ) 
{
    /* From utf-8 man page; two-byte encoding is:
     *    0x00000080 - 0x000007FF:
     *       110xxxxx 10xxxxxx
     * If more than 8-bits of those x's are set, we fail.
     * So, we check that the first 6 bits of the first byte are:
     *       110000.
     * Then decode like:
     *       110000xx 10yyyyyy  -> xxyyyyyy
     * Do this with a mask and a compare:
     *       zzzzzzzz
     *     & 11111100  <=> 0xFC
     *    == 11000000  <=> 0XC0    
     * 
     * joe: A real C hacker would probably do some funky bit
     * inversion, and turn this into an is-not-zero test, 
     * but I'm a fake, so...
     */
    if( (src[0] & 0xFC) == 0xC0 ) {
	dest[0] = ((src[0] & 0x03) << 6) | (src[1] & 0x3F) ;
	return 0;
    } else {
	return -1;
    }
}
	
int site_read_stored_state( struct site *site ) {
    FILE *fp;
    char buffer[6];
    int ret;

    DEBUG( DEBUG_FILES, "Reading info file: %s\n", site->infofile );
    fp = fopen( site->infofile, "r" );
    if( fp == NULL ) {
	struct stat st;
	ret = stat( site->infofile, &st );
	if( (ret == 0) || (errno != ENOENT) ) {
	    /* The file exists but could not be opened for reading...
	     * this is an error condition. */
	    DEBUG( DEBUG_FILES, "Stat failed %s\n", strerror(errno) );
	    return SITE_ERRORS;
	} else {
	    DEBUG( DEBUG_FILES, "Info file doesn't exist.\n" );
	    return SITE_FAILED;
	}
    }
    /* To work out whether the file is old-style or new-style,
     * we try to read in 5 bytes from the file. */
    if( fgets( buffer, 6, fp ) == NULL ) {
	/* Empty file... 'no' files remotely */
	DEBUG( DEBUG_FILES, "Empty storage file.\n" );
	return SITE_OK;
    }
    /* Put the file pointer so they can we the whole file */
    rewind( fp );
    if( strncasecmp( buffer, "<?xml", 5 ) == 0 ) {
	/* XML-format */
	DEBUG( DEBUG_FILES, "New-style XML storage file.\n" );
	ret = site_read_stored_state_new( site, fp );
    } else {
	/* Old-style */
	DEBUG( DEBUG_FILES, "Old-style storage file.\n" );
	ret = site_read_stored_state_old( site, fp );
    }
    fclose( fp );
    return ret;
}

#define EOL "\r\n"

/* Write out the stored state for the site. 
 * Returns 0 on success, non-zero on error. */
int site_write_stored_state( struct site *site ) {
    FILE *fp;
    struct site_file *current;
#if defined(__CYGWIN__) || defined(__EMX__)
    fp = fopen( site->infofile, "wb" );
#else
    fp = fopen( site->infofile, "w" );
#endif
    if( fp == NULL ) {
	return -1;
    }
    fprintf( fp, "<?xml version=\"1.0\"?>" EOL );
    /* TODO: DTD */
    fprintf( fp, "<sitestate version=\"" SITE_STATE_FILE_VERSION "\">" EOL );
    fprintf( fp, "<options>" EOL );
    fprintf( fp, " <saved-by package=\"" PACKAGE "\" version=\"" VERSION "\"/>" EOL );
    if( site->state_method == state_checksum ) {
	/* For forwards-compatibility */
	fprintf( fp, " <checksum-algorithm><checksum-MD5/></checksum-algorithm>" EOL );
    }
    fprintf( fp, " <state-method><state-%s/></state-method>" EOL,
	     (site->state_method==state_checksum)?"checksum":"timesize" );
    if( site->safemode ) {
	fprintf( fp, " <safemode/>" EOL );
    }
    fprintf( fp, "</options>" EOL );
    fprintf( fp, "<items>" EOL );
    /* Now write out the items */
    for( current = site->files; current!=NULL; current = current->next ) {
	unsigned const char *pnt;
	if( !current->stored.exists ) continue;
	fprintf( fp, "<item>" );
	fprintf( fp, "<type><type-%s/></type>",
		 (current->type==file_file)?"file":(
		     (current->type==file_dir)?"directory":"link" ) );
	fprintf( fp, "<filename>" );
	/* Filenames can contain all sorts of cruft, so we write
	 * out XML character references; "&#x" <HEX><HEX> ";" 
	 */
	for( pnt = current->stored.filename; *pnt!='\0'; pnt++ ) {
	    /* Don't escape alphanumerics, '/' and '.'... could be
	     * more clever here, but it's safe to be stupid. */
	    if( isalnum( *pnt ) || *pnt == '/' || *pnt == '.' || *pnt == '-' ) { 
		fputc( *pnt, fp );
	    } else {
		fprintf( fp, "&#x%c%c;", HEXD2asc((*pnt&0xf0)>>4), 
			 HEXD2asc(*pnt&0x0f) );
	    }
	}
	fprintf( fp, "</filename>" EOL );
	switch( current->type ) {
	case file_link:
	    fprintf( fp, "<linktarget>%s</linktarget>", 
		     current->stored.linktarget );
	    break;
	case file_file:
	    fprintf( fp, "<protection>%03o</protection>", 
		     current->stored.mode ); /* three-digit octal */
	    fprintf( fp, "<size>%ld</size>", current->stored.size );
	    switch( site->state_method ) {
	    case state_checksum: {
		char csum[33];
		md5_hexify( current->stored.checksum, csum );
		fprintf( fp, "<checksum>%s</checksum>", csum );
	    } break;
	    case state_timesize:
		fprintf( fp, "<modtime>%ld</modtime>", current->stored.time );
		break;
	    }
	    fprintf( fp, "<ascii>%s</ascii>",
		     current->stored.ascii?"<true/>":"<false/>" );
	    if( current->server.exists ) {
		fprintf( fp, "<server-modtime>%ld</server-modtime>", 
			 current->server.time );
	    }
	    break;
	case file_dir:
	    /* nothing to do */
	    break;
	}
	fprintf( fp, "</item>" EOL );
    }
    fprintf( fp, "</items>" EOL );
    fprintf( fp, "</sitestate>" EOL );
    site->stored_state_method = site->state_method;
    if( fclose( fp ) == 0 ) {
	return 0;
    } else {
	return -1;
    }
}

#undef EOL

/* XML is parsed just like in httpdav.c.  We could build a complete
 * document tree, then traverse it, but would be slow, and
 * inefficient. This way is a real bore to code, but is nice and fast.  
 */

static const char *site_xml_elm_names[] = {
    "sitestate",
    "options",
    "saved-by",
    "checksum-algorithm",
    "checksum-MD5",
    "state-method",
    "state-timesize",
    "state-checksum",
    "items",
    "item",
    "type",
    "type-file",
    "type-directory",
    "type-link",    
    "filename",
    "size",
    "modtime",
    "ascii",
    "linktarget",
    "checksum",
    "protection",
    "server-modtime",
    "true",
    "false",
    NULL, /* unknown */
    "@<root>@", /* filler for root */
};

enum site_xml_tag {
    site_xml_elm_sitestate,
    site_xml_elm_options,
    site_xml_elm_opt_saved_by,
    site_xml_elm_opt_checksum,
    site_xml_elm_opt_checksum_md5,
    site_xml_elm_opt_state_method,
    site_xml_elm_opt_state_method_timesize,
    site_xml_elm_opt_state_method_checksum,
    site_xml_elm_items,
    site_xml_elm_item,
    site_xml_elm_type,
    site_xml_elm_type_file,
    site_xml_elm_type_directory,
    site_xml_elm_type_link,
    site_xml_elm_filename,
    site_xml_elm_size,
    site_xml_elm_modtime,
    site_xml_elm_ascii,
    site_xml_elm_linktarget,
    site_xml_elm_checksum,
    site_xml_elm_protection,
    site_xml_elm_server_modtime,
    site_xml_true,
    site_xml_false,
    site_xml_elm_unknown,
    site_xml_elm_root
};

struct site_xml_elm {
    enum site_xml_tag tag;
    struct site_xml_elm *child;
    struct site_xml_elm *parent;    
};

struct site_xmldoc {
    struct site_xml_elm *root;
    struct site_xml_elm *current;
    struct site *site;
    char *cdata; /* cdata buffer */
    size_t cdata_buflen; /* length of buffer */
    size_t cdata_len; /* actual length of data in buffer */
    bool want_cdata;
    bool valid;
    /* What we've collected so far */
    enum file_type type;
    struct file_state stored;
    struct file_state server;
    short truth; /* 0: invalid, 1: true, 2: false */
};

/* Copied straight from httpdav.c:dav_xml_cdata() */
void site_xml_cdata( void *userdata, const char *cdata, int len ) {
    struct site_xmldoc *doc = userdata;
    int n, m;
    size_t newlen;

    if( !doc->want_cdata ) return;
    /* First, if this is the beginning of the CDATA, skip all
     * leading whitespace, we don't want it. */
    if( doc->cdata_buflen < 0  ) {
	DEBUG( DEBUG_XML, "ALERT: Shouldn't be collecting.\n" );
	return;
    }
    DEBUG( DEBUG_XML, "Given %d bytes of cdata.\n", len );
    if( doc->cdata_len == 0 ) {
	size_t wslen = 0;
	/* Ignore any leading whitespace */
	while( wslen < len && 
	       ( cdata[wslen] == ' ' || cdata[wslen] == '\r' ||
		 cdata[wslen] == '\n' || cdata[wslen] == '\t' ) ) {
	    wslen++;
	}
	cdata += wslen;
	len -= wslen;
	DEBUG( DEBUG_XML, "Skipped %d bytes of leading whitespace.\n", 
	       wslen );
	if( len == 0 ) {
	    DEBUG( DEBUG_XML, "Zero bytes of content.\n" );
	    return;
	}
    }
    /* Work out whether we need to expand the cdata buffer to
     * include the new incoming cdata. We always keep one more
     * byte in the buffer than we need, for the null-terminator */
    for( newlen = doc->cdata_buflen; 
	 newlen < (doc->cdata_len + len + 1);
	 newlen += CDATABUFSIZ ) /* nullop */ ;
    if( newlen > doc->cdata_buflen ) { 
	size_t oldbuflen = doc->cdata_buflen;
	/* Reallocate bigger buffer */
	DEBUG( DEBUG_XML, "Growing CDATA buffer from %d to %d.\n",
	       oldbuflen, newlen );
	doc->cdata = realloc( doc->cdata, newlen );
	doc->cdata_buflen = newlen;
	/* Zero-out the new bit of buffer */
	memset( doc->cdata+oldbuflen, 0, newlen-oldbuflen );
    }
    /* Now copy the CDATA onto the end of the buffer.
     * expat encodes non-7-bit characters using UTF-8, so
     * we have to decode them.
     *
     * In the loop, n indexes the original cdata, and
     * m indexes the decoded cdata.
     */
    m = doc->cdata_len;
    for( n = 0; n < len; n++ ) {
	if( SINGLEBYTE_UTF8( cdata[n] ) ) {
	    doc->cdata[m++] = cdata[n];
	} else {
	    /* An optimisation here: we only deal with 8-bit 
	     * data, which will be encoded as two bytes of UTF-8 */
	    if( (len - n < 2) ||
		decode_utf8_double( &doc->cdata[m], &cdata[n] ) ) {
		/* Failed to decode! */
		DEBUG( DEBUG_XML, "Could not decode UTF-8 data.\n" );
		doc->valid = false;
		return;
	    } else {
		DEBUG( DEBUG_XML, "UTF-8 two-bytes decode: "
		       "0x%02hx 0x%02hx -> 0x%02hx!\n",
		       cdata[n], cdata[n+1], doc->cdata[m] );
		n += 2;
		m++;
	    }
	}
    }
    doc->cdata_len = m;
    DEBUG( DEBUG_XML, "Collected %d bytes of cdata, buffer now:\n%s\n",
	   len, doc->cdata );

};

enum site_xml_tag site_xml_get_tag( const char *tagname ) {
    int n;
    for( n = 0; site_xml_elm_names[n] != NULL; n++ ) {
	if( strcmp( site_xml_elm_names[n], tagname ) == 0 ) {
	    return n;
	}
    }
    return site_xml_elm_unknown;
}

void site_xml_startelm( void *userdata, const char *tag, const char **atts ) {
    struct site_xmldoc *doc = userdata;
    struct site_xml_elm *elm;
    
    DEBUG( DEBUG_XML, "Start: %s\n", tag);
    if( !doc->valid ) {
	DEBUG( DEBUG_XML, "skipping... not valid.\n" );
	return;
    }

    elm = malloc( sizeof(struct site_xml_elm) );
    memset( elm, 0, sizeof(struct site_xml_elm) );
    elm->tag = site_xml_get_tag( tag );
#ifdef DEBUGGING
    if( elm->tag == site_xml_elm_unknown ) {
	DEBUG( DEBUG_XML, "Got unknown tag.\n" );
    } else {
	DEBUG( DEBUG_XML, "Got tag: %s\n", site_xml_elm_names[elm->tag] );
    }
#endif DEBUGGING
    doc->current->child = elm;
    elm->parent = doc->current;
    doc->current = elm;
    /* Validate it... when expat is a validating parser, and we
     * have a DTD, we won't need to do this. */

    /* We could do this with a lookup table, but that would be hell
     * to maintain/get-working without having the table generated
     * programmatically, and that would take too long.
     */
    switch( elm->parent->tag ) {
    case site_xml_elm_root:
	if( elm->tag != site_xml_elm_sitestate )
	    doc->valid = false;
	break;
    case site_xml_elm_sitestate:
	switch( elm->tag ) {
	case site_xml_elm_options:
	case site_xml_elm_items:
	    break;
	default:
	    doc->valid = false;
	}
	break;
    case site_xml_elm_options:
	switch( elm->tag ) {
	case site_xml_elm_opt_saved_by:
	case site_xml_elm_opt_checksum:
	case site_xml_elm_opt_state_method:
	case site_xml_elm_unknown: /* and anything we don't understand */
	    break;
	default:
	    doc->valid = false;
	}
	break;
    case site_xml_elm_opt_checksum:
	if( elm->tag != site_xml_elm_opt_checksum_md5 )
	    doc->valid = false;
	break;
    case site_xml_elm_opt_state_method:
	switch( elm->tag ) {
	case site_xml_elm_opt_state_method_checksum:
	case site_xml_elm_opt_state_method_timesize:
	    break;
	default:
	    doc->valid = false;
	}
	break;
    case site_xml_elm_items:
	if( elm->tag != site_xml_elm_item )
	    doc->valid = false;
	break;
    case site_xml_elm_item:
	switch( elm->tag ) {
	case site_xml_elm_type:
	case site_xml_elm_filename:
	case site_xml_elm_checksum:
	case site_xml_elm_linktarget:
	case site_xml_elm_protection:
	case site_xml_elm_size:
	case site_xml_elm_modtime:
	case site_xml_elm_unknown:
	case site_xml_elm_server_modtime:
	case site_xml_elm_ascii:
	    break;	    
	default:
	    doc->valid = false;
	}
	break;
    case site_xml_elm_type:
	switch( elm->tag ) {
 	case site_xml_elm_type_file:
 	case site_xml_elm_type_directory:
 	case site_xml_elm_type_link:
	    break;
	default:
	    doc->valid = false;
	}
	break;
    case site_xml_elm_opt_saved_by:
	/* allow for putting stuff in here */
	if( elm->tag != site_xml_elm_unknown ) 
	    doc->valid = false;
	break;
    case site_xml_elm_unknown:
	/* allow for extensions */
	if( elm->tag != site_xml_elm_unknown )
	    doc->valid = false;
	break;
	/* Now, stuff we only allow cdata in, or nothing at all */
    case site_xml_elm_ascii:
	switch( elm->tag ) {
	case site_xml_true:
	case site_xml_false:
	    break;
	default:
	    doc->valid = false;
	}
	break;
    case site_xml_elm_server_modtime:
    case site_xml_elm_type_file:
    case site_xml_elm_type_directory:
    case site_xml_elm_type_link:
    case site_xml_true:
    case site_xml_false:
    case site_xml_elm_opt_checksum_md5:
    case site_xml_elm_opt_state_method_checksum:
    case site_xml_elm_opt_state_method_timesize:
    case site_xml_elm_filename:
    case site_xml_elm_checksum:
    case site_xml_elm_linktarget:
    case site_xml_elm_protection:
    case site_xml_elm_size:
    case site_xml_elm_modtime:
	doc->valid = false;
    }

    if( !doc->valid ) {
	DEBUG( DEBUG_XML, "Not valid!\n" ); 
	return;
    } else {
	DEBUG( DEBUG_XML, "Valid!\n" );
    }

    /* Now, actually do something with what we've got */
    switch( elm->tag ) {
    case site_xml_elm_filename:
    case site_xml_elm_checksum:
    case site_xml_elm_linktarget:
    case site_xml_elm_protection:
    case site_xml_elm_server_modtime:
    case site_xml_elm_size:
    case site_xml_elm_modtime:
	doc->want_cdata = true;
	break;
    default:
	break;
    }
    
    if( doc->want_cdata ) {
	/* Ready the cdata buffer for new cdata */
	if( doc->cdata_buflen == -1 ) {
	    /* Create a buffer */
	    DEBUG( DEBUG_XML, "Allocating new cdata buffer.\n" );
	    doc->cdata = malloc( CDATABUFSIZ );
	    doc->cdata_buflen = CDATABUFSIZ;
	}
	/* Now zero-out the buffer. */
	memset( doc->cdata, 0, doc->cdata_buflen );
	/* And we've got nothing in it */
	doc->cdata_len = 0;
    }


}

void site_xml_endelm( void *userdata, const char *tag ) {
    struct site_xmldoc *doc = userdata;
    struct site_xml_elm *elm;

    DEBUG( DEBUG_XML, "End: %s\n", tag );
    if( !doc->valid ) {
	DEBUG( DEBUG_XML, "skipping... not valid.\n" );
	return;
    }

    elm = doc->current;
    
    /* Dispatch Ajax */
    switch( elm->tag ) {
    case site_xml_elm_opt_state_method_timesize:
	doc->site->stored_state_method = state_timesize;
	break;
    case site_xml_elm_opt_state_method_checksum:
	doc->site->stored_state_method = state_checksum;
	break;
    case site_xml_elm_type_file:
	doc->type = file_file;
	break;
    case site_xml_elm_type_directory:
	doc->type = file_dir;
	break;
    case site_xml_elm_type_link:
	doc->type = file_link;
	break;
    case site_xml_elm_filename:
	DEBUG( DEBUG_XML, "Cdata: %s\n", doc->cdata );
	doc->stored.filename = strdup( doc->cdata );
	break;
    case site_xml_elm_checksum:
	if( doc->cdata_len > 32 ) {
	    /* FIXME: error */
	    doc->valid = false;
	} else {
	    /* FIXME: validate */
	    md5_unhexify( doc->cdata, doc->stored.checksum );
#ifdef DEBUGGING
	    {
		char tmp[33];
		md5_hexify( doc->stored.checksum, tmp );
		DEBUG( DEBUG_XML, "Recoded: [%32s]\n", tmp );
	    }
#endif DEBUGGING
	}
	break;
    case site_xml_elm_size:
	/* FIXME: validate. FIXME: strtoUl? */
	doc->stored.size = strtoul( doc->cdata, NULL, 10 );
	break;
    case site_xml_elm_protection:
	/* FIXME: validate */
	doc->stored.mode = strtoul( doc->cdata, NULL, 8 );
	break;
    case site_xml_elm_server_modtime:
	/* FIXME: validate. */
	doc->server.time = strtol( doc->cdata, NULL, 10 );
	break;
    case site_xml_elm_modtime:
	/* FIXME: validate */
	doc->stored.time = strtol( doc->cdata, NULL, 10 );
	break;
    case site_xml_true:
	doc->truth = 1;
	break;
    case site_xml_false:
	doc->truth = 2;
	break;
    case site_xml_elm_ascii:
	if( doc->truth ) {
	    doc->stored.ascii = (doc->truth==1);
	} else {
	    /* Never got a true or false element -> invalid */
	    doc->valid = false;
	}
	break;
    case site_xml_elm_linktarget:
	doc->stored.linktarget = strdup( doc->cdata );
	break;
    case site_xml_elm_item: {
	struct site_file *file;
	/* Gordon's aliiiiiveeeeee... */
	doc->stored.exists = true;
	DEBUG( DEBUG_XML, "Calling file_set_stored NOW.\n" );
	file = file_set_stored( doc->type, &doc->stored, doc->site );
	DEBUG_DUMP_FILE( DEBUG_FILES, file );
	if( doc->server.exists ) {
	    file_state_copy( &file->server, &doc->server );
	}
    }	break;
    case site_xml_elm_opt_state_method:
    case site_xml_elm_opt_checksum:
    case site_xml_elm_opt_checksum_md5:
    case site_xml_elm_opt_saved_by:
    case site_xml_elm_sitestate:
    case site_xml_elm_type:
    case site_xml_elm_root:
    case site_xml_elm_options:
    case site_xml_elm_items:
    case site_xml_elm_unknown:
	break;
    }

    if( doc->want_cdata ) {
	/* Free the cdata buffer if it's grown to big for its boots. */
	if( doc->cdata_buflen > CDATASHRINK ) {
	    DEBUG( DEBUG_XML, "cdata buffer overgrown, freeing.\n" );
	    free( doc->cdata );
	    doc->cdata_buflen = -1;
	} 
	/* And we've stopped collecting it now, thanks */
	doc->want_cdata = false;
    }

    if( elm->parent != NULL ) {
	/* Not in the top-level element */
	doc->current = elm->parent;
	free( elm );
    }

}

/* Read a new XML-format state storage file */
static int site_read_stored_state_new( struct site *site, FILE *fp ) {
    XML_Parser p;
    struct site_xmldoc doc = {0};
    struct site_xml_elm root = {0};
    char buffer[BUFSIZ];
    int len, ret;
    
    doc.current = doc.root = &root;
    doc.valid = true;
    doc.cdata_buflen = -1; /* not yet allocated */
    doc.site = site;
    root.parent = NULL;
    root.tag = site_xml_elm_root;
    
    p = XML_ParserCreate( NULL );
    XML_SetElementHandler( p, site_xml_startelm, site_xml_endelm );
    XML_SetCharacterDataHandler( p, site_xml_cdata );
    XML_SetUserData( p, (void *) &doc );
    
    ret = 0;
    do {
	len = fread( buffer, 1, BUFSIZ, fp );
	if( len < BUFSIZ ) {
	    if( feof( fp ) ) {
		DEBUG( DEBUG_XML, "End of file.\n" );
		ret = 1;
	    } else if( ferror( fp ) ) {
		ret = -1;
		/* And don't parse anything else... */
		break;
	    }
	}
	DEBUG( DEBUG_XML, "Parsing %d bytes (end of file: %s).\n", len,
	       (ret==0)?"false":"true" );
	if( XML_Parse( p, buffer, len, ret ) == 0 )
	    ret = -2;
    } while( ret == 0 );
    
    switch( ret ) {
    case -2:
	/* TODO: output expat's error string */
	DEBUG( DEBUG_XML, "Parse error %s", 
	       XML_ErrorString(XML_GetErrorCode(p)));
	ret = SITE_ERRORS;
	break;
    case 1:
	/* Got to end-of-file okay */
	if( doc.valid ) {
	    ret = SITE_OK;
	} else {
	    ret = SITE_ERRORS;
	}
	break;
    case -1:
	ret = SITE_ERRORS;
    default:
	break;
    }

    XML_ParserFree( p );

    return ret;    
}

/* Read an old-format state storage file */
static int site_read_stored_state_old( struct site *site, FILE *fp ) {
    char buf[BUFSIZ], /* for the line */
	tmp[BUFSIZ], /* for the current field */
	*pos, /* for the current position within buf */
	*point; /* for the curpos within tmp */
    struct file_state stored_state;
    enum file_type type;
    bool got_type;
    int state;
    /* That's all we can do */
    site->stored_state_method = state_timesize;
    /* The file exists, so read it.
     * Format: one item / line, tab-separated fields.
     * First field is filename of item.
     * Second field is 'dir' for directory items, or mtime for files
     * Third field (files only) is size of file */
    while( fgets( buf, BUFSIZ, fp) != NULL ) {
	/* Create a new file item and lob it on the end of the linked 
	 * list */
	/* Make sure we have an end-of-buffer */
	buf[BUFSIZ-1] = '\0';
	memset( &state, 0, sizeof(struct file_state) );
	/* Now parse the line. Simple DFA, states are:
	 *  0: Reading filename, field 1
	 *  1: Reading date/time stamp or DIRWORD, field 2
	 *  2: Reading file size, field 3 (if file)
	 *  3: Junk state - consume-all-crud-till-end-of-line.
	 * 
	 * We read the current field into tmp char by char.
	 * point is the current point within tmp. */
	state = 0;
	got_type = false;
	point = tmp;
	for( pos = buf; *pos!='\0'; pos++ ) {
	    if( *pos < 0 ) state = 5;
	    switch( state ) {
	    case 0:
		if( *pos == '\t' ) {
		    /* End of the filename */
		    *point = '\0';
		    /* +1 to skip the leading / */
		    stored_state.filename = strdup( tmp + 1 );
		    point = tmp;
		    state = 1;
		} else {
		    /* Still in the filename */
		    *(point++) = *pos;
		}
		break;
	    case 1:
		if( *pos == '\t' || *pos == '\n' ) {
		    /* End of the second field */
		    *point = '\0';
		    if( strlen( tmp ) > 0 ) {
			if( strcmp( tmp, DIRWORD ) == 0 ) {
			    /* It's a directory! */
			    type = file_dir;
			    state = 3; /* that's all we need */
			} else if( strcmp( tmp, LINKWORD ) == 0 ) {
			    type = file_link;
			    point = tmp;
			    state = 4; /* read the link target */
			} else {
			    /* It's a file! - field 2 is the mtime */
			    type = file_file;
			    stored_state.time = atol( tmp );
			    point = tmp;
			    state = 2;
			}
			got_type = true;
		    } else {
			/* Corrupt line, we need at least two fields */
			/* FIXME: Report this to the user. */
			state = 5;
		    }			
		} else {
		    /* Within the second field */
		    *(point++) = *pos;
		}
		break;
	    case 2:
		if( *pos == '\n' ) {
		    /* End of the size field */
		    *point = '\0';
		    stored_state.size = atol( tmp );
		    state = 3;
		} else {
		    /* Within the file size field */
		    *(point++) = *pos;
		}
		break;
	    case 3: /* junk state */
		break;
	    case 4: /* read the link name */
		if( *pos == '\n' ) {
		    /* End of the field */
		    *point = '\0';
		    stored_state.linktarget = strdup( tmp );
		    state = 3;
		} else {
		    *(point++) = *pos;
		}
	    case 5: /* error state */
		break;
	    }
	}
	if( (state == 5) || (stored_state.filename == NULL) || (!got_type) ) {
	    /* FIXME: quit */
	    DEBUG( DEBUG_FILES, "Corrupt line.\n" );
	    return SITE_ERRORS;
	} else {
	    struct site_file *current;
	    stored_state.exists = true;
	    current = file_set_stored( type, &stored_state, site );
	    DEBUG_DUMP_FILE_PROPS( DEBUG_FILES, current, site );
	}
    }
    return SITE_OK;
}

