/* 
   HTTP/1.1 methods
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

*/

#ifndef HTTP_BASIC_H
#define HTTP_BASIC_H

#include "config.h"

#include <sys/types.h> /* for time_t */

#include <stdio.h> /* for FILE * */

int http_getmodtime( http_session *sess, const char *uri, time_t *modtime );
int http_put( http_session *sess, const char *uri, FILE *f );
int http_put_if_unmodified( http_session *sess, const char *uri,
			    FILE *stream, time_t since );
int http_read_file( http_session *sess, const char *uri, 
		    http_block_reader reader, void *userdata );
int http_get( http_session *sess, const char *uri, FILE *f );

typedef struct {
    const char *type, *subtype;
    const char *charset;
    char *value;
} http_content_type;   

/* Sets (*http_content_type)userdata appropriately. Free ->value after use */
void http_content_type_handler( void *userdata, const char *value );

#if 0 /* TODO: unimplemented */

typedef http_content_range {
    long start, end, total;
} http_content_range;

/* This will write to the CURRENT position of f; so if you want
 * to do a resume download, use:
 *      struct http_content_range range;
 *      range.start = resume_from; 
 *      range.end = range.total = 1000;
 *      fseek( myfile, resume_from, SEEK_SET );
 *      http_get_range( sess, uri, &range, myfile );
 */
int http_get_range( http_session *sess, const char *uri, 
		    http_content_range *range, FILE *f );

#endif

typedef struct {
    unsigned int broken_expect100:1;
    unsigned int dav_class1;
    unsigned int dav_class2;
    unsigned int dav_executable;
} http_server_capabilities;

int http_options( http_session *sess, const char *uri, 
		  http_server_capabilities *caps );

#endif
