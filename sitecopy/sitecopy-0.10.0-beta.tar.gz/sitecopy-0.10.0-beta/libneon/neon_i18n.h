
#ifdef HAVE_I18N
#include "i18n.h"
#else
#define _(str) (str)
#define N_(str) (str)
#endif
