/* 
   WebDAV 207 multi-status response handling
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

*/

#ifndef DAV207_H
#define DAV207_H

#include "hip_xml.h"
#include "http_utils.h" /* for struct http_status */

struct dav_207_parser_s;
typedef struct dav_207_parser_s dav_207_parser;

/* The handler structure: you provide a set of callbacks.
 * They are called in the order they are listed... start/end_prop
 * multiple times before end_prop, start/end_propstat multiple times
 * before an end_response, start/end_response multiple times.
 */

/* TODO: do we need to pass userdata to ALL of these? We could get away with
 * only passing the userdata to the start_'s and relying on the caller
 * to send it through as the _start return value if they need it. */

typedef void *(*dav_207_start_response)( void *userdata, const char *href );
typedef void (*dav_207_end_response)( 
    void *userdata, void *response, const char *status_line, const http_status *status );

typedef void *(*dav_207_start_propstat)( void *userdata, void *response );
typedef void (*dav_207_end_propstat)( 
    void *userdata, void *propstat, const char *status_line, const http_status *status, 
    const char *description );

typedef void *(*dav_207_start_prop)( void *userdata, void *propstat,
				     const char *name, const hip_xml_char **atts );
typedef void (*dav_207_end_prop)( void *userdata, void *prop,
				  const char *cdata );

/* TODO: extend to allow handling sub-elements within properties...
 * need to extend the XML layer to dynamically determine whether to
 * COLLECT the sub-elements or call the handlers for them?
 */

/* Create a 207 parser */

dav_207_parser *dav_207_init( void *userdata );

/* Set the callbacks for the parser */

void dav_207_set_response_handlers( 
    dav_207_parser *p, dav_207_start_response start, dav_207_end_response end );

void dav_207_set_propstat_handlers( 
    dav_207_parser *p, dav_207_start_propstat start, dav_207_end_propstat end );

void dav_207_set_prop_handlers( 
    dav_207_parser *p, dav_207_start_prop start, dav_207_end_prop end );

/* Parse an input block, as hip_xml_parse */
void dav_207_parse( void *parser, const hip_xml_char *block, size_t len );

/* Finish parsing... returns 0 if the parse was successful, else
 * non-zero. */
int dav_207_finish( dav_207_parser *p );

const char *dav_207_error( dav_207_parser *p );

#endif /* DAV207_H */
