/* 
   Basic WebDAV support
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

*/

#ifndef DAV_BASIC_H
#define DAV_BASIC_H

#include "http_request.h"

#include "dav_207.h"

#define DAV_DEPTH_ZERO (0)
#define DAV_DEPTH_ONE (1)
#define DAV_DEPTH_INFINITE (2)

/* WebDAV request handling, incorporating 207 error response handling.
 * does http_request_dispatch and http_request_destroy for you.
 * Use this function for any WebDAV method which may return an error
 * using a 207 XML response. */

void dav_add_depth_header( http_req *req, int depth );

int dav_simple_request( http_session *sess, http_req *req );

int dav_accept_207( void *userdata, http_req *req, http_status *status );
void dav_parse_xml_block( void *userdata, const char *block, size_t length );

int dav_copy( http_session *sess, const char *src, const char *dest );
int dav_move( http_session *sess, const char *src, const char *dest );
int dav_delete( http_session *sess, const char *uri );
int dav_mkcol( http_session *sess, const char *uri );

#endif
