/* 
   sitecopy FTP protocol driver module
   Copyright (C) 2000, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   
   $Id: ftpdriver.c,v 1.6 2000/04/30 17:52:12 joe Exp $
*/

#include "protocol.h"
#include "ftp.h"

static int f2p( int code ) 
{
    switch( code ) {
    case FTP_OK:
	return PROTO_OK;
    case FTP_LOGIN:
	return PROTO_AUTH;
    case FTP_CONNECT:
	return PROTO_CONNECT;
    default:
	return PROTO_ERROR;
    }
}

static int init( void **session, struct proto_options *opt ) 
{
    ftp_session *sess = ftp_init( opt );
    *session = sess;
    return PROTO_OK;
}    

static int set_server( void *session, struct proto_host *server )
{
    ftp_session *sess = session;
    return f2p( ftp_set_server( sess, server ) );
}

static int set_proxy( void *session, struct proto_host *proxy )
{
    return PROTO_UNSUPPORTED;
}

static int verify( void *session, const char *root, struct proto_support *reqd )
{
    ftp_session *sess = session;
    return f2p( ftp_open( sess ) );
}

static void finish( void *session ) {
    ftp_session *sess = session;
    ftp_finish( sess );
}

static int file_move( void *session, const char *from, const char *to ) {
    ftp_session *sess = session;
    return f2p( ftp_move( sess, from, to ) );
}

static int file_upload( void *session, const char *local, const char *remote, 
			int ascii ) {
    ftp_session *sess = session;
    return f2p( ftp_put( sess, local, remote, ascii ) );
}

static int file_upload_cond( void *session,
			     const char *local, const char *remote,
			     int ascii, time_t time ) {
    return PROTO_ERROR;
}

static int file_get_modtime( void *session, const char *remote, time_t *modtime ) {
    ftp_session *sess = session;
    return f2p( ftp_get_modtime( sess, remote, modtime ) );
}
    
static int file_download( void *session, const char *local, const char *remote,
			  size_t remotesize, int ascii ) {
    ftp_session *sess = session;
    return f2p( ftp_get( sess, local, remote, remotesize, ascii ) );
}

static int file_read( void *session, const char *remote, size_t remotesize, 
		      proto_read_block reader, void *userdata ) {
    ftp_session *sess = session;
    return f2p( ftp_read_file( sess, remote, remotesize, reader, userdata ) );
}

static int file_delete( void *session, const char *filename ) {
    ftp_session *sess = session;
    return f2p( ftp_delete( sess, filename ) );
}

static int file_chmod( void *session, const char *filename, mode_t mode ) {
    ftp_session *sess = session;
    return f2p( ftp_chmod( sess, filename, mode ) );
}

static int dir_create( void *session, const char *dirname ) {
    ftp_session *sess = session;
    return f2p( ftp_mkdir( sess, dirname ) );
}

static int dir_remove( void *session, const char *dirname ) {
    ftp_session *sess = session;
    return f2p( ftp_rmdir( sess, dirname ) );
}

static int fetch_list( void *session, const char *dirname, int need_modtimes,
		       struct proto_file **files ) 
{
    ftp_session *sess = session;
    int ret;
    
    ret = f2p( ftp_fetch( sess, dirname, files ) );
    if( ret != PROTO_OK ) return ret;
    
    if( need_modtimes ) {
	ret = f2p( ftp_fetch_modtimes( sess, dirname, *files ) );
    }

    return ret;
}

static const char *error( void *session ) {
    ftp_session *sess = session;
    return ftp_get_error( sess );
}

/* The protocol drivers */
const struct proto_driver ftp_driver = {
    init, 
    set_server, 
    set_proxy, 
    verify,
    finish,
    file_move,
    file_upload,
    file_upload_cond,
    file_get_modtime,
    file_download,
    file_read,
    file_delete,
    file_chmod,
    dir_create,
    dir_remove,
    NULL, /* create link */
    NULL, /* change link target */
    NULL, /* delete link */
    fetch_list,
    error,
    "ftp", /* service name */
    21, /* service number */
    "FTP"
};
