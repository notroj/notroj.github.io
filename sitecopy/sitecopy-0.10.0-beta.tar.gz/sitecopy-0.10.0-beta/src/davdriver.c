/* 
   sitecopy WebDAV protocol driver module
   Copyright (C) 2000, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   $Id: davdriver.c,v 1.12 2000/04/30 19:26:42 joe Exp $
*/

/* TODO: remove PROTO_* and use SITE_* directly */

#include <config.h>

#include <sys/stat.h> /* For S_IXUSR */

#include <errno.h>

#include "common.h" /* for strerror */

#include "protocol.h"
#include "frontend.h"
#include "xalloc.h"
#include "i18n.h"
#include "http_request.h"
#include "http_basic.h"
#include "dav_basic.h"
#include "dav_props.h"

/* TODO: get rid of this? */
static void set_err( http_session *sess, const char *msg )
{
    char *err;
    CONCAT2( err, msg, strerror(errno) );
    http_set_error( sess, err );
    free( err );
}

static int server_auth_cb( void *userdata, const char *realm, const char *hostname,
			   char **username, char **password )
{
    struct proto_host *server = userdata;
    if( server->username && server->password ) {
	*username = xstrdup(server->username);
	*password = xstrdup(server->password);
	return 0;
    } else {
	return fe_login( fe_login_server, realm, hostname, username, password );
    }
}

static int proxy_auth_cb( void *userdata, const char *realm, const char *hostname,
			   char **username, char **password )
{
    struct proto_host *proxy = userdata;
    if( proxy->username && proxy->password ) {
	*username = xstrdup(proxy->username);
	*password = xstrdup(proxy->password);
	return 0;
    } else {
	return fe_login( fe_login_proxy, realm, hostname, username, password );
    }
}

/* Maps an HTTP_* error code onto a PROTO_* error code */
static int h2p( http_session *sess, int errcode ) 
{
    switch( errcode ) {
    case HTTP_OK:
	return PROTO_OK;
    case HTTP_FAILED:
	return PROTO_FAILED;
    case HTTP_AUTH:
	return PROTO_AUTH;
    case HTTP_AUTHPROXY:
	return PROTO_PROXYAUTH;
    case HTTP_SERVERAUTH:
	http_set_error( sess, _("The server did not authenticate itself correctly.\n"
				"Report this error to your server administrator.") );
	return PROTO_ERROR;
    case HTTP_PROXYAUTH:
	http_set_error( sess, _("The proxy server did not authenticate itself correctly.\n"
				"Report this error to your proxy server administrator.") );
	return PROTO_ERROR;
    default:
	return PROTO_ERROR;
    }
}

static int 
init( void **session, struct proto_options *options )
{
    http_session *sess = http_session_init();

    if( options->http_use_expect )
 	http_set_expect100( sess, 1 );

    if( options->http_limit )
	http_set_persist( sess, 0 );

    /* Note, this won't differentiate between xsitecopy and
     * sitecopy... maybe we should put a comment in as well. */
    http_set_useragent( sess, PACKAGE "/" VERSION );

    *session = sess;
    return PROTO_OK;
}

static int 
set_server( void *session, struct proto_host *server )
{
    http_session *sess = session;
    http_set_server_auth( sess, server_auth_cb, server );
    return h2p(sess, http_session_server( sess, server->hostname, server->port ));
}

static int
set_proxy( void *session, struct proto_host *proxy )
{
    http_session *sess = session;
    http_set_proxy_auth( sess, proxy_auth_cb, proxy );
    return h2p(sess, http_session_proxy( sess, proxy->hostname, proxy->port ));
}

static int verify( void *session, const char *root, struct proto_support *reqd )
{
    http_session *sess = session;
    http_server_capabilities caps = {0};
    int ret;
    ret = h2p(sess, http_options( sess, root, &caps ) );
    if( ret == PROTO_OK ) {
	if( !caps.dav_class1 || (reqd->set_permissions && !caps.dav_executable) ) {
	    /* Need to set permissions, but the server can't do that */
	    http_set_error( sess, 
			    _("The server does not support the executable live property.") );
	    ret = PROTO_ERROR;
	}
    }
    return ret;
}

static void finish( void *session ) 
{
    http_session *sess = session;
    http_session_finish( sess );
}

static int file_move( void *session, const char *from, const char *to ) 
{
    http_session *sess = session;
    return h2p(sess, dav_move( sess, from, to ));
}

static int file_upload( void *session, const char *local, const char *remote, 
			int ascii ) {
    FILE *f = fopen( local, "r" FOPEN_BINARY_FLAGS );
    http_session *sess = session;
    int ret;

    if( f == NULL ) {
	set_err( sess, _("Could not open file: ") );
	return PROTO_ERROR;
    }
    
    ret = http_put( sess, remote, f );

    (void) fclose( f );

    return h2p(sess, ret);
}

static int file_upload_cond( void *session,
			     const char *local, const char *remote,
			     int ascii, time_t time ) {
    http_session *sess = session;
    FILE *f = fopen( local, "r" FOPEN_BINARY_FLAGS );
    int ret;

    if( f == NULL ) {
	set_err( sess, _("Could not open file: ") );
	return PROTO_ERROR;
    }
    
    ret = h2p(sess, http_put_if_unmodified( sess, remote, f, time ));
    
    if( ferror(f) ) {
	if( ret != PROTO_OK ) {
	    set_err( sess, _("Could not write to file: ") );
	    ret = PROTO_ERROR;
	}
    } 
    if( fclose(f) ) {
	ret = PROTO_ERROR;
    }
    
    return ret;
}

static int file_get_modtime( void *session, const char *remote, time_t *modtime ) {
    http_session *sess = session;
    return h2p(sess, http_getmodtime(sess,remote,modtime));
}
    
static int file_download( void *session, const char *local, const char *remote,
			  size_t remotesize, int ascii ) 
{
    http_session *sess = session;
    FILE *f = fopen( local, "r" FOPEN_BINARY_FLAGS );
    int ret;

    if( f == NULL ) {
	set_err( sess, _("Could not open file: ") );
	return PROTO_ERROR;
    }
    
    ret = h2p(sess, http_get( sess, remote, f ));
    
    if( ferror( f ) ) {
	ret = PROTO_ERROR;
    }
    if( fclose( f ) ) {
	ret = PROTO_ERROR;
    }
    
    return ret;
}

static int file_read( void *session, const char *remote, size_t remotesize, 
		      proto_read_block reader, void *userdata ) 
{
    http_session *sess = session;
    return h2p(sess, http_read_file(sess, remote, reader, userdata));
}

static int file_delete( void *session, const char *filename ) 
{
    http_session *sess = session;
    return h2p(sess, dav_delete( sess, filename ) );
}

static int file_chmod( void *session, const char *filename, mode_t mode ) 
{
    http_session *sess = session;
    static const dav_propname execprop = 
    { "http://apache.org/dav/props/", "executable" };
    dav_proppatch_item items[] = { { &execprop, dav_propset, NULL }, { NULL } };
    
    if( mode & S_IXUSR ) {
	items[0].value = "T";
    } else {
	items[0].value = "F";
    }
    return h2p(sess, dav_proppatch( sess, filename, items ) );
}

static int dir_create( void *session, const char *dirname ) 
{
    http_session *sess = session;
    return h2p(sess, dav_mkcol( sess, dirname ) );
}

static int dir_remove( void *session, const char *dirname ) 
{
    http_session *sess = session;
    return h2p(sess, dav_delete( sess, dirname ) );
}

static void property_cb( void *userdata, const char *href, 
			 dav_propfind_result results[], int numresults )
{
}


static int fetch_list( void *session, const char *dirname, int need_modtimes,
		       struct proto_file **files ) 
{
#if 0
    http_session *sess = session;
    int ret;
    static const dav_propname props[] = {
	{ "DAV:", "getcontentlength" },
	{ "DAV:", "resourcetype" },
	{ "DAV:", "getlastmodified" }, /* ignore need_modtimes... it's no beef to us */
	{ "http://apache.org/dav/props/", "executable" },
	{ NULL }
    };
    
    ret = dav_propfind( sess, dirname, DAV_DEPTH_INFINITE, props, 
			property_cb, files );
    
    return ret;
#else
    return PROTO_UNSUPPORTED;
#endif
}

static int unimp_link2( void *session, const char *link, const char *target )
{
    http_session *sess = session;
    http_set_error( sess, "Operation not supported" );
    return PROTO_UNSUPPORTED;
}
 
static int unimp_link1( void *session, const char *link )
{
    http_session *sess = session;
    http_set_error( sess, "Operation not supported" );
    return PROTO_UNSUPPORTED;
}


static const char *error( void *session ) 
{
    http_session *sess = session;
    return http_get_error(sess);
}

/* The WebDAV protocol driver */
const struct proto_driver dav_driver = {
    init,
    set_server,
    set_proxy,
    verify,
    finish,
    file_move,
    file_upload,
    file_upload_cond,
    file_get_modtime,
    file_download,
    file_read,
    file_delete,
    file_chmod,
    dir_create,
    dir_remove,
    unimp_link2, /* create link */
    unimp_link2, /* change link target */
    unimp_link1, /* delete link */
    fetch_list,
    error,
    "http", /* service name */
    80, /* service number */
    "WebDAV"
};
