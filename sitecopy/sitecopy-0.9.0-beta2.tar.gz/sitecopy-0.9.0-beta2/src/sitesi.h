/* 
   sitecopy, for managing remote web sites.
   Copyright (C) 1999, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef SITESI_H
#define SITESI_H

#include "common.h"
#include "sites.h"

/* Internal sites code handling */

void file_uploaded( struct site_file *file, struct site *site );
void file_downloaded( struct site_file *file, struct site *site );

bool file_contents_changed( struct site_file *file, struct site *site );
bool file_perms_changed( struct site_file *file, struct site *site );

#define DEBUG_GIVE_DIFF( diff )					\
       diff==file_new?"new":(					\
	   diff==file_changed?"changed":(			\
	       diff==file_unchanged?"unchanged":(		\
		   diff==file_deleted?"deleted":"moved")))

/* Macro, used mainly internally to the sites code to dump a file. */
#define DEBUG_DUMP_FILE( ch, file )			\
DEBUG( ch, "%s: local=%s stored=%s, %s%s\n",		\
       (file->type==file_file)?"File":(			\
	   file->type==file_dir?"Dir":"Link"),		\
       file->local.filename?file->local.filename:".",	\
       file->stored.filename?file->stored.filename:".",	\
       DEBUG_GIVE_DIFF( file->diff ),			\
       file->ignore?" (ignored)":"" )

#define DEBUG_DUMP_FILE_PROPS( ch, file, site )			\
DEBUG_DUMP_FILE( ch, file );					\
if( site->state_method == state_timesize ) {			\
    DEBUG( ch, "Time: %ld/%ld Size: %ld/%ld ", 			\
       file->local.time, file->stored.time,			\
       file->local.size, file->stored.size );			\
} else {							\
    char l[33], s[33];						\
    md5_hexify( file->local.checksum, l );			\
    md5_hexify( file->stored.checksum, s );			\
    DEBUG( ch, "Checksum: %32s/%32s\n", l, s );			\
}								\
DEBUG( ch, "ASCII:%c/%c Perms:%03o/%03o\n",			\
       file->local.ascii?'y':'n', file->stored.ascii?'y':'n',	\
       file->local.mode, file->stored.mode    );

/* Use to iterate over a files list. */
#define for_each_file( file, site ) \
for( file = site->files; file != NULL; file = file->next )


/* Remove a file from the files list */
void file_remove( struct site *site, struct site_file *item );

/* Destroys a file, destroying all associated data too */
void file_destroy( struct site_file *file );
/* Destroys a file state */
void file_state_destroy( struct file_state *state );
/* Copies a file state from src to dest */
void file_state_copy( struct file_state *dest, const struct file_state *src );

/* This *MUST* be called after you change the local or stored state
 * of a file. It sets the ->diff appropriately, and updates the
 * site's num* and total* fields. */
void file_set_diff( struct site_file *file, struct site *site );

struct site_file *
file_find( struct site *site, const char *fname, enum file_type type );

/* Compares two files states for a file of given type, belonging to
 * the given site. */
enum file_diff 
file_compare( const enum file_type type, 
	      const struct file_state *, const struct file_state *, 
	      const struct site *site );

struct site_file *
file_set_stored( enum file_type type, struct file_state *state,
		 struct site *site );

struct site_file *
file_set_local( enum file_type type, struct file_state *state,
		struct site *site );

/* Places the checksum of the given filename in the given file state.
 * The checksum algorithm may in the future be determined from the
 * site.
 * Returns 0 on success or -1 on error.
 */
int
file_checksum( const char *fname, struct file_state *state, struct site *s );

/* Returns whether a file of given name is exclude from the given site */
bool file_isexcluded( const char *filename, struct site *site );
/* Returns whether a file is ASCII text or binary */
bool file_isascii( char *filename, struct site *site );
/* Returns whether a file is ignored or not */
bool file_isignored( const char *filename, struct site *site );

#endif /* SITESI_H */
