/* 
   sitecopy, for managing remote web sites.
   Copyright (C) 1998-99, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   $Id: sites.c,v 1.87.2.1 1999/11/02 19:20:28 joe Exp $
*/

/* This is the core functionality of sitecopy, performing updates
 * and checking files etc. */

#include <config.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <errno.h>
#include <dirent.h>
#include <fnmatch.h>
#include <fcntl.h>
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif /* HAVE_STDLIB_H */
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif /* HAVE_UNISTD_H */
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#include <time.h>
#include <utime.h>

#ifndef HAVE_SNPRINTF
#include <snprintf.h>
#endif /* !HAVE_SNPRINTF */

#include <basename.h>
#include <md5.h>

#include "common.h"
#include "frontend.h"
#include "protocol.h"
#include "socket.h"
#include "sitesi.h"
#include "string_utils.h"

#include "ftp.h"

/* The protocol drivers */
const struct proto_driver ftp_driver = {
    ftp_init,
    ftp_finish,
    ftp_move,
    ftp_put,
    ftp_put_cond,
    ftp_ext_get_modtime,
    ftp_get, /* Download */
    ftp_read_file, /* read file */
    ftp_delete,
    ftp_chmod,
    ftp_mkdir,
    ftp_rmdir,
    NULL, /* create link */
    NULL, /* change link target */
    NULL, /* delete link */
    ftp_fetch,
    "ftp", /* service name */
    21, /* service number */
    "FTP",
    ftp_error
};

#ifdef USE_DAV
#include "httpdav.h"

const struct proto_driver dav_driver = {
    http_init, /* Connect */
    http_finish, /* Disconnect */
    dav_move, /* File move */
    http_put, /* File upload - HTTP PUT */
    http_put_if_unmodified, /* Conditional PUT */
    http_getmodtime,
    http_get, /* File download */
    http_read_file, /* read file */
    http_delete, /* File delete */
    NULL, /* File chmod... this could be done using either
	   *   a) A special live property
	   *   b) The ACL extensions: draft-ietf-webdav-acl-??.txt
	   */
    dav_mkcol, /* Dir create */
    dav_rmdir, /* Dir remove, same as file remove */
    dav_mkref, /* Create link */
    dav_chref, /* Change link */
    dav_rmref, /* Remove link */
    /* fetch listing */
#ifdef HAVE_LIBEXPAT
    dav_fetch, 
#else
    NULL, 
#endif
    "http", /* Service name */
    80, /* server number */
    "WebDAV", /* User-visible protocol name */
    http_error
};
#endif

/* Shorthand for protocol driver methods */
#define CALL( a ) (*site->driver->a)

/* This holds ALL the sites defined in the rcfile */
struct site *all_sites;
 
bool fe_prompting;
bool site_keepgoing;

/* Error message used in safe mode when remote file has changed */
static const char *cond_failure = 
   "Remote file has been modified - not overwriting with local changes";
/* Used when the upload succeeds, but the modtime could not be 
 * fetched */
static const char *warn_get_modtime = 
   "Upload succeeded, but could not retrieve modification time.\n"
   "If this message persists, turn off safe mode.";

static const char *warn_synch_modtime = 
   "Could not set modification time of local file.";

static int proto_init( struct site *site );

#define HANDLE_ABORT(t,r) { 			\
    if( fe_abort_##t(site) ) {			\
	r = SITE_ABORTED;			\
	break;					\
    }						\
}

/* Prototypes */
void site_checkmoved( struct site *any_site );

static int site_synch_create_directories( struct site *site );
static int site_synch_files( struct site *site );
static int site_synch_delete_directories( struct site *site );

static int site_update_create_directories( struct site *site, bool onlysome );
static int site_update_delete_directories( struct site *site, bool onlysome );
static int site_update_delete_files( struct site *site, bool onlysome );
static int site_update_files( struct site *site, bool onlysome );
static int site_update_links( struct site *the_site, bool onlymarked );
static void file_retrieve_server( struct site_file *file, struct site *site );

static void site_fetch_walk( struct site *site, struct proto_file *files );
void site_fetch_csum_read( void *userdata, const char *s, const size_t len );
static int site_fetch_checksum( struct proto_file *files, struct site *site );

void site_flatlist_items( FILE *f, struct site *site, 
			  const enum file_diff diff, const char *name );

static int 
site_verify_compare( struct site *site, const struct proto_file *files );

struct site *site_find( const char *sitename ) {
    struct site *current;

    for( current = all_sites; current!=NULL; current=current->next ) {
	if( strcmp( current->name, sitename ) == 0 ) {
	    /* We found it */
	    return current;
	}
    }

    return NULL;
}

int site_synch_create_directories( struct site *site ) {
    struct site_file *current;
    char *full_local;
    int ret;
    
    ret = 0;
    
    for_each_file( current, site ) {
	if( (current->type==file_dir) && (current->diff==file_deleted) ) {
	    full_local = file_full_local( &current->stored, site );
	    fe_synching( current );
	    if( mkdir( full_local, 0755 ) == 0 ) {
		fe_synched( current, true, NULL );
	    } else {
		ret = 1;
		fe_synched( current, false, strerror(errno) );
		file_downloaded( current, site );
	    }
	    free( full_local );
	}
	HANDLE_ABORT(synch,ret)
    }
    return ret;
}

int site_synch_files( struct site *site ) {
    struct site_file *current;
    int ret;

    ret = 0;

    for_each_file( current, site ) {
	char *full_local, *full_remote;
	if( current->type != file_file ) continue;
	switch( current->diff ) {
	case file_changed:
	case file_deleted:
	    full_local = file_full_local( &current->stored, site );
	    full_remote = file_full_remote( &current->stored, site );
	    fe_synching( current );
	    if( CALL(file_download)( full_local, full_remote,
				     current->stored.size, 
				     current->stored.ascii ) != PROTO_OK ) {
		fe_synched( current, false, site->driver->last_error );
		ret = 1;
	    } else { 
		/* Successfull download */
		fe_synched( current, true, NULL );
		if( site->state_method == state_timesize ) {
		    struct utimbuf times;
		    /* Change the modtime of the local file so it doesn't look
		     * like it's changed already */
		    times.actime = current->stored.time;
		    times.modtime = current->stored.time;
		    if( utime( full_local, &times ) < 0 ) {
			fe_warning( warn_synch_modtime, full_local, 
				    strerror(errno) );
		    }
		}
		file_downloaded( current, site );
		if( file_perms_changed( current, site ) ) {
		    fe_setting_perms( current );
		    if( chmod( full_local, current->stored.mode ) < 0 ) {
			fe_set_perms( current, false, strerror(errno) );
		    } else {
			fe_set_perms( current, true, NULL );
		    }
		}
	    }
	    free( full_local );
	    free( full_remote );
	    break;
	case file_new:
	    full_local = file_full_local( &current->local, site );
	    fe_synching( current );
	    if( unlink( full_local ) != 0 ) {
		fe_synched( current, false, strerror(errno) );
		ret = 1;
	    } else {
		fe_synched( current, true, NULL );
	    }
	    free( full_local );
	    break;
	case file_moved: {
	    char *old_full_local = file_full_local( &current->stored, site );
	    full_local = file_full_local( &current->local, site );
	    fe_synching( current );
	    if( rename( full_local, old_full_local ) == 0 ) {
		fe_synched( current, true, NULL );
	    } else {
		fe_synched( current, false, strerror(errno) );
		ret = 1;
	    }
	    free( old_full_local );
	    free( full_local );
	}
	default:
	    break;	    
	}
	HANDLE_ABORT(synch,ret)
    }

    return ret;

}

int site_synch_delete_directories( struct site *site ) {
    struct site_file *current, *prev;
    int ret;

    ret = 0;

    for( current=site->files_tail; current!=NULL; current=prev ) {
	prev = current->prev;
	if( (current->type==file_dir) && (current->diff==file_new) ) {
	    char *full_local = file_full_local( &current->local, site );
	    fe_synching( current );
	    if( rmdir( full_local ) == -1 ) {
		fe_synched( current, false, strerror(errno) );
		ret = 3;
	    } else {
		fe_synched( current, true, NULL );
		file_remove( site, current );
		file_destroy( current );
	    }
	    free( full_local );
	}
	HANDLE_ABORT(synch,ret)
    }

    return ret;
}

/* Resyncs the LOCAL site with the REMOTE site.
 * This is site_update backwards, and is essentially the same in structure,
 * except with the logic reversed.
 */
int site_synch( struct site *site ) {
    int ret;

    ret = proto_init( site );
    if( ret != SITE_OK )
	return ret;

    ret = site_synch_create_directories( site );
    if( ret == 0 ) {
	ret = site_synch_files( site );
	if( ret == 0 ) {
	    ret = site_synch_delete_directories( site );
	}
    }
    
    CALL(finish)( );

    if( ret == 0 ) {
	ret = SITE_OK;
    } else if( ret != SITE_ABORTED ) {
	ret = SITE_ERRORS;
    }
    return ret;
}

static int file_chmod( struct site_file *file, struct site *site ) {
    int ret = 0;
    /* chmod it if necessary */
    if( file_perms_changed( file, site ) ) {
	char *full_remote = file_full_remote( &file->local, site );
	fe_setting_perms( file );
	if( CALL(file_chmod)( full_remote, file->local.mode ) != PROTO_OK ) {
	    fe_set_perms( file, false, site->driver->last_error );
	    ret = 1;
	} else {
	    file->stored.mode = file->local.mode;
	    fe_set_perms( file, true, NULL );
	    file_set_diff( file, site );
	}
	free( full_remote );
    }
    return ret;
}

static void file_retrieve_server( struct site_file *file, struct site *site ) {
    time_t rtime;
    char *full_remote = file_full_remote( &file->local, site );
    if( CALL(file_get_modtime)( full_remote, &rtime ) == PROTO_OK ) {
	file->server.time = rtime;
	file->server.exists = true;
    } else {
	file->server.exists = false;
	fe_warning( warn_get_modtime, full_remote, site->driver->last_error );
    }
    free( full_remote );
}

int site_update_create_directories( struct site *site, bool onlymarked) {
    struct site_file *current;
    int ret = 0;

    for_each_file( current, site ) {
	if( (current->type == file_dir) && (current->diff == file_new) && 
	    (!onlymarked || !current->marked) ) {
	    /* New dir! */
	    char *full_remote;
	    if( fe_prompting ) if( !fe_can_update( current ) ) continue;
	    full_remote = file_full_remote( &current->local, site );
	    fe_updating( current );
	    if( CALL(dir_create)( full_remote ) != PROTO_OK ) {
		fe_updated( current, false, site->driver->last_error );
		ret = 1;
	    } else {
		fe_updated( current, true, NULL );
		file_uploaded( current, site );
	    }
	    free( full_remote );
	}
	HANDLE_ABORT(update,ret)
    }

    return ret;
}

int site_update_delete_files( struct site *site, bool onlymarked ) {
    struct site_file *current, *next;
    int ret = 0;

    for( current=site->files; current!=NULL; current=next ) {
	next = current->next;
	/* Skip directories and links, and only do deleted files on
	 * this pass */
	if( (current->diff == file_deleted ) &&
	    (current->type == file_file ) && 
	    (!onlymarked || current->marked) ) {
	    char *full_remote;
	    if( fe_prompting ) if( !fe_can_update( current ) ) continue;
	    full_remote = file_full_remote( &current->stored, site );
	    fe_updating( current );
	    if( CALL(file_delete)( full_remote ) != PROTO_OK ) {
		fe_updated( current, false, site->driver->last_error  );
		ret = 1;
	    } else {
		/* Successful update - file was deleted */
		fe_updated( current, true, NULL );
		file_remove( site, current );
		file_destroy( current );
	    }
	    free( full_remote );
	}
	HANDLE_ABORT(update,ret)
    }
    
    return ret;

}

/* Does everything but file deletes */
int site_update_files( struct site *site, bool onlymarked ) {
    struct site_file *current;
    char *driver_error = site->driver->last_error;
    int ret = 0;

    for_each_file( current, site ) {
	char *full_local, *full_remote;
	if( (current->type != file_file) || (current->diff == file_deleted) ||
	    (onlymarked && !current->marked) ) continue;
	full_local = file_full_local( &current->local, site );
	full_remote = file_full_remote( &current->local, site );
	switch( current->diff ) {
	case file_changed: /* File has changed, upload it */
	    if( current->ignore ) break;
	    if( !file_contents_changed( current, site ) ) {
		/* If the file contents haven't changed, then we can
		 * just chmod it */
		if( file_chmod( current, site ) )
		    ret = 1;
		break;
	    }
	    /*** fall-through ***/
	case file_new: /* File is new, upload it */
	    if( fe_prompting ) if( !fe_can_update( current ) ) continue;
	    if( (current->diff == file_changed) && site->nooverwrite ) {
		/* Must delete remote file before uploading new copy.
		 * FIXME: Icky hack to convince the FE we are about to
		 * delete the file */
		current->diff = file_deleted;
		fe_updating( current );
		if( CALL(file_delete)( full_remote ) != PROTO_OK ) {
		    fe_updated( current, false, driver_error );
		    ret = 1;
		    current->diff = file_changed;
		    /* Don't upload it! */
		    break;
		} else {
		    fe_updated( current, true, NULL );
		    current->diff = file_changed;
		}
	    }
	    fe_updating( current );
	    /* Now, upload it */
	    if( site->safemode && current->server.exists ) {
		/* Only do this for files we do know the remote modtime for */
		int cret;
		cret = CALL(file_upload_cond)( 
		    full_local, full_remote, current->local.ascii,
		    current->server.time );
		switch( cret ) {
		case PROTO_ERROR:
		    fe_updated( current, false, driver_error );
		    ret = 1;
		    break;
		case PROTO_FAILED:
		    fe_updated( current, false, cond_failure );
		    ret = 1;
		    break;
		default:
		    /* Success case */
		    fe_updated( current, true, NULL );
		    file_retrieve_server( current, site );
		    if( file_chmod( current, site ) ) ret = 1;
		    file_uploaded( current, site );
		    break;
		}
	    } else if( site->tempupload && (current->diff == file_changed) ) {
		/* Do temp file upload followed by a move */
		char *temp_remote;
		CONCAT2( temp_remote, full_remote, ".in" );
		if( CALL(file_upload)( full_local, temp_remote,
				       current->local.ascii != PROTO_OK ) ) {
		    fe_updated( current, false, driver_error );
		    ret = 1;
		} else {
		    /* Successful upload... now move it */
		    if( CALL(file_move)( temp_remote, 
					 full_remote ) != PROTO_OK ) {
			fe_updated( current, false, driver_error );
			/* Originally coded to delete the temporary file
			 * here, but, on second thoughts... if something
			 * is broken, let's not try to be too clever, else
			 * we might make it worse. */
			ret = 1;
		    } else {
			/* Successful move */
			fe_updated( current, true, NULL );
			if( site->safemode ) {
			    file_retrieve_server( current, site );
			}
			if( file_chmod( current, site ) ) ret = 1;
			file_uploaded( current, site );
		    }
		}
		free( temp_remote );
	    } else {
		/* Normal unconditional upload */
		if( CALL(file_upload)( full_local, full_remote, 
				       current->local.ascii ) != PROTO_OK ) {
		    fe_updated( current, false, driver_error );
		    ret = 1;
		} else {
		    /* Successful upload. */
		    fe_updated( current, true, NULL );
		    if( site->safemode ) {
			file_retrieve_server( current, site );
		    }
		    if( file_chmod( current, site ) ) ret = 1;
		    file_uploaded( current, site );
		}
	    }
	    break;
		
	case file_moved:
	{
	    char *old_full_remote;
	    /* The file has been moved */
	    if( fe_prompting ) {
		if( !fe_can_update( current ) ) continue;
	    } else {
		fe_updating( current );
	    }
	    old_full_remote = file_full_remote( &current->stored, site );
	    if( CALL(file_move)( old_full_remote, full_remote ) != PROTO_OK ) {
		ret = 1;
		fe_updated( current, false, driver_error );
	    } else {
		/* Successful update - file was moved */
		fe_updated( current, true, NULL );
		file_uploaded( current, site );
	    }
	    free( old_full_remote );
	    break;
	}   
	default: /* Ignore everything else */
	    break;
	}
	free( full_remote );
	free( full_local );
	HANDLE_ABORT(update,ret)
    }

    return ret;
    
}

int site_update_delete_directories( struct site *site, bool onlymarked ){
    struct site_file *current, *prev;
    int ret = 0;

    /* This one must iterate through the list BACKWARDS, so
     * directories are deleted bottom up */
    for( current=site->files_tail; current!=NULL; current=prev ) {
	prev = current->prev;
	if( onlymarked && !current->marked ) continue;
	if( (current->type==file_dir) && (current->diff == file_deleted ) ) {
	    char *full_remote;
	    if( fe_prompting ) if( !fe_can_update( current ) ) continue;
	    full_remote = file_full_remote( &current->stored, site );
	    fe_updating( current );
	    if( CALL(dir_remove)( full_remote ) != PROTO_OK ) {
		ret = 1;
		fe_updated( current, false, site->driver->last_error );
	    } else {
		/* Successful delete */
		fe_updated( current, true, NULL );
		file_remove( site, current );
		file_destroy( current );
	    }
	    free( full_remote );
	}
	HANDLE_ABORT(update,ret)
    }
    return ret;
}

int site_update_links( struct site *site, bool onlymarked ) {
    struct site_file *current, *next;
    int ret = 0;

    for( current=site->files; current!=NULL; current=next ) {
	char *full_remote;
	next = current->next;
	if( (current->type != file_link) || (onlymarked && !current->marked) )
	    continue;
	full_remote = file_full_remote( &current->local, site );
	switch( current->diff ) {
	case file_new:
	    fe_updating( current );
	    if( CALL(link_create)( full_remote, current->local.linktarget ) != PROTO_OK ) {
		    fe_updated( current, false, site->driver->last_error );
		    ret = 1;
		} else {
		    fe_updated( current, true, NULL );
		    current->diff = file_unchanged;
		}
	    break;
	case file_changed:
	    fe_updating( current );
	    if( CALL(link_change)( full_remote,
				   current->local.linktarget ) != PROTO_OK ) {
		fe_updated( current, false, site->driver->last_error );
		ret = 1;
	    } else {
		fe_updated( current, true, NULL );
		current->diff = file_unchanged;
	    }
	    break;
	case file_deleted:
	    fe_updating( current );
	    if( CALL(link_delete)( full_remote ) != PROTO_OK ) {
		fe_updated( current, false, site->driver->last_error );
		ret = 1;
	    } else {
		fe_updated( current, true, NULL );
		file_remove( site, current );
		file_destroy( current );
	    }
	default:
		break;
	}
	free( full_remote );
	HANDLE_ABORT(update,ret)
    }
    return ret;
}

static int proto_init( struct site *site ) {
    struct proto_host *proxy_pass;
    int ret;

    ftp_use_passive = site->ftp_pasv_mode;
    ftp_echo_quit = site->ftp_echo_quit;
#ifdef USE_DAV
    http_enable_expect = site->http_use_expect;
    http_conn_limit = site->http_limit;
#endif

    if( site->proxy.hostname == NULL ) {
	proxy_pass = NULL;
    } else {
	proxy_pass = &site->proxy;
    }

    ret = CALL(init)( site->remote_root, &site->server, proxy_pass );
    switch( ret ) {
    case PROTO_LOOKUP:
	ret = SITE_LOOKUP;
	break;
    case PROTO_CONNECT:
	ret = SITE_CONNECT;
	break;
    case PROTO_AUTH:
	ret = SITE_AUTH;
	break;
    default:
	ret = SITE_OK;
	break;
    }
    return ret;
}


/* Updates the remote site with the local copy.
 * This is the core functionality of sitecopy.
 * All we do is compare the local files list with the remote files
 * list, and upload any changed or new files.
 * Directories are treated differently - any new ones must be created BEFORE
 * any files are uploaded, and any old ones must be deleted AFTER any files
 * are deleted, since most FTP servers will not allow you to DELE a 
 * non-empty directory.
 */
int site_update( struct site *site, bool onlymarked )  {
    int ret = 0;
    
    ret = proto_init( site );
    if( ret != SITE_OK )
	return ret;

    ret = site_update_create_directories( site, onlymarked );
    if( ret == 0 || (ret != SITE_ABORTED && site_keepgoing) ) {
	/* Delete files first, since they might be quota-limited
	 * on the remote site */
	if( !site->nodelete ) {
	    ret += site_update_delete_files( site, onlymarked );
	}
	if( ret == 0 || (ret != SITE_ABORTED && site_keepgoing) ) {
	    ret += site_update_files( site, onlymarked );
	    if( (ret == 0 || (ret != SITE_ABORTED && site_keepgoing) ) && 
		(site->symlinks == sitesym_maintain ) ) {
		ret += site_update_links( site, onlymarked );
	    }
	    if( (ret == 0 || (ret != SITE_ABORTED && site_keepgoing)) && 
		!site->nodelete ) {
		ret += site_update_delete_directories( site, onlymarked );
	    }
	}
    }

    CALL(finish)( );

    if( ret == 0 ) {
	/* Site updated successfully. */
	ret = SITE_OK;
    } else if( ret != SITE_ABORTED ) {
	/* Update not totally successfull */
	ret = SITE_ERRORS;
    }
    return ret;
}

/* This reads off the remote files and the local files. */
int site_readfiles( struct site *site ) {
    site_destroy( site );
    if( site_read_stored_state( site ) < 0 )
	return -1;
    if( site_read_local_state( site ) )
	return -2;
    return 0;
}

/* Read the local site files... 
 * A stack is used for directories within the site - this is not recursive.
 * Each item on the stack is a FULL PATH to the directory, i.e., including
 * the local site root. */

/* Initial size of directory stack, and amount it grows
 * each time we fill it. */
#define DIRSTACKSIZE 128

int site_read_local_state( struct site *site ) {
    char **dirstack, *this, *full = NULL;
    int dirtop = 0, /* points to item above top stack item */
	dirmax = DIRSTACKSIZE; /* size of stack */

    dirstack = malloc( sizeof(char *) * DIRSTACKSIZE );
    /* Push the root directory on to the stack */
    dirstack[dirtop++] = strdup( site->local_root );
    
    /* Now, for all items in the stack, process all the files, and
     * add the dirs to the stack. Everything we put on the stack is
     * temporary and gets freed eventually. */

    while( dirtop > 0 ) {
	DIR *curdir;
	struct dirent *ent;
	/* Pop the stack */
	this = dirstack[--dirtop];
	
	DEBUG( DEBUG_FILES, "Scanning: %s\n", this );
	curdir = opendir( this );
	if( curdir == NULL ) {
	    fe_warning( "Could not read directory", this, strerror(errno) );
	    free( this );
	    continue;
	}

	/* Now read all the directory entries */
	while( (ent = readdir( curdir )) != NULL ) {
	    char *fname;
	    struct stat item;
	    struct site_file *current;
	    struct file_state local = {0};
	    enum file_type type;
	    
	    /* Exclude the special directory entries. This test comes
	     * high since it kills two stat calls per directory. */
	    if( (strcmp( ent->d_name, "." )==0 ||
		 strcmp( ent->d_name, ".." )==0) ) {
		continue;
	    }
	    
	    if( full != NULL ) free( full );

	    CONCAT2( full, this, ent->d_name );

#ifndef __EMX__
 	    if( lstat( full, &item ) == -1 ) {
#else
	    /* There are no symlinks under OS/2, use stat() instead */
	    if( stat( full, &item ) == -1 ) {
#endif
		fe_warning( "Could not stat file.", full, strerror(errno) );
		continue;
	    }
#ifndef __EMX__
	    /* Is this a symlink? */
	    if( S_ISLNK( item.st_mode ) ) {
		DEBUG( DEBUG_FILES, "symlink - " );
		if( site->symlinks == sitesym_ignore ) {
		    /* Just skip it */
		    DEBUG( DEBUG_FILES, "ignoring.\n" );
		    continue;
		} else if( site->symlinks == sitesym_follow ) {
		    DEBUG( DEBUG_FILES, "followed - " );
		    /* Else, carry on as normal, stat the real file */
		    if( stat( full, &item ) == -1 ) {
			/* It's probably a broken link */
			DEBUG( DEBUG_FILES, "broken.\n" );
			continue;
		    }
		} else {
		    DEBUG( DEBUG_FILES, "maintained:\n" );
		}
	    }
#endif /* __EMX__ */
	    /* Now process it */
	    
	    /* This is the filename of this file - i.e., everything
	     * apart from the local root */
	    fname = (char *)full+strlen(site->local_root);
	    
	    /* Check for excludes */
	    if( file_isexcluded( fname, site ) )
		continue;
	    
	    if( S_ISREG( item.st_mode ) ) {
		switch( site->state_method ) {
		case state_timesize:
		    local.time = item.st_mtime;
		    break;
		case state_checksum:
		    if( file_checksum( full, &local, site ) != 0 ) {
			fe_warning( "Could not checksum file", full,
				    strerror(errno) );
			continue;
		    }
		    break;
		}
		local.size = item.st_size;
		local.ascii = file_isascii( fname, site );
		type = file_file;
	    }
#ifndef __EMX__
	    else if( S_ISLNK( item.st_mode ) ) {
		char tmp[BUFSIZ] = {0};
		type = file_link;
		DEBUG( DEBUG_FILES, "symlink being maintained.\n" );
		if( readlink( full, tmp, BUFSIZ ) == -1 ) {
		    fe_warning( "The target of the link could not be read.", full, strerror(errno) );
		    continue;
		}
		local.linktarget = strdup( tmp );
	    }
#endif /* __EMX__ */
	    else if( S_ISDIR( item.st_mode ) ) {
		type = file_dir;
		if( dirtop == dirmax ) {
		    /* Grow the stack */
		    dirmax += DIRSTACKSIZE;
		    dirstack = realloc( dirstack, sizeof(char *) * dirmax );
		}
		/* Add it to the search stack */
		CONCAT2( dirstack[dirtop], full, "/" );
		dirtop++;
	    } else {
		DEBUG( DEBUG_FILES, "something else.\n" );
		continue;
	    }
	    
	    /* Set up rest of the local state */
	    local.mode = item.st_mode & 0777;
	    local.exists = true;
	    local.filename = strdup( fname );

	    current = file_set_local( type, &local, site );
	    DEBUG_DUMP_FILE_PROPS( DEBUG_FILES, current, site );

	}
	/* Close the open directory */
	closedir( curdir );
	/* And we're finished with this */
	free( this );
    }
    return 0;
}

#undef DIRSTACKSIZE


/* Pretend the remote site is the same as the local site. */
void site_catchup( struct site *site ) {
    struct site_file *current, *next;
    for( current=site->files; current!=NULL; current=next ) {
	next = current->next;
	switch( current->diff ) {
	case file_deleted:
	    file_remove( site, current );
	    file_destroy( current );
	    break;
	case file_changed:
	case file_new:
	case file_moved:
	    file_state_copy( &current->stored, &current->local );
	    file_set_diff( current, site );
	    break;
	case file_unchanged:
	    /* noop */
	    break;
	}
    }
}

/* Reinitializes the site - clears any remote files
 * from the list, and marks all other files as 'new locally'.
 */
void site_initialize( struct site *site ) {
    
    /* It's simple: */
    site_destroy_stored( site );

}

/* This walks the files list as returned by the protocol driver,
 * and converts it into a 'real' files list. */
static void site_fetch_walk( struct site *site, struct proto_file *files ) {
    struct proto_file *this_file, *next_file;

    this_file = files;
    while( this_file != NULL ) {

	if( !file_isexcluded( this_file->filename, site ) ) {
	    enum file_type type;
	    struct site_file *file;
	    struct file_state state = {0};
	    switch( this_file->type ) {
	    case proto_file:
		type = file_file;
		break;
	    case proto_dir:
		type = file_dir;
		break;
	    case proto_link:
		type = file_link;
		break;
	    }
	    state.size = this_file->size;
	    state.time = this_file->modtime;
	    state.exists = true;
	    state.filename = this_file->filename;
	    state.mode = this_file->mode;
	    state.ascii = file_isascii( this_file->filename, site );
	    memcpy( state.checksum, this_file->checksum, 16 );

	    file = file_set_stored( type, &state, site );
	    fe_fetch_found( file );

	    /* Fix the modification time if necessary.
	     * Because the modtime ON THE SERVER is ALWAYS going to be
	     * different from the local modtime for files, we make it
	     * the same, else, after doing a --fetch, all existing files
	     * will appear 'changed'. 
	     */
	    if( file->diff == file_changed && 
		site->state_method == state_timesize ) {
		file->stored.time = file->local.time;
		file_set_diff( file, site );
	    }

	} else {
	    free( this_file->filename );
	}

	next_file = this_file->next;
	free( this_file );
	this_file = next_file;
    }

}

void
site_fetch_csum_read( void *userdata, const char *s, const size_t len ) {
    struct md5_ctx *md5 = userdata;
    md5_process_bytes( s, len, md5 );
}

/* Retrieve the remote checksum for all files */
static int site_fetch_checksum( struct proto_file *files, struct site *site ) {
    struct md5_ctx md5;
    struct proto_file *file;
    int ret = 0;
    
    for( file = files; file!=NULL; file=file->next ) { 
	if( file->type == proto_file ) {
	    char *full_remote;
	    CONCAT2( full_remote, site->remote_root, file->filename );
	    md5_init_ctx( &md5 );
	    fe_checksumming( file->filename );
	    if( CALL(file_read)( full_remote, file->size, 
				 site_fetch_csum_read, &md5 ) !=
		PROTO_OK ) {
		ret = 1;
		fe_checksummed( full_remote, false, site->driver->last_error );
	    } else {
		md5_finish_ctx( &md5, file->checksum );
		fe_checksummed( full_remote, true, NULL );
	    }
	    free( full_remote );
	}
    }
    return ret;
}
    
/* Updates the remote file list... site_fetch_callback is called for
 * every remote file found.
 */
int site_fetch( struct site *site ) {
    struct proto_file *files = NULL;
    int ret;

    if( CALL(fetch_list) == NULL ) {
	return SITE_UNIMPL;
    }

    ret = proto_init( site );
    if( ret != SITE_OK )
	return ret;

    ret = CALL(fetch_list)( site->remote_root, &files );

    if( site->state_method == state_checksum ) {
	site_fetch_checksum( files, site );
    }

    CALL(finish)( );
    
    if( ret == PROTO_OK ) {
	/* Copy over the list of files */
	site_destroy_stored( site );
	site_fetch_walk( site, files );
	return SITE_OK;
    } else {
	return SITE_FAILED;
    }

}

/* Compares files list with files.
 * Returns SITE_OK on match, SITE_ERRORS on no match.
 */
int site_verify_compare( struct site *site, const struct proto_file *files ) {
    struct site_file *file;
    const struct proto_file *lfile;
    int numremote = 0;
    /* Clear live state */
    for_each_file( file, site )	{
	if( file->stored.exists ) {
	    numremote++;
	}
    }

    for( lfile = files; lfile != NULL; lfile = lfile->next ) {
	numremote--;
	for_each_file( file, site ) {
	    if( file->stored.exists &&
		(strcmp( file->stored.filename, lfile->filename ) == 0) ) {
		/* Do a mini file_compare job */
		if( site->state_method == state_checksum ) {
		    if( memcmp( file->stored.checksum, lfile->checksum, 16 ) )
			return SITE_ERRORS;
		} else {
		    if( (file->stored.size != lfile->size) ||
			(site->safemode && 
			 (file->server.time != lfile->modtime)) ) {
			return SITE_ERRORS;
		    }
		}
		break;
	    }
	}
    }
    
    if( numremote != 0 ) {
	return SITE_ERRORS;
    } else {
	return SITE_OK;
    }	   

}

/* Compares what's on the server with what we THINK is on the server.
 * Returns SITE_OK if match, SITE_ERRORS if doesn't match.
 */
int site_verify( struct site *site ) {
    struct proto_file *files = NULL;
    int ret;

    if( CALL(fetch_list) == NULL ) {
	return SITE_UNIMPL;
    }

    ret = proto_init( site );
    if( ret != SITE_OK )
	return ret;

    ret = CALL(fetch_list)( site->remote_root, &files );

    if( site->state_method == state_checksum ) {
	site_fetch_checksum( files, site );
    }

    CALL(finish)( );
    
    if( ret == PROTO_OK ) {
	/* Return whether they matched or not */
	return site_verify_compare( site, files );
    } else {
	return SITE_FAILED;
    }

}

/* Destroys the stored state of files in the files list for the given
 * site. Removes any files which do not exist locally from the list. */
void site_destroy_stored( struct site *site ) {
    struct site_file *current, *next;
    current = site->files;
    while( current != NULL ) {
	next = current->next;
	if( !current->local.exists ) {
	    /* It doesn't exist locally... nuke it */
	    file_remove( site, current );
	    file_destroy( current );
	} else {
	    /* Just nuke the stored state...
	     * TODO-ngm: verify this. */
	    file_state_destroy( &current->stored );
	    /* Could just do .exists = false */
	    memset( &current->stored, 0, sizeof(struct file_state) );
	    /* And set the diff */
	    file_set_diff( current, site );
	}
	current = next;
    }
}

/* Called to delete all the files associated with the site */
void site_destroy( struct site *site ) {
    struct site_file *current, *next;

    current = site->files;

    while( current != NULL ) {
	next = current->next;
	/* Removing it is overkill... but it updates the stats
	 * properly */
	file_remove( site, current );
	file_destroy( current );
	current = next;
    }

    site->files = NULL;
    site->files_tail = NULL;

}


/* Produces a section of the flat listing output, of all the items
 * with the given diff type in the given site, using the given section
 * name. */
void site_flatlist_items( FILE *f, struct site *site, 
			  const enum file_diff diff, const char *name ) {
    struct site_file *current;
    fprintf( f, "sectstart|%s", name );
    putc( '\n', f );
    for_each_file( current, site ) {
	if( current->diff == diff ) {
	    fprintf( f, "item|%s%s", current->local.filename,
		    (current->type==file_dir)?"/":"" );
	    if( current->diff == file_moved ) {
		fprintf( f, "|%s\n", current->stored.filename );
	    } else {
		putc( '\n', f );
	    }	    
	}
    }
    fprintf( f, "sectend|%s\n", name );
}

/* Produce the flat listing output for the given site */
void site_flatlist( FILE *f, struct site *site ) {
    fprintf( f, "sitestart|%s", site->name );
    if( site->url )	fprintf( f, "|%s", site->url );
    putc( '\n', f );
    if( site->numnew > 0 )
	site_flatlist_items( f, site, file_new, "added" );
    if( site->numchanged > 0 )
	site_flatlist_items( f, site, file_changed, "changed" );
    if( site->numdeleted > 0 )
	site_flatlist_items( f, site, file_deleted, "deleted" );
    if( site->nummoved > 0 )
	site_flatlist_items( f, site, file_moved, "moved" );
    fprintf( f, "siteend|%s\n", site->local_is_different?"changed":"unchanged" );
}
