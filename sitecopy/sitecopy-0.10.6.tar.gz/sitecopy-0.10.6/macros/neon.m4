# Copyright (C) 1998-2000 Joe Orton.  
# This file is free software; you may copy and/or distribute it with
# or without modifications, as long as this notice is preserved.
# This software is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY, to the extent permitted by law; without even
# the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.

# The above license applies to THIS FILE ONLY, the library code itself
# may be copied and distributed under the terms of the GNU LGPL, see
# COPYING.LIB for more details

# This file is part of the neon HTTP/WebDAV client library.
# See http://www.webdav.org/neon/ for the latest version. 
# Please send any feedback to <neon@webdav.org>
# $Id: neon.m4,v 1.13 2000/09/11 14:06:53 joe Exp $

# $1 specifies the location of the bundled neon "src" directory, or is
# empty if none is bundled. $2 specifies the location of the bundled
# expat directory, or is empty if none is bundled. 

# Usage:
# NEON_LIBRARY([libneon],[expat])
# If a neon library is not found, $NEONOBJS will be added to LIBOBJS.
# You should set NEONOBJS to the minimal set of neon object files you
# require, e.g.:
#    NEONOBJS="libneon/http_request.o libneon/http_config.o \
#	libneon/string_utils.o libneon/xalloc.o libneon/socket.o \
#	libneon/http_auth.o libneon/dates.o libneon/base64.o"

# The function defines two variables which can be used to describe
# to the user how the build has been configured:
#    neon_library_message     : for neon overall
#    neon_xml_parser_message  : which XML parser is being used

AC_DEFUN([NEON_LIBRARY],[

AC_ARG_WITH(neon,
	[  --with-neon	          Specify location of neon library ],
	[neon_loc="$withval"])

if test -n "$1"; then
	AC_ARG_WITH(included-neon,
	[  --with-included-neon    Force use of included neon library ],
 	[neon_included="$withval"],
 	[neon_included="no"])
fi

AC_MSG_CHECKING(for neon location)

if test "$neon_included" != "yes"; then
    # Look for neon

    if test -z "$neon_loc"; then
    # Look in standard places
	for d in /usr /usr/local; do
	    if test -x $d/bin/neon-config; then
		neon_loc=$d
	    fi
	done
    fi

    if test -x $neon_loc/bin/neon-config; then
	# Found it!
	AC_MSG_RESULT(found in $neon_loc)
	NEON_CONFIG=$neon_loc/bin/neon-config
	CFLAGS="$CFLAGS `$NEON_CONFIG --cflags`"
	LIBS="$LIBS `$NEON_CONFIG --libs`"
	neon_library_message="library in $neon_loc"
    else
	if test -n "$1"; then
	    neon_included="yes"
	else
	    AC_MSG_ERROR(could not find neon)
	fi
    fi
fi

if test "$neon_included" = "yes"; then
    AC_MSG_RESULT(using supplied)
    NEON_XML_PARSER($2)
    CFLAGS="$CFLAGS -I$1"
    LIBNEON_SOURCE_CHECKS
    LIBOBJS="$LIBOBJS \$(NEONOBJS)"
    neon_library_message="included libneon"
else
    neon_xml_parser_message="using whatever libneon uses"
fi

])

dnl Call these checks when compiling the libneon source package.

AC_DEFUN([LIBNEON_SOURCE_CHECKS],[

AC_CHECK_HEADERS(stdarg.h string.h strings.h sys/time.h regex.h \
	stdlib.h unistd.h limits.h sys/select.h)

AC_REPLACE_FUNCS(strcasecmp)

AC_SEARCH_LIBS(gethostbyname, nsl)

AC_SEARCH_LIBS(socket, socket inet)

NEON_SSL()

])

dnl Call to put lib/snprintf.o in LIBOBJS and define HAVE_SNPRINTF_H
dnl if snprintf isn't in libc.

AC_DEFUN([NEON_REPLACE_SNPRINTF], [

dnl Check for snprintf
AC_CHECK_FUNC(snprintf,,
	AC_DEFINE(HAVE_SNPRINTF_H, 1, [Define if need to include snprintf.h])
	LIBOBJS="$LIBOBJS lib/snprintf.o" )

])
