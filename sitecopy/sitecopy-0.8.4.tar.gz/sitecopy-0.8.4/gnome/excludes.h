/* 
 *      XSitecopy, for managing remote web sites with a GNOME interface.
 *      Copyright (C) 1999, Lee Mallabone <lee0@callnetuk.com
 *                                                                        
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *     
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *     
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 */
#include <gtk/gtk.h>

#ifndef FE_GTK_EXCLUDES_H
#define FE_GTK_EXCLUDES_H

void populate_excludes (void);
void select_exclude (GtkWidget *list, gint row);
void change_exclude (GtkWidget *entry, gpointer data);
void add_exclude (GtkWidget *button, gpointer data);
void remove_exclude (GtkWidget *button, gpointer data);
   
#endif /* Excludes_H */
