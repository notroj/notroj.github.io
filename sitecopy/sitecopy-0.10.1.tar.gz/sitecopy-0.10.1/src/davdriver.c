/* 
   sitecopy WebDAV protocol driver module
   Copyright (C) 2000, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   $Id: davdriver.c,v 1.20 2000/07/28 09:43:43 joe Exp $
*/

#include <config.h>

#include <sys/stat.h> /* For S_IXUSR */

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#include <errno.h>

#include "common.h" /* for strerror */

#include <http_request.h>
#include <http_basic.h>
#include <dav_basic.h>
#include <dav_props.h>
#include <xalloc.h>
#include <uri.h>

#include "protocol.h"
#include "frontend.h"
#include "i18n.h"

struct fetch_context {
    struct proto_file **files;
    const char *root;
};

static inline int get_depth(const char *href) {
    const char *pnt;
    int count = 0;
    for (pnt=href; *pnt != '\0'; pnt++) /* oneliner */
	if (*pnt == '/') count++;
    return count;
}

/* TODO: get rid of this? */
static void set_err(http_session *sess, const char *msg)
{
    char *err;
    CONCAT2(err, msg, strerror(errno));
    http_set_error(sess, err);
    free(err);
}

static int get_server_port(struct site *site)
{
    const char *svc;
    int port, defport;
    if (site->http_secure) {
	svc = "https";
        defport = 443;
    } else {
	svc = "http";
	defport = 80;
    }
    port = sock_service_lookup(svc);
    if (port == 0) {
	port = defport;
	DEBUG(DEBUG_HTTP, "Using default port for %s: %d\n", svc, port);
    }
    return port;
}

static int get_proxy_port(struct site *site)
{
    return 8080;
}

static int auth_common(void *userdata, fe_login_context ctx,
		       const char *realm, const char *hostname,
		       char **username, char **password)
{
    struct site_host *host = userdata;
    if (host->username && host->password) {
	*username = xstrdup(host->username);
	*password = xstrdup(host->password);
	return 0;
    } else {
	return fe_login(ctx, realm, hostname, username, password);
    }
}

static int 
server_auth_cb(void *userdata, const char *realm, const char *hostname,
	       char **username, char **password)
{
    return auth_common(userdata, fe_login_server, realm, hostname,
		       username, password);
}

static int 
proxy_auth_cb(void *userdata, const char *realm, const char *hostname,
	      char **username, char **password)
{
    return auth_common(userdata, fe_login_proxy, realm, hostname,
		       username, password);
}

static int h2s(http_session *sess, int errcode)
{
    switch (errcode) {
    case HTTP_OK:
	return SITE_OK;
    case HTTP_AUTH:
	return SITE_AUTH;
    case HTTP_AUTHPROXY:
	return SITE_PROXYAUTH;
    case HTTP_FAILED:
	return SITE_FAILED;
    case HTTP_CONNECT:
	return SITE_CONNECT;
    case HTTP_LOOKUP:
	return SITE_LOOKUP;
    case HTTP_TIMEOUT:
	http_set_error(sess, _("The connection timed out."));
	return SITE_ERRORS;
    case HTTP_SERVERAUTH:
	http_set_error(sess, 
		       _("The server did not authenticate itself correctly.\n"
			 "Report this error to your server administrator."));
	return SITE_ERRORS;
    case HTTP_PROXYAUTH:
	http_set_error(sess, 
		 _("The proxy server did not authenticate itself correctly.\n"
		   "Report this error to your proxy server administrator."));
	return SITE_ERRORS;
    case HTTP_ERROR:
    default:
	return SITE_ERRORS;
    }
}

static int 
init(void **session, struct site *site)
{
    http_session *sess = http_session_create();
    http_server_capabilities caps = {0};
    int ret;

    *session = sess;

    if (site->http_use_expect)
 	http_set_expect100(sess, 1);

    if (site->http_limit)
	http_set_persist(sess, 0);

    if (site->http_secure) {
	if (http_set_secure(sess, 1)) {
	    http_set_error(sess, _("SSL support has not be compiled in."));
	    return SITE_FAILED;
	}
    }

    /* Note, this won't differentiate between xsitecopy and
     * sitecopy... maybe we should put a comment in as well. */
    http_set_useragent(sess, PACKAGE "/" VERSION);

    if (site->proxy.hostname) {
	http_set_proxy_auth(sess, proxy_auth_cb, &site->proxy);
	ret = http_session_proxy(sess, site->proxy.hostname, site->proxy.port);
	if (ret == HTTP_LOOKUP)
	    return SITE_PROXYLOOKUP;
	else if (ret != HTTP_OK) {
	    return h2s(sess, ret);
	}
    }

    http_set_server_auth(sess, server_auth_cb, &site->server);
    ret = http_session_server(sess, site->server.hostname, site->server.port);
    if (ret != HTTP_OK) {
	return h2s(sess, ret);
    }
    
    ret = http_options(sess, site->remote_root, &caps);
    if (ret == HTTP_OK) {
	if (!caps.dav_class1) {
	    http_set_error(sess, 
			    _("The server does not appear to be a WebDAV server."));
	    return SITE_ERRORS;
	} else if (site->perms != sitep_ignore && !caps.dav_executable) {
	    /* Need to set permissions, but the server can't do that */
	    http_set_error(sess, 
			    _("The server does not support the executable live property."));
	    return SITE_ERRORS;
	}
    } else {
	return h2s(sess, ret);
    }


    return SITE_OK;
}

static void finish(void *session) 
{
    http_session *sess = session;
    http_session_destroy(sess);
}

static int file_move(void *session, const char *from, const char *to) 
{
    http_session *sess = session;
    return h2s(sess, dav_move(sess, 0, from, to));
}

static int file_upload(void *session, const char *local, const char *remote, 
		       int ascii)
{
    FILE *f = fopen(local, "r" FOPEN_BINARY_FLAGS);
    http_session *sess = session;
    int ret;

    if (f == NULL) {
	set_err(sess, _("Could not open file: "));
	return SITE_ERRORS;
    }
    
    ret = http_put(sess, remote, f);

    (void) fclose(f);

    return h2s(sess, ret);
}

static int 
file_upload_cond(void *session, const char *local, const char *remote,
		 int ascii, time_t time)
{
    http_session *sess = session;
    FILE *f = fopen(local, "r" FOPEN_BINARY_FLAGS);
    int ret;

    if (f == NULL) {
	set_err(sess, _("Could not open file: "));
	return SITE_ERRORS;
    }
    
    ret = h2s(sess, http_put_if_unmodified(sess, remote, f, time));
    
    if (ferror(f)) {
	if (ret != SITE_OK) {
	    set_err(sess, _("Could not write to file: "));
	    ret = SITE_ERRORS;
	}
    } 
    if (fclose(f)) {
	ret = SITE_ERRORS;
    }
    
    return ret;
}

static int file_get_modtime(void *session, const char *remote, time_t *modtime)
{
    http_session *sess = session;
    return h2s(sess, http_getmodtime(sess,remote,modtime));
}
    
static int file_download(void *session, const char *local, const char *remote,
			 size_t remotesize, int ascii) 
{
    http_session *sess = session;
    FILE *f = fopen(local, "w" FOPEN_BINARY_FLAGS);
    int ret;

    if (f == NULL) {
	set_err(sess, _("Could not open file: "));
	return SITE_ERRORS;
    }
    
    ret = h2s(sess, http_get(sess, remote, f));
    
    if (ferror(f)) {
	set_err(sess, _("Could not write to file: "));
	ret = SITE_ERRORS;
    }
    if (fclose(f)) {
	ret = SITE_ERRORS;
    }
    
    return ret;
}

static int file_read(void *session, const char *remote, size_t remotesize, 
		      sock_block_reader reader, void *userdata) 
{
    http_session *sess = session;
    return h2s(sess, http_read_file(sess, remote, reader, userdata));
}

static int file_delete(void *session, const char *filename) 
{
    http_session *sess = session;
    return h2s(sess, dav_delete(sess, filename));
}

static int file_chmod(void *session, const char *filename, mode_t mode) 
{
    http_session *sess = session;
    static const dav_propname execprop = 
    { "http://apache.org/dav/props/", "executable" };
    /* Use a single operation; set the executable property to... */
    dav_proppatch_operation ops[] = { 
	{ &execprop, dav_propset, NULL }, { NULL } 
    };
    
    /* True or false, depending... */
    if (mode & S_IXUSR) {
	ops[0].value = "T";
    } else {
	ops[0].value = "F";
    }
    return h2s(sess, dav_proppatch(sess, filename, ops));
}

static int dir_create(void *session, const char *dirname)
{
    http_session *sess = session;
    return h2s(sess, dav_mkcol(sess, dirname));
}

static int dir_remove(void *session, const char *dirname)
{
    http_session *sess = session;
    /* TODO: check whether it is empty first */
    return h2s(sess, dav_delete(sess, dirname));
}

static void *start_resource(void *userdata, const char *href)
{
    struct fetch_context *ctx = userdata;
    struct proto_file *file;
    
    DEBUG(DEBUG_HTTP, "Resource: %s in %s\n", href, ctx->root);
    if (strncmp(href, "http://", 7) == 0) {
	/* Absolute URI */
	href = strchr(href+7, '/');
	if (href == NULL) {
	    DEBUG(DEBUG_HTTP, "Invalid URI???");
	    return NULL;
	}
    }
    if (!uri_childof(ctx->root, href)) {
	/* URI not a child of the root collection... 
	 * ignore this resource */
	return NULL;
    }
   
    file = xmalloc(sizeof(struct proto_file));
    memset(file, 0, sizeof(struct proto_file));
    file->filename = xstrdup(href+strlen(ctx->root));
    file->depth = get_depth(file->filename);

    return file;
}

static void end_resource(void *userdata, void *res,
			 const char *status_line, const http_status *status,
			 const char *description)
{
    struct fetch_context *ctx = userdata;
    struct proto_file *file = res;

    if (file == NULL) {
	return;
    }
    
    if (!status || status->_class == 2) {
	/* Insert the file in the linked list in the appropriate
	 * position (keeping it sorted). */
	struct proto_file *previous, *current;
	previous = NULL;
	current = *ctx->files;
	while (current != NULL && current->depth < file->depth) {
	    previous = current;
	    current = current->next;
	}
	if (previous == NULL) {
	    *ctx->files = file;
	} else {
	    previous->next = file;
	}
	file->next = current;
    } else {
	DEBUG(DEBUG_HTTP, "Skipping response for %s, error status %d\n", 
	      file->filename, status->code);
	fe_warning(_("Could not access resource"), file->filename,
		   status_line);
	free(file->filename);
	free(file);
    }

    return;
}

#define ELM_getcontentlength (1001)
#define ELM_resourcetype (1002)
#define ELM_getlastmodified (1003)
#define ELM_executable (1004)
#define ELM_collection (1005)

/* joe: my GCC will only make one copy of these strings in the object
 * file, so having them in both fetch_elms and fetch_props doesn't
 * actually waste any space. */
static const struct hip_xml_elm fetch_elms[] = {
    { "DAV:", "getcontentlength", ELM_getcontentlength, HIP_XML_CDATA },
    { "DAV:", "resourcetype", ELM_resourcetype, 0 },
    { "DAV:", "getlastmodified", ELM_getlastmodified, HIP_XML_CDATA },
    { "http://apache.org/dav/props/", "executable", ELM_executable, HIP_XML_CDATA },
    { "DAV:", "collection", ELM_collection, 0 },
    { NULL }
};

static const dav_propname fetch_props[] = {
    { "DAV:", "getcontentlength" },
    { "DAV:", "resourcetype" },
    { "DAV:", "getlastmodified" },
    { "http://apache.org/dav/props/", "executable" },
    { NULL }
};

static int check_context(hip_xml_elmid child, hip_xml_elmid parent)
{
    /* FIXME */
    return 0;    
}

/* Called when a complete element is parsed */
static int end_element(void *userdata, const struct hip_xml_elm *elm, const char *cdata)
{
    struct proto_file *f;
    f = dav_propfind_get_current_resource(userdata);
    if (f == NULL) {
	return 0;
    }
    DEBUG(DEBUG_HTTP, "Property [%d], %s@@%s of %s = %s\n", elm->id,
	   elm->nspace, elm->name, f->filename, cdata?cdata:"undefined");
    switch (elm->id) {
    case ELM_getcontentlength:
	if (cdata) {
	    f->size = atoi(cdata);
	}
	break;
    case ELM_getlastmodified:
	if (cdata) {
	    f->modtime = http_dateparse(cdata);
	}
	break;
    case ELM_executable:
	if (cdata && strcasecmp(cdata, "T") == 0) {
	    f->mode = 0755; /* Made up */
	} else {
	    f->mode = 0644; /* Made up */
	}
	break;
    case ELM_collection:
	DEBUG(DEBUG_HTTP, "It's a collection!\n");
	f->type = proto_dir;
	if (uri_has_trailing_slash(f->filename)) {
	    f->filename[strlen(f->filename) - 1] = '\0';
	}
	break;
    }
    return 0;
}

/* TODO: optimize: only ask for lastmod + executable when we really
 * need them: it does waste bandwidth and time to ask for executable
 * when we know they are not defined on any resources.
 */
static int fetch_list(void *session, const char *dirname, int need_modtimes,
		       struct proto_file **files) 
{
    http_session *sess = session;
    int ret;
    struct fetch_context ctx;
    dav_propfind_handler *ph;

    ctx.root = dirname;
    ctx.files = files;
    ph = dav_propfind_create(sess, dirname, DAV_DEPTH_INFINITE);
    
    dav_propfind_set_resource_handlers(ph, start_resource, end_resource);
    hip_xml_add_handler(dav_propfind_get_parser(ph), fetch_elms, 
			 check_context, NULL, end_element, ph);
    
    ret = dav_propfind_named(ph, fetch_props, &ctx);

    return h2s(sess,ret);
}

static int unimp_link2(void *session, const char *link, const char *target)
{
    http_session *sess = session;
    http_set_error(sess, "Operation not supported");
    return SITE_UNSUPPORTED;
}
 
static int unimp_link1(void *session, const char *link)
{
    http_session *sess = session;
    http_set_error(sess, "Operation not supported");
    return SITE_UNSUPPORTED;
}


static const char *error(void *session) 
{
    http_session *sess = session;
    return http_get_error(sess);
}

/* The WebDAV protocol driver */
const struct proto_driver dav_driver = {
    init,
    finish,
    file_move,
    file_upload,
    file_upload_cond,
    file_get_modtime,
    file_download,
    file_read,
    file_delete,
    file_chmod,
    dir_create,
    dir_remove,
    unimp_link2, /* create link */
    unimp_link2, /* change link target */
    unimp_link1, /* delete link */
    fetch_list,
    error,
    get_server_port,
    get_proxy_port,
    "WebDAV"
};
