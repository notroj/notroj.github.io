#!/bin/sh
set -e
rm -rf config.cache autom4te*.cache
test -f .version || echo -n 0.0.0 > .version
${ACLOCAL:-aclocal} -I macros
${AUTOHEADER:-autoheader}
${AUTOCONF:-autoconf}
cp /usr/share/libtool/config.sub .
cp /usr/share/libtool/config.guess .
rm -rf autom4te*.cache
rm -rf intl
cp -pr /usr/share/gettext/intl intl
# annoying, and it always screws up configure.in
# Mac OS X weirdness workaround?
cp src/fileset.h src/fileset2.h
