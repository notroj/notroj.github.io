/* 
   sitecopy, for managing remote web sites. File handling.
   Copyright (C) 1998-9, Joe Orton <joe@orton.demon.co.uk>
                                                                     
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   $Id: sitefiles.c,v 1.26 1999/10/17 23:44:03 joe Exp $
*/

#include <config.h>

#include <sys/types.h>

/* Needed for S_IXUSR */
#include <sys/stat.h>

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif

#include <ctype.h>

#include "basename.h"
#include "fnmatch.h"
#include "md5.h"
#include "string_utils.h"

#include "sitesi.h"

/* Inserts a file into the files list, position chosen by type */
static struct 
site_file *file_insert( enum file_type type, struct site *site );
					     
/* fnmatch the filename against list */
inline bool fnlist_match( const char *filename, const struct fnlist *list );

static void
site_stats_increase( const struct site_file *file, struct site *site );
static void
site_stats_decrease( const struct site_file *file, struct site *site );
static void site_stats_update( struct site *site );

/* Deletes the given file from the given site */
void file_remove( struct site *site, struct site_file *item ) {
    site_stats_decrease( item, site );
    site_stats_update( site );
    if( item->prev ) {
	/* Not first in list */
	item->prev->next = item->next;
    } else {
	/* Not last in list */
	site->files = item->next;
    }
    if( item->next ) {
	/* Not last in list */
	item->next->prev = item->prev;
    } else {
	/* Last in list */
	site->files_tail = item->prev;
    }
    /* Safety */
    item->prev = NULL;
    item->next = NULL;
}

struct site_file *
file_insert( enum file_type type, struct site *site ) {
    struct site_file *file;
    file = malloc( sizeof(struct site_file) );
    if( file == NULL ) return NULL;
    memset( file, 0, sizeof(struct site_file) );
    if( site->files == NULL ) {
	/* Empty list */
	site->files = file;
	site->files_tail = file;
    } else if( type == file_dir ) {
	/* Append file */
	site->files_tail->next = file;
	file->prev = site->files_tail;
	site->files_tail = file;
    } else {
	/* Prepend file */
	site->files->prev = file;
	file->next = site->files;
	site->files = file;
    }
    return file;
}

/* Prepends  an item to the fnlist. Returns the item. */
struct fnlist *fnlist_prepend( struct fnlist **list ) {
    struct fnlist *item = malloc( sizeof( struct fnlist ) );
    item->next = *list;
    item->prev = NULL;
    if( *list != NULL ) {
	(*list)->prev = item;
    }
    *list = item;
    return item;
}

/* Returns a deep copy of the given fnlist */
struct fnlist *fnlist_deep_copy( const struct fnlist *src ) {
    const struct fnlist *iter;
    struct fnlist *dest = NULL, *prev = NULL, *item = NULL;
    for( iter = src; iter != NULL; iter = iter->next ) {
	item = malloc( sizeof( struct fnlist ) );
	item->pattern = strdup( iter->pattern );
	item->haspath = iter->haspath;
	if( prev != NULL ) {
	    prev->next = item;
	} else {
	    /* First item in list */
	    dest = item;
	}
	item->prev = prev;
	item->next = NULL;
	prev = item;
    }
    return dest;
}

/* Performs fnmatch() of all the strings in the given string list again
 * the given filename. Returns true if a pattern matches, else false. */
inline bool fnlist_match( const char *filename, const struct fnlist *list ) {
    const struct fnlist *item;
    char *bname = base_name( filename );    

    for( item=list; item != NULL; item=item->next ) {
	DEBUG( DEBUG_FILES, "%s ", item->pattern );
	if( item->haspath ) {
	    if( fnmatch( item->pattern, filename, FNM_PATHNAME ) == 0 )
		break;
	} else {
	    if( fnmatch( item->pattern, bname, 0 ) == 0 )
		break;
	}
    }
	
#ifdef DEBUGGING
    if( item ) {
	DEBUG( DEBUG_FILES, "- matched.\n" );
    } else if( list ) {
	DEBUG( DEBUG_FILES, "\n" );
    } else {
	DEBUG( DEBUG_FILES, "(none)\n" );
    }
#endif DEBUGGING

    return (item!=NULL);
}

/* Returns whether the given filename is excluded from the
 * given site */
bool file_isexcluded( const char *filename, struct site *site ) {
    DEBUG( DEBUG_FILES, "Matching excludes for %s:\n", filename );
    return fnlist_match( filename, site->excludes );
}

bool file_isignored( const char *filename, struct site *site ) {
    DEBUG( DEBUG_FILES, "Matching ignores for %s:\n", filename );
    return fnlist_match( filename, site->ignores );
}

bool file_isascii( char *filename, struct site *site ) {
    DEBUG( DEBUG_FILES, "Matching asciis for %s:\n", filename );
    return fnlist_match( filename, site->asciis );
}

inline void 
site_stats_increase( const struct site_file *file, struct site *site ) {
    switch( file->diff ) {
    case file_unchanged:
	site->numunchanged++;
	break;
    case file_changed:
	if( file->ignore ) {
	    site->numignored++;
	} else {
	    site->numchanged++;
	    site->totalchanged += file->local.size;
	}
	break;
    case file_new:
	site->numnew++;
	site->totalnew += file->local.size;
	break;
    case file_moved:
	site->nummoved++;
	break;
    case file_deleted:
	site->numdeleted++;
	break;
    default:
	/* Do nothing */
	break;
    }
}

static void site_stats_update( struct site *site ) {
    DEBUG( DEBUG_FILES, 
	   "Stats: moved=%d new=%d %sdeleted=%d%s changed=%d"
	   " ignored=%d unchanged=%d\n",
	   site->nummoved, site->numnew, site->nodelete?"[":"",
	   site->numdeleted, site->nodelete?"]":"", site->numchanged,
	   site->numignored, site->numunchanged );
    site->remote_is_different = (site->nummoved + site->numnew +
				 (site->nodelete?0:site->numdeleted) + 
				 site->numchanged) > 0;
    site->local_is_different = (site->nummoved + site->numnew +
				site->numdeleted + site->numchanged + 
				site->numignored) > 0;
    DEBUG( DEBUG_FILES, "Remote: %s  Local: %s\n", 
	   site->remote_is_different?"yes":"no", 
	   site->local_is_different?"yes":"no" );
}

void 
site_stats_decrease( const struct site_file *file, struct site *site ) {
    switch( file->diff ) {
    case file_unchanged:
	site->numunchanged--;
	break;
    case file_changed:
	if( file->ignore ) {
	    site->numignored--;
	} else {
	    site->numchanged--;
	    site->totalchanged -= file->local.size;
	}
	break;
    case file_new:
	site->numnew--;
	site->totalnew -= file->local.size;
	break;
    case file_moved:
	site->nummoved--;
	break;
    case file_deleted:
	site->numdeleted--;
	break;
    default:
	/* Do nothing */
	break;
    }
}

void file_set_diff( struct site_file *file, struct site *site ) {
    site_stats_decrease( file, site );
    file->diff = file_compare( file->type, &file->local, &file->stored, site );
    site_stats_increase( file, site );
    site_stats_update( site );
}

inline void file_state_copy( struct file_state *dest, 
			     const struct file_state *src ) {
    file_state_destroy( dest );
    memcpy( dest, src, sizeof(struct file_state) );
    if( src->linktarget != NULL ) {
	dest->linktarget = strdup( src->linktarget );
    }
    if( src->filename != NULL ) {
	dest->filename = strdup( src->filename );
    }
}

void file_state_destroy( struct file_state *state ) {
    if( state->linktarget != NULL ) {
	free( state->linktarget );
	state->linktarget = NULL;
    }
    if( state->filename != NULL ) {
	free( state->filename );
	state->filename = NULL;
    }
}


/* Destroys a file */
void file_destroy( struct site_file *file ) {
    
    file_state_destroy( &file->local );
    file_state_destroy( &file->stored );
    file_state_destroy( &file->server );

    free( file );

}

/* Checksum the file.
 * We pass the site atm, since it's likely we will add different
 * methods of checksumming later on, with better-faster-happier
 * algorithms.
 * Returns:
 *  0 on success
 *  non-zero on error (e.g., couldn't open file)
 */
int
file_checksum( const char *fname, struct file_state *state, struct site *s ) {
    int ret;
    FILE *f;
    f = fopen( fname, BINARY_R_FOPEN );
    if( f == NULL ) {
	return -1;
    }
    ret = md5_stream( f, state->checksum );
    fclose( f ); /* worth checking return value? */
#ifdef DEBUGGING
    { 
	char tmp[33] = {0};
	md5_hexify( state->checksum, tmp );
	DEBUG( DEBUG_FILES, "Checksum: %s = [%32s]\n", fname, tmp );
    }
#endif /* DEBUGGING */
    return ret;
}    

/* Dynamically update the files list. This is a really confusing function.
 * Returns a file in the list with the LOCAL state set to the given
 * state. Shallow copies the filename (and linktarget) out of the state.
 * Updates the files list to reflect moved files etc. */

/* TODO: Make this generic, so the implementation of set_local and
 * set_remote is not so copy'n'paste.
 */

struct site_file *
file_set_local( enum file_type type, struct file_state *state, 
		struct site *site ) {
    struct site_file *file, *direct = NULL, *moved = NULL, *rename = NULL;
    enum file_diff dir_diff;
    char *bname;
    DEBUG( DEBUG_FILES, "set_local on %s: \n", state->filename );
    if( site->checkmoved && (type==file_file)) 
	bname = base_name( state->filename );
    for( file=site->files; file!=NULL; file=file->next ) {
	/* TODO: profile and reorder these checks for best case. */
	if( file->stored.exists && 
	    (direct == NULL) &&
	    (file->type == type) && 
	    (strcmp( file->stored.filename, state->filename ) == 0) ) {
	    /* Direct match found! */
	    direct = file;
	} else if( site->checkmoved && 	/* Check for moved files... */
		   (type == file_file) && 
		   (moved == NULL) &&
		   (file->type == file_file) && 
		   (file_compare( file_file, state, &file->stored, site )
		    == file_moved) ) {
	    /* TODO: There is a slight fuzz here - if checkrenames is true, 
	     * we'll always match the first 'direct move' candidate as a 
	     * 'rename move'. I don't think this matters. */
	    if( site->checkrenames && rename == NULL ) {
		DEBUG( DEBUG_FILES, "(Rename) move candidate: %s\n", 
		       file->stored.filename );
		rename = file;
	    } else if( strcmp( bname, base_name(file->stored.filename) ) == 0){
		DEBUG( DEBUG_FILES, "Direct move candidate: %s\n", 
		       file->stored.filename );
		moved = file;
	    }
	}
	/* Stop searching if we've found all we need */
	if( direct!=NULL && moved!=NULL && rename!=NULL ) break;
    }
    DEBUG( DEBUG_FILES, "Found: %s-%s-%s\n", 
	   direct?"direct":"", moved?"moved":"", rename?"rename":"" );
    /* We prefer a direct move to a rename */
    if( moved == NULL ) moved = rename;
    if( direct != NULL ) {
	dir_diff = file_compare( type, state, &direct->stored, site );
	DEBUG( DEBUG_FILES, "Direct compare: %s\n", 
	       DEBUG_GIVE_DIFF( dir_diff ) );
    } else {
	dir_diff = file_new;
    }
    /* We prefer a move to a CHANGED direct match. */
    if( (direct==NULL && moved==NULL) ||
	(direct!=NULL && direct->diff == file_moved &&
	 moved==NULL && dir_diff != file_unchanged ) ) {
	DEBUG( DEBUG_FILES, "Creating new file.\n" );
	file = file_insert( type, site );
	file->type = type;
	file->diff = file_new;
	if( type == file_file ) {
	    file->ignore = file_isignored( state->filename, site );
	}
    } else {
	/* Overwrite file case...
	 * Again, we still prefer a move to a direct match */
	if( moved!=NULL && dir_diff!=file_unchanged ) {
	    DEBUG( DEBUG_FILES, "Using moved file.\n" );
	    file = moved;
	    site_stats_decrease( file, site );
	    file->diff = file_moved;
	} else {
	    DEBUG( DEBUG_FILES, "Using direct match.\n" );
	    file = direct;
	    site_stats_decrease( file, site );
	    file->diff = dir_diff;
	}
	if( file->local.exists ) {
	    /* SHOVE! */
	    struct site_file *other;
	    DEBUG( DEBUG_FILES, "Shoving file:\n" );
	    other = file_insert( file->type, site );
	    other->type = file->type;
	    other->diff = file_new;
	    other->ignore = file->ignore;
	    /* Copy over the stored state for the moved file. */
	    memcpy( &other->local, &file->local, sizeof(struct file_state) );
	    DEBUG_DUMP_FILE_PROPS( DEBUG_FILES, file, site );
	    site_stats_increase( other, site );
	}
    }
    /* Finish up - write over the new state */
    memcpy( &file->local, state, sizeof(struct file_state) );
    /* And update the stats */
    site_stats_increase( file, site );
    site_stats_update( site );
    return file;
}    

/* See file_set_local for more comments.
 * This function is a direct dup of file_set_local, with stored swapped
 * for local, and file_new swapped for file_deleted.
 */
struct site_file *
file_set_stored( enum file_type type, struct file_state *state,
		 struct site *site ) {
    struct site_file *file, *moved = NULL, *direct = NULL, *rename = NULL;
    enum file_diff dir_diff;
    char *bname;
    if( site->checkmoved && (type==file_file)) 
	bname = base_name( state->filename );
    for( file=site->files; file!=NULL; file=file->next ) {
	/* TODO: profile and reorder these checks for best case. */
	if( file->local.exists && 
	    (file->type == type) && 
	    (strcmp( file->local.filename, state->filename ) == 0) ) {
	    /* Direct match found! */
	    direct = file;
	} else if( site->checkmoved && /* Check for moved files. */
		   (type == file_file) && 
		   (moved == NULL) &&
		   (file->type == file_file) &&
		   (file_compare( file_file, state, &file->local, site ) 
		    == file_moved)) {
	    if( site->checkrenames && rename == NULL ) {
		DEBUG( DEBUG_FILES, "(Rename) move candidate: %s\n", 
		       file->local.filename );
		rename = file;
	    } else if( strcmp( bname, base_name(file->local.filename) ) == 0){
		DEBUG( DEBUG_FILES, "Direct move candidate: %s\n", 
		       file->local.filename );
		moved = file;
	    }
	}
	/* Stop searching if we've found all we need */
	if( direct!=NULL && moved!=NULL && rename!=NULL ) break;
    }
    DEBUG( DEBUG_FILES, "Found: %s-%s-%s\n", 
	   direct?"direct":"", moved?"moved":"", rename?"rename":"" );
    /* We prefer a direct move to a rename */
    if( moved == NULL ) moved = rename;
    if( direct != NULL ) {
	dir_diff = file_compare( type, state, &direct->local, site );
	DEBUG( DEBUG_FILES, "Direct compare: %s\n", 
	       DEBUG_GIVE_DIFF( dir_diff ) );
    } else {
	dir_diff = file_new;
    }
    if( (direct==NULL && moved==NULL) ||
	(direct!=NULL && direct->diff == file_moved &&
	 moved==NULL && dir_diff != file_unchanged ) ) {
	DEBUG( DEBUG_FILES, "Creating new file.\n" );
	file = file_insert( type, site );
	file->type = type;
	file->diff = file_deleted;
	if( type == file_file ) {
	    file->ignore = file_isignored( state->filename, site );
	}
    } else {
	/* Overwrite file case. */
	if( moved!=NULL && dir_diff!=file_unchanged ) {
	    DEBUG( DEBUG_FILES, "Using moved file.\n" );
	    file = moved;
	    site_stats_decrease( file, site );
	    file->diff = file_moved;
	} else {
	    DEBUG( DEBUG_FILES, "Using direct match.\n" );
	    file = direct;
	    site_stats_decrease( file, site );
	    file->diff = dir_diff;
	}
	if( file->stored.exists ) {
	    /* SHOVE! */
	    struct site_file *other;
	    DEBUG( DEBUG_FILES, "Shoving file:\n" );
	    other = file_insert( file->type, site );
	    other->type = file->type;
	    other->diff = file_new;
	    other->ignore = file->ignore;
	    /* Copy over the stored state for the moved file. */
	    memcpy( &other->stored, &file->stored, sizeof(struct file_state) );
	    DEBUG_DUMP_FILE_PROPS( DEBUG_FILES, file, site );
	    site_stats_increase( other, site );
	}
    }
    /* Finish up - write over the new state */
    memcpy( &file->stored, state, sizeof(struct file_state) );
    /* And update the stats */
    site_stats_increase( file, site );
    site_stats_update( site );
    return file;
}

/* Returns the difference between the local and stored state of the
 * given file in the given state.
 * Returns:
 *   file_changed    if changed
 *   file_unchanged  otherwise
 */
enum file_diff 
file_compare( const enum file_type type, 
	      const struct file_state *first, const struct file_state *second, 
	      const struct site *site ) {
    enum file_diff ret = file_unchanged;
    /* Handle the special cases */
    if( !first->exists )
	return file_deleted;
    if( !second->exists )
	return file_new;
    /* They're both there... compare them properly */
    switch( type ) {
    case file_dir:
	break;
    case file_link:
	if( strcmp( first->linktarget, second->linktarget ) != 0 ) {
	    ret = file_changed;
	}
	break;
    case file_file:
	switch( site->state_method ) {
	case state_timesize:
	    if( (first->time != second->time) 
		|| (first->size!=second->size) ) {
		ret = file_changed;
	    }
	    break;
	case state_checksum:
	    if( memcmp( first->checksum, second->checksum, 16 ) != 0 ) {
		ret = file_changed;
	    }
	    break;
	}
	/* Check permissions and ASCIIness.
	 * There's a twist for permissions: if EITHER local or
	 * remote file has an EXEC bit set, then in 'perms exec' mode,
	 * perms are compared. */
	if( first->ascii != second->ascii ) {
	    ret = file_changed;
	} else if( (site->perms == sitep_all) ||
		   ( ( (first->mode & S_IXUSR) || (second->mode & S_IXUSR) ) &&
		     (site->perms == sitep_exec) ) ) {
	    if( first->mode != second->mode ) {
		ret = file_changed;
	    }
	}
	if( ret == file_unchanged && site->checkmoved &&
	    strcmp( first->filename, second->filename) ) {
	    ret = file_moved;
	}
	break;
    }
    return ret;
}

char *file_full_remote( struct file_state *state, struct site *site ) {
    char *ret;
    ret = malloc( strlen(site->remote_root) + strlen(state->filename) + 1 );
    strcpy( ret, site->remote_root );
    if( site->lowercase ) {
	int n, off, len;
	/* Write the remote filename in lower case */
	off = strlen( site->remote_root );
	len = strlen( state->filename ) + 1; /* +1 for \0 */
	for( n = 0; n < len; n++ ) {
	    ret[off+n] = tolower(state->filename[n]);
	}
    } else {
	strcat( ret, state->filename );
    }
    return ret;
}

char *file_full_local( struct file_state *state, struct site *site ) {
    char *ret;
    CONCAT2( ret, site->local_root, state->filename );
    return ret;
}

char *file_name( const struct site_file *file ) {
    if( file->diff == file_deleted ) {
	return file->stored.filename;
    } else {
	return file->local.filename;
    }
}

/* Returns whether the file "contents" have changed or not.
 * TODO: better name needed. */
bool file_contents_changed( struct site_file *file, struct site *site ) {
    bool ret = false;
    if( site->state_method == state_checksum ) {
	if( memcmp( file->stored.checksum, file->local.checksum, 16 ) )
	    ret = true;
    } else {
	if( file->stored.size != file->local.size ||
	    file->stored.time != file->local.time ) 
	    ret = true;
    }
    if( file->stored.ascii != file->local.ascii )
	ret = true;
    return ret;
}

bool file_perms_changed( struct site_file *file, struct site *site ) {
    if( ( (site->perms == sitep_all) || 
	  ( ((file->local.mode | file->stored.mode ) & S_IXUSR) && 
	    (site->perms == sitep_exec)) ) &&
	( file->local.mode != file->stored.mode || 
	  file->local.exists != file->stored.exists ) ) {
	return true;
    } else {
	return false;
    }
}

/*  */    
void file_uploaded( struct site_file *file, struct site *site ) {
    file->stored.size = file->local.size;
    if( site->state_method == state_checksum ) {
	memcpy( file->stored.checksum, file->local.checksum, 16 );
    } else {
	file->stored.time = file->local.time;
    }
    /* Now the filename */
    if( file->stored.filename ) free( file->stored.filename );
    file->stored.filename = strdup( file->local.filename );
    file->stored.ascii = file->local.ascii;
    file->stored.exists = file->local.exists;
    /* Update the diff */
    file_set_diff( file, site );
}
    
void file_downloaded( struct site_file *file, struct site *site ) {
    file->local.size = file->stored.size;
    if( site->state_method == state_checksum ) {
	memcpy( file->local.checksum, file->stored.checksum, 16 );
    } else {
	file->local.time = file->stored.time;
    }
    /* Now the filename */
    if( file->local.filename ) free( file->local.filename );
    file->local.filename = strdup( file->stored.filename );
    file->local.ascii = file->stored.ascii;
    file->local.exists = file->stored.exists;
    file_set_diff( file, site );
}
