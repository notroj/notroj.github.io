/* 
   WebDAV Properties manipulation
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

   $Id: dav_props.c,v 1.9 2000/04/30 21:48:23 joe Exp $
*/

#include "config.h"

#include "xalloc.h"
#include "dav_props.h"
#include "dav_basic.h"

struct propfind_context {
    /* The array of properties they passed to us */
    dav_propname *propnames;
    dav_propfind_result *result;
    int numresults;
    char *href;
    http_status status;
    dav_propfind_callback callback;
    void *userdata;
};

int dav_propfind( http_session *sess, const char *uri, int depth, 
		  const dav_propname props[],
		  dav_propfind_callback callback, void *userdata ) {
    int ret, is_allprop = (props==NULL);
    http_req *req = http_request_create( sess, "PROPFIND", uri );
    http_status status;
    struct propfind_context ctx = {0};
    dav_207_parser *parser;
    sbuffer body, hdrs;
    
    body = sbuffer_create();

    sbuffer_concat( body, 
		    "<?xml version=\"1.0\" encoding=\"utf-8\"?>" EOL 
		    "<propfind xmlns=\"DAV:\">", NULL );
    
    if( !is_allprop ) {
	int n;
	sbuffer_zappend( body, "<prop>" EOL );
	for( n = 0; props[n].name != NULL; n++ ) {
	    sbuffer_concat( body, "<", props[n].name, " xmlns=\"", 
			    props[n].nspace, "\"/>" EOL, NULL );
	}
	sbuffer_zappend( body, "</prop></propfind>" EOL );
    } else {
	sbuffer_zappend( body, "</allprop></propfind>" EOL );
    }

    parser = dav_207_init( &ctx );
    
    http_set_request_body_buffer( req, sbuffer_data(body) );
    
    hdrs = http_get_request_header( req );
    sbuffer_zappend( hdrs, "Content-Type: text/xml" EOL ); /* TODO: UTF-8? */
    dav_add_depth_header( req, depth );
    
    ret = http_request_dispatch( req, &status );

    http_request_destroy( req );

    return ret;
}

/* Reassuringly easy */
int dav_proppatch( http_session *sess, const char *uri, 
		   const dav_proppatch_operation *items )
{
    http_req *req = http_request_create( sess, "PROPPATCH", uri );
    sbuffer body = sbuffer_create(), hdrs;
    int n, ret;
    
    /* Create the request body */
    sbuffer_zappend( body, "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" EOL
		     "<propertyupdate xmlns=\"DAV:\">" );

    for( n = 0; items[n].name != NULL; n++ ) {
	switch( items[n].type ) {
	case dav_propset:
	    /* <set><prop><prop-name>value</prop-name></prop></set> */
	    sbuffer_concat( body, "<set><prop>"
			    "<", items[n].name->name, " xmlns=\"",
			    items[n].name->nspace, "\">", items[n].value,
			    "</", items[n].name->name, "></prop></set>" EOL, NULL );
	    break;

	case dav_propremove:
	    /* <remove><prop><prop-name/></prop></remove> */
	    sbuffer_concat( body, "<remove><prop><", items[n].name->name, " xmlns=\"",
			    items[n].name->nspace, "\"/></prop></remove>" EOL, NULL );
	    break;
	}
    }	

    sbuffer_zappend( body, "</propertyupdate>" EOL );
    
    http_set_request_body_buffer( req, sbuffer_data(body) );

    hdrs = http_get_request_header( req );
    sbuffer_zappend( hdrs, "Content-Type: text/xml" EOL ); /* TODO: UTF-8? */
    
    ret = dav_simple_request( sess, req );
    
    sbuffer_destroy( body );
    
    return ret;
}

