/* 
   WebDAV Properties manipulation
   Copyright (C) 1999-2000, Joe Orton <joe@orton.demon.co.uk>
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.
  
   Alternatively, you can redistribute it and/or modify it under the
   terms of the GNU Library General Public License as published by the
   Free Software Foundation; either version 2 of the License, or (at
   your option) any later version.

   This software is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   License for more details.

   You should have received copies of the GNU Library General Public
   License and the GNU General Public License along with this software; 
   if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
   Cambridge, MA 02139, USA.

*/

#ifndef DAV_PROPS_H
#define DAV_PROPS_H

#include "http_request.h"

/* The name of a WebDAV property. */
typedef struct {
    const char *nspace, *name;
} dav_propname;

/* The result of a PROPFIND operation for a particular resource: */
typedef struct {
    const dav_propname *propname;
    char *value;
    const http_status *status;
} dav_propfind_result;

/* A result from the PROPFIND operation. */
typedef void (*dav_propfind_callback)( 
    void *userdata, const char *href, 
    dav_propfind_result results[], int numresults );

/* Find properties with names in set *props on resource at URI 
 * in set *props, with given depth. If props == NULL all properties
 * are returned. For each property result returned, the callback is
 * passed the userdata, and the property object, value, and the status.
 * Returns:
 *   HTTP_OK on success.
 *   else other HTTP_* code
 */
int dav_propfind( http_session *sess, 
		  const char *uri, int depth, const dav_propname *names,
		  dav_propfind_callback callback, void *userdata );


/* A PROPPATCH request may include any number of operations. Pass an
 * array of these operations to dav_proppatch, with the last item
 * having the name element being NULL.  If the type is propset, the
 * property of the given name is set to the new value.  If the type is
 * propremove, the property of the given name is deleted, and the
 * value is ignored.  */
typedef struct {
    const dav_propname *name;
    enum {
	dav_propset,
	dav_propremove
    } type;
    const char *value;
} dav_proppatch_operation;

int dav_proppatch( http_session *sess, const char *uri,
		   const dav_proppatch_operation *items );

#endif /* DAV_PROPS_H */
