# Copyright (C) 1998-2000 Joe Orton.  
# This file is free software; you may copy and/or distribute it with
# or without modifications, as long as this notice is preserved.
# This software is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY, to the extent permitted by law; without even
# the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE.

# The above license applies to THIS FILE ONLY, the neon library code
# itself may be copied and distributed under the terms of the GNU
# LGPL, see COPYING.LIB for more details

# This file is part of the neon HTTP/WebDAV client library.
# See http://www.webdav.org/neon/ for the latest version. 
# Please send any feedback to <neon@webdav.org>

#
# Usage:
#      NEON_LIBRARY
# or   NEON_BUNDLED(src) 
#   where srcs is the location of bundled neon 'src' directory.
#
# After calling NEON_LIBRARY or NEON_BUNDLED, if
# NEON_NEED_XML_PARSER="yes", then you must configure an XML parser
# too. You can do this your own way, or do it easily using the
# NEON_XML_PARSER() macro. Example usage for where we have bundled the
# neon sources in a directory called libneon, and bundled expat
# sources in a directory called 'expat'.
#
#   NEON_BUNDLED(libneon)
#   NEON_XML_PARSER(expat)
#
# Alternatively, for a simple standalone app with neon as a
# dependancy, use just:
#
#   NEON_LIBRARY
# 
# and rely on the user installing neon correctly.
#
# You are free to configure an XML parser any other way you like,
# but the end result must be, either expat or libxml will get linked
# in, and HAVE_EXPAT or HAVE_LIBXML is defined appropriately.
#
# If a neon library is not found, and NEON_BUNDLED is used, $NEONOBJS
# will be added to LIBOBJS. So, you should set NEONOBJS to the minimal
# set of neon object files you require, e.g.:
#
#    NEONOBJS="libneon/http_request.o libneon/http_config.o \
#	libneon/string_utils.o libneon/xalloc.o libneon/socket.o \
#	libneon/http_auth.o libneon/dates.o libneon/base64.o"

# The function defines two variables which can be used to describe
# to the user how the build has been configured:
#    neon_library_message     : for neon overall

AC_DEFUN([NEON_BUNDLED],[

AC_ARG_WITH(included-neon,
[  --with-included-neon    Force use of included neon library ],
[neon_force_included="$withval"],
[neon_force_included="no"])

neon_bundled_location=$1

NEON_COMMON

])

dnl Not got any bundled sources:
AC_DEFUN([NEON_LIBRARY],[

neon_force_included=no
neon_bundled_location=

NEON_COMMON

])

AC_DEFUN([NEON_COMMON],[

AC_ARG_WITH(neon,
	[  --with-neon	          Specify location of neon library ],
	[neon_loc="$withval"])

AC_MSG_CHECKING(for neon location)

if test "$neon_force_included" = "no"; then
    # We don't have an included neon source directory,
    # or they aren't force us to use it.

    if test -z "$neon_loc"; then
	# Look in standard places
	for d in /usr /usr/local; do
	    if test -x $d/bin/neon-config; then
		neon_loc=$d
	    fi
	done
    fi

    if test -x $neon_loc/bin/neon-config; then
	# Found it!
	AC_MSG_RESULT(found in $neon_loc)
	NEON_CONFIG=$neon_loc/bin/neon-config
	CFLAGS="$CFLAGS `$NEON_CONFIG --cflags`"
	LIBS="$LIBS `$NEON_CONFIG --libs`"
	neon_library_message="library in $neon_loc"
	neon_xml_parser_message="using whatever libneon uses"
    else
	if test -n "$neon_bundled_location"; then
	    # Couldn't find neon, forced to use bundled sources
	    neon_force_included="yes"
	else
	    # Couldn't find neon, and don't have bundled sources
	    AC_MSG_ERROR(could not find neon)
	fi	    
    fi
fi

# This isn't a simple 'else' branch, since neon_force_included
# is set to yes if the search fails.

if test "$neon_force_included" = "yes"; then
    AC_MSG_RESULT(using supplied)
    dnl The NEON_INCLUDED_SOURCE below looks weird, but m4
    dnl groks it, so believe in it...
    CFLAGS="$CFLAGS -I$neon_bundled_location"
    LIBS="$LIBS -L$neon_bundled_location"
    LIBNEON_SOURCE_CHECKS
    LIBOBJS="$LIBOBJS \$(NEONOBJS)"
    neon_library_message="included libneon"
else
    # Don't need to configure an XML parser
    NEON_NEED_XML_PARSER=no
fi

])

dnl Call these checks when compiling the libneon source package.

AC_DEFUN([LIBNEON_SOURCE_CHECKS],[

AC_CHECK_HEADERS(stdarg.h string.h strings.h sys/time.h regex.h \
	stdlib.h unistd.h limits.h sys/select.h arpa/inet.h)

AC_REPLACE_FUNCS(strcasecmp)

AC_SEARCH_LIBS(gethostbyname, nsl)

AC_SEARCH_LIBS(socket, socket inet)

NEON_SSL()

# Need to configure an XML parser, thankye.
NEON_NEED_XML_PARSER=yes

])

dnl Call to put lib/snprintf.o in LIBOBJS and define HAVE_SNPRINTF_H
dnl if snprintf isn't in libc.

AC_DEFUN([NEON_REPLACE_SNPRINTF], [

dnl Check for snprintf
AC_CHECK_FUNC(snprintf,,
	AC_DEFINE(HAVE_SNPRINTF_H, 1, [Define if need to include snprintf.h])
	LIBOBJS="$LIBOBJS lib/snprintf.o" )

])

AC_DEFUN([NEON_COMMON_BUILD], [

AC_SUBST(NEON_TARGET)
AC_SUBST(OBJ_EXT)

top_builddir=`pwd`
AC_SUBST(top_builddir)

AC_PATH_PROG(AR, ar)

])

AC_DEFUN([NEON_LIBTOOL_BUILD], [

NEON_TARGET=libneon.la
OBJ_EXT=lo

NEON_COMMON_BUILD

])

AC_DEFUN([NEON_NORMAL_BUILD], [

NEON_TARGET=libneon.a
OBJ_EXT=o

NEON_COMMON_BUILD

])