Fixes XXXX (fixes #NNN)

```
Changelog:

```
